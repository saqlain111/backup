import os
import logging
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from typing import Optional

from slack_utils.report_generator import generate_slack_report
from utils.email_fetcher import get_report_recipients

from config.constants import ADMIN_EMAILS, LOG_PATH
from config.env_config import SLACK_BOT_TOKEN

logger = logging.getLogger(__name__)


def get_user_slack_id(email: str, client: WebClient) -> Optional[str]:
    """Get Slack user ID from email address"""
    try:
        response = client.users_lookupByEmail(email=email)
        return response["user"]["id"]
    except SlackApiError as e:
        if e.response["error"] == "users_not_found":
            logger.error(f"No Slack user found for email: {email}")
        else:
            logger.error(f"Error looking up Slack user: {str(e)}")
        return None


def log_file_has_errors(log_path: str = LOG_PATH) -> bool:
    """
    Check if the given log file contains any 'ERROR' entries.

    Args:
        log_path (str): Path to the log file

    Returns:
        bool: True if any 'ERROR' is found, False otherwise
    """
    try:
        with open(log_path, "r") as f:
            return "ERROR" in f.read()
    except Exception as e:
        logger.error(f"Failed to read log file {log_path}: {e}")
        return False


def send_message_to_user(email: str, message: str) -> bool:
    """
    Send a message to a specific Slack user via email.
    Attach the log file only if the user is in ADMIN_EMAILS and errors are present.
    """
    client = WebClient(token=SLACK_BOT_TOKEN)
    user_id = get_user_slack_id(email, client)
    if not user_id:
        return False

    attach_log = email in ADMIN_EMAILS and log_file_has_errors(LOG_PATH)

    try:
        response = client.conversations_open(users=[user_id])
        channel_id = response["channel"]["id"]

        # Send the main message
        client.chat_postMessage(channel=channel_id, text=message)

        # Attach the log file only for admin emails if errors are found
        if attach_log:
            try:
                client.files_upload(
                    channels=channel_id,
                    filename=LOG_PATH,
                    file=LOG_PATH,
                    filetype="text",
                    title="Error Log",
                    initial_comment=f"⚠️ Errors detected in `{LOG_PATH}`. See attached file.",
                )
                logger.info(f"Log file attached for {email}")
            except SlackApiError as e:
                logger.error(f"Failed to upload log file for {email}: {str(e)}")

        logger.info(f"Message successfully sent to {email} (Slack ID: {user_id})")
        return True

    except SlackApiError as e:
        logger.error(f"Error sending Slack message to {email}: {str(e)}")
        return False


def send_report_to_recipients() -> dict:
    """
    Send the report to all recipients (hiring lead + admins)

    Returns:
        dict: Results for each recipient {email: success}
    """
    # Generate report message
    report_message = generate_slack_report()

    # Get recipients
    recipients = get_report_recipients()
    logger.info(f"Sending report to recipients: {', '.join(recipients)}")

    # Send to each recipient
    results = {}
    for email in recipients:
        success = send_message_to_user(email, report_message)
        results[email] = success

    return results
