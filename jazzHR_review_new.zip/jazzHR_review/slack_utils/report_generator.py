import re

from config.env_config import JOB_ROLE_TITLE, JOB_CITY_LOCATION

EMOJI_PATTERN = re.compile(
    r"[\U0001F300-\U0001F9FF\U00002600-\U000027BF\U0001F100-\U0001F1FF"
    r"\U0001F680-\U0001F6FF\U0001F900-\U0001F9FF\U00002700-\U000027BF"
    r"\U0001F000-\U0001F02F\U0001F0A0-\U0001F0FF\U0001F200-\U0001F2FF"
    r"\U0001F600-\U0001F64F\U0001F680-\U0001F6FF]"
)


def generate_slack_report() -> str:
    """Generate Slack report from REPORT_DATA with emojis and dynamic table formatting"""
    from workflows.candidate_browser_processor import REPORT_DATA

    if not REPORT_DATA["success"]:
        return f"❌ Resume review process failed for job title: `{JOB_ROLE_TITLE}` at city location: `{JOB_CITY_LOCATION}`. Check logs for details."

    # Header section
    message = [
        "🎯 *Resume Review Job Results:*",
        f"Job: `{JOB_ROLE_TITLE}` | City: `{JOB_CITY_LOCATION}`",
        f"* Found: `{REPORT_DATA['found_candidates']}` candidates",
        f"  * Pre-filter rejects: `{REPORT_DATA['pre_filter_rejects']}`",
        f"  * AI Model rejects: `{REPORT_DATA['rejected_candidates']}`",
        f"  * Advanced: `{REPORT_DATA['advanced_candidates']}`",
        "",
        "📋 *Candidate Details:*",
    ]

    # Candidate details table
    if REPORT_DATA["candidate_details"]:
        table_data = []
        for candidate in REPORT_DATA["candidate_details"]:
            # Process candidate data
            name = candidate["name"]
            if len(name) > 25:
                name = name[:23] + ".."

            pf_status = (
                "✅ Pass" if candidate["pre_filter_status"] == "Passed" else "❌ Reject"
            )
            score = f"{candidate['score']:.1f}" if candidate["score"] > 0 else "0"
            action = "✅ Advance" if candidate["action"] == "advance" else "🚫 Reject"

            reasons = candidate["rejection_reasons"]
            if len(reasons) > 57:
                reasons = reasons[:55] + ".."

            table_data.append(
                [name, pf_status, score, candidate["e_level"], action, reasons]
            )

        headers = ["Name", "Pre-filter", "Score", "E-Level", "Decision", "Reasons"]
        formatted_table = create_custom_table(table_data, headers)

        message.append("```")
        message.append(formatted_table)
        message.append("```")

    return "\n".join(message)


def visual_length(text: str) -> int:
    """Calculate visual length accounting for emojis taking 2 spaces"""
    if not text:
        return 0

    # Count emojis efficiently using precompiled pattern
    emoji_count = len(EMOJI_PATTERN.findall(text))
    # Regular characters count (subtract emoji characters)
    char_count = len(text) - emoji_count
    return char_count + (emoji_count * 2)


def calculate_optimal_column_widths(table_data, headers):
    """Calculate column widths based on content visual length"""
    num_columns = len(headers)
    column_widths = [0] * num_columns

    # Process headers first
    for i, header in enumerate(headers):
        column_widths[i] = visual_length(header)

    # Process data rows
    for row in table_data:
        for i in range(num_columns):
            if i < len(row):
                cell_length = visual_length(str(row[i]))
                if cell_length > column_widths[i]:
                    column_widths[i] = cell_length

    # Add minimal padding (1 space per side)
    return [w + 2 for w in column_widths]


def visual_pad(text: str, target_width: int) -> str:
    """Pad string to target visual width accounting for emojis"""
    current_width = visual_length(text)
    padding = max(0, target_width - current_width)
    return text + (" " * padding)


def create_custom_table(table_data, headers):
    """Create visually aligned table for Slack with emoji handling"""
    if not table_data:
        return ""

    col_widths = calculate_optimal_column_widths(table_data, headers)
    lines = []

    # Create header
    header_cells = [visual_pad(headers[i], col_widths[i]) for i in range(len(headers))]
    lines.append("| " + " | ".join(header_cells) + " |")

    # Separator
    sep_cells = ["-" * col_widths[i] for i in range(len(headers))]
    lines.append("|-" + "-|-".join(sep_cells) + "-|")

    # Data rows
    for row in table_data:
        row_cells = []
        for i in range(len(headers)):
            cell = str(row[i]) if i < len(row) else ""
            row_cells.append(visual_pad(cell, col_widths[i]))
        lines.append("| " + " | ".join(row_cells) + " |")

    return "\n".join(lines)
