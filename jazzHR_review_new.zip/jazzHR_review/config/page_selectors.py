# Candidate page selectors
REJECT_BTN_XPATH = "//span[@ng-bind='quickscreenControlComponent.state.rejectText' and normalize-space(text())='Reject']"
DROPPED_OUT_OPTION_XPATH = "//a[normalize-space(text())='Dropped Out']"
ADVANCE_BTN_XPATH = "//span[@ng-bind='quickscreenControlComponent.state.advanceText' and normalize-space(text())='Advance']"
INITIAL_REVIEW_OPTION_XPATH = "//a[normalize-space(text())='1. Initial review']"
CANDIDATE_LINK_XPATH = "//a[contains(@class, 'candidate-list-prospect-name')]"
CANDIDATE_PROFILE_NAME_XPATH = "//h1[contains(@class, 'candidate-name')]"
DROPPED_OUT_LABEL_XPATH = "//span[@data-test='workflow-step-dropdown-button' and normalize-space(text())='Dropped Out']"
INITIAL_REVIEW_LABEL_XPATH = "//span[@data-test='workflow-step-dropdown-button' and normalize-space(text())='1. Initial review']"
