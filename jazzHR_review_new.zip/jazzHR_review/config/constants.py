# === Gemini Model ===
GEMINI_MODEL = "gemini-2.0-flash"

# === Resume Evaluation Thresholds ===
DEFAULT_SCORE_THRESHOLD = 3
DEFAULT_E_LEVEL_THRESHOLD = 1.3

# === Resume Directories ===
BASE_RESUME_DIR = "resume_data"
RESUME_DIR = f"{BASE_RESUME_DIR}/candidate_resumes"
RESUME_CONTENT_DIR = f"{BASE_RESUME_DIR}/candidate_resume_content"
RESUME_JSON_TEXT_DIR = f"{BASE_RESUME_DIR}/resume_json_text"
CANDIDATES_CSV_FILE = f"{BASE_RESUME_DIR}/candidates.csv"

# === BASE URLs ===
JAZZHR_API_BASE_URL = "https://api.resumatorapi.com/v1"
JAZZHR_WEB_BASE_URL = "https://app.jazz.co"

# === Auth Configs ===
OKTA_DOMAIN = "https://lotusflare.okta.com"
JAZZHR_OKTA_REDIRECT_URL = (
    "https://lotusflare.okta.com/home/jazz/0oa5g7whumiSRwG8h697/58537"
)
OKTA_USERNAME = "infra-oncall@lotusflare.com"
ENCRYPTION_KEY = b"m0FoUHpZ-Sz3ZaRjC8w_qEufExFZe8p1ZY6lRvHMUJs="

# === Admin Configs ===
ADMIN_EMAILS = ["kartik.binagekar@lotusflare.com"]

# === Log Configs ===
LOG_PATH = "jazzHR_review.log"

# List of rejection statuses for historical duplicates
REJECTION_STATUSES = {
    "do not meet hiring criterion",
    "wrong cultural fit",
    "high salary expectations",
    "declined offer",
    "failed technical interviews",
    "failed final interview",
    "dropped out",
    "for future follow up",
}
