from job_roles.utils import get_job_role_enum
import logging
import yaml

logger = logging.getLogger(__name__)


def load_config(config_path):
    """Load configuration from config.yaml"""
    logger.info(f"Loading config file from: {config_path}")
    try:
        with open(config_path, "r") as file:
            config = yaml.safe_load(file)
        logger.info("Config file loaded successfully.")
        return config
    except FileNotFoundError:
        logger.error(f"Config file {config_path} not found.")
        raise
    except yaml.YAMLError as e:
        logger.error(f"Error parsing the config file: {e}")
        raise


# Load configuration at startup
CONFIG = load_config("/config/config.yaml")

# Load Job configuration
JOB_CONFIG = get_job_role_enum(CONFIG)
JOB_ID = JOB_CONFIG.job_id
JOB_URL_ID = JOB_CONFIG.job_url_id
JOB_ROLE_DEFINATION_FILE_PATH = JOB_CONFIG.json_path
ACCEPTABLE_LOCATIONS = JOB_CONFIG.acceptable_locations

# Use configuration values
API_KEY = CONFIG.get("API_KEY")
GEMINI_API_KEY = CONFIG.get("GEMINI_API_KEY")
ENCRYPTED_PASSWORD = CONFIG.get("ENCRYPTED_PASSWORD")
SLACK_BOT_TOKEN = CONFIG.get("SLACK_BOT_TOKEN")

JOB_ROLE_TITLE = CONFIG.get("ROLE")
JOB_CITY_LOCATION = CONFIG.get("CITY")

CUSTOM_PROMPT = CONFIG.get("CUSTOM_PROMPT")
REPORT_EMAIL = CONFIG.get("REPORT_EMAIL")
