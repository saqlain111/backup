import logging

logger = logging.getLogger(__name__)


def log_experience_evaluation(experience_details: dict):
    """Log experience evaluation results in structured format"""
    if not experience_details:
        logger.info("Experience check: No details available")
        return

    total_months = experience_details.get("total_months", 0)
    total_years = experience_details.get("total_years", 0)
    threshold_months = experience_details.get("threshold_months", 0)
    threshold_years = experience_details.get("threshold_years", 0)

    # Determine if passed based on comparison
    is_acceptable = total_months >= threshold_months

    # Determine status and icon
    if is_acceptable:
        icon = "✅"
        status = "PASS"
    else:
        icon = "❌"
        status = "FAIL"

    logger.info(f"Experience evaluation: {icon} - {status}")

    # Log main metrics
    logger.info(f"  📊 Experience Summary:")
    logger.info(f"    - Total experience: {total_months} months ({total_years} years)")
    logger.info(
        f"    - Required threshold: {threshold_months} months ({threshold_years} years)"
    )

    # Show gap or excess
    gap_months = threshold_months - total_months
    if gap_months > 0:
        gap_years = round(gap_months / 12, 1)
        logger.info(f"    - Experience gap: {gap_months} months ({gap_years} years)")
    else:
        excess_months = total_months - threshold_months
        excess_years = round(excess_months / 12, 1)
        logger.info(
            f"    - Experience excess: {excess_months} months ({excess_years} years)"
        )

    # Log job processing details
    processed_jobs = experience_details.get("processed_jobs", 0)
    logger.info(f"  💼 Jobs processed: {processed_jobs}")

    # Log processing errors if any
    processing_errors = experience_details.get("processing_errors", [])
    if processing_errors:
        logger.info(f"  ⚠️ Processing issues ({len(processing_errors)}):")
        for i, error in enumerate(processing_errors, 1):
            logger.info(f"    {i}. {error}")

    # Calculate experience level categorization
    years = total_years
    if years < 1:
        level = "Entry Level"
        level_icon = "🌱"
    elif years < 3:
        level = "Junior"
        level_icon = "📈"
    elif years < 5:
        level = "Mid-Level"
        level_icon = "🎯"
    elif years < 8:
        level = "Senior"
        level_icon = "🏆"
    else:
        level = "Expert/Lead"
        level_icon = "🎖️"

    logger.info(f"  {level_icon} Experience Level: {level}")
