import logging

logger = logging.getLogger(__name__)


def log_education_evaluation(education_details: dict):
    """Log education evaluation results in structured format"""
    if not education_details:
        logger.info("Education check: No details available")
        return

    qualification_status = education_details.get("qualification_status")
    reason = education_details.get("reason", "")
    education_data = education_details.get("education_data", [])

    # Main status
    if qualification_status is True:
        if "warning" in education_details or "error" in education_details:
            icon = "⚠️"
            status = "PASS (with warning)"
        else:
            icon = "✅"
            status = "PASS"
    elif qualification_status is False:
        icon = "❌"
        status = "FAIL"
    else:
        icon = "❓"
        status = "UNKNOWN"

    logger.info(f"Education evaluation: {icon} - {status}")

    # Log reason
    if reason:
        logger.info(f"  📝 Reason: {reason}")

    # Log education data found
    if education_data:
        logger.info(f"  🎓 Education entries found: {len(education_data)}")
        for i, edu in enumerate(education_data, 1):
            # Handle different field name variations
            degree = edu.get("degree", "Unknown")
            field = edu.get("field_of_study") or edu.get("field", "Unknown")
            institution = edu.get("institution") or edu.get("university", "Unknown")

            # Add graduation year if available
            grad_year = ""
            if edu.get("end_year"):
                grad_year = f" ({edu.get('end_year')})"
            elif edu.get("graduation_year"):
                grad_year = f" ({edu.get('graduation_year')})"

            if field and field != "Unknown" and field:
                logger.info(
                    f"    {i}. {degree} in {field} from {institution}{grad_year}"
                )
            else:
                logger.info(f"    {i}. {degree} from {institution}{grad_year}")
    else:
        logger.info(f"  🎓 Education entries found: 0")

    # Log Gemini analysis if available
    gemini_analysis = education_details.get("gemini_analysis", {})
    if gemini_analysis and isinstance(gemini_analysis, dict):
        logger.info(f"  🤖 AI Analysis:")

        highest_degree = gemini_analysis.get("highest_degree", "Unknown")
        relevant_field = gemini_analysis.get("relevant_field", "Unknown")
        confidence = gemini_analysis.get("confidence", "Unknown")

        logger.info(f"    - Highest degree identified: {highest_degree}")
        logger.info(f"    - Relevant field: {relevant_field}")
        logger.info(f"    - Confidence level: {confidence}")

        # Show qualifying degree if available
        qualifying_degree = gemini_analysis.get("qualifying_degree")
        if qualifying_degree:
            logger.info(f"    - Qualifying degree: {qualifying_degree}")

        detailed_analysis = gemini_analysis.get("detailed_analysis")
        if detailed_analysis and detailed_analysis != "No detailed analysis provided":
            logger.info(f"    - Analysis: {detailed_analysis}")

    # Log warnings or errors
    if "warning" in education_details:
        logger.info(f"  ⚠️ Warning: {education_details['warning']}")

    if "error" in education_details:
        logger.info(f"  ❌ Error: {education_details['error']}")
