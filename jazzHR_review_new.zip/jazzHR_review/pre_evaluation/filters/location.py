from config.env_config import ACCEPTABLE_LOCATIONS
from typing import Dict, Tuple


def location_filter(
    candidate_data: Dict,
    structured_resume: Dict,
) -> Tuple[bool, str, Dict]:
    """
    Check if candidate's location is acceptable based on multiple data sources.
    Returns tuple: (is_acceptable, failure_reason, field_results)
    """
    # Normalize acceptable locations for case-insensitive matching
    normalized_locations = [loc.strip().lower() for loc in ACCEPTABLE_LOCATIONS]
    field_results = {}
    any_match = False
    all_fields_empty = True
    any_field_empty = False

    # Helper function to safely handle values
    def safe_value(value):
        """Convert None to empty string and ensure string type"""
        if value is None:
            return ""
        return str(value).strip()

    # 1. Check JazzHR candidate data fields
    jazz_fields = {
        "address": safe_value(candidate_data.get("address")),
        "location": safe_value(candidate_data.get("location")),
        "questionnaire": "",
    }

    # Extract location from questionnaire
    for q in candidate_data.get("questionnaire", []):
        if "current location" in q.get("question", "").lower():
            jazz_fields["questionnaire"] = safe_value(q.get("answer"))
            break

    # Check each JazzHR field
    for field, value in jazz_fields.items():
        # Use safe_value to ensure string type and handle None
        value = safe_value(value)
        if value:  # Field has content
            all_fields_empty = False
            value_lower = value.lower()
            match = any(loc in value_lower for loc in normalized_locations)
            field_results[f"jazz_{field}"] = {
                "match": match,
                "value": value,
                "reason": "Match found" if match else "No acceptable location found",
            }
            any_match = any_match or match
        else:
            any_field_empty = True
            field_results[f"jazz_{field}"] = {"match": False, "reason": "Field empty"}

    # 2. Check structured resume fields
    resume_fields = {
        "basic_info_location": safe_value(
            structured_resume.get("basic_info", {}).get("location")
        ),
        "current_work_location": "",
    }

    # Extract current work location (first job in work experience)
    work_experience = structured_resume.get("work_experience", [])
    if work_experience:
        resume_fields["current_work_location"] = safe_value(
            work_experience[0].get("location")
        )

    # Check each resume field
    for field, value in resume_fields.items():
        # Use safe_value to ensure string type and handle None
        value = safe_value(value)
        if value:  # Field has content
            all_fields_empty = False
            value_lower = value.lower()
            match = any(loc in value_lower for loc in normalized_locations)
            field_results[f"resume_{field}"] = {
                "match": match,
                "value": value,
                "reason": "Match found" if match else "No acceptable location found",
            }
            any_match = any_match or match
        else:
            any_field_empty = True
            field_results[f"resume_{field}"] = {"match": False, "reason": "Field empty"}

    # Determine final result based on requirements
    if any_match:
        # At least one field matched - success
        return True, "", field_results
    elif all_fields_empty:
        # All fields were empty - location not found
        return False, "Location not found in any field", field_results
    elif any_field_empty:
        # At least one field is empty - benefit of doubt
        return (
            True,
            "Location inconclusive - giving benefit of doubt due to empty fields",
            field_results,
        )
    else:
        # All fields have content but none match - rejection
        return (
            False,
            "Current location doesn't match ACCEPTABLE_LOCATIONS",
            field_results,
        )
