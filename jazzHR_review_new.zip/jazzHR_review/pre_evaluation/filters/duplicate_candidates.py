import logging
from typing import Dict, Tuple
from utils.duplicate_checker import detect_latest_duplicate

logger = logging.getLogger(__name__)


def filter_duplicates(
    candidate_data: dict,
    prospect_id: str,
) -> Tuple[bool, str, Dict]:
    """
    Per-candidate duplicate filter. Returns detailed duplicate check information.

    Returns tuple:
      (is_unique, failure_reason, details)
    """
    # Extract relevant fields with defaults
    first_name = candidate_data.get("first_name", "")
    last_name = candidate_data.get("last_name", "").strip()
    email = candidate_data.get("email", "")
    phone = candidate_data.get("prospect_phone") or candidate_data.get("phone", "")

    # Prepare base details dictionary
    details = {
        "status": "unique",
        "prospect_id": prospect_id,
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "phone": phone,
    }

    # Check for duplicates
    dup = detect_latest_duplicate(current_candidate_data=candidate_data)
    if not dup:
        return True, "Unique candidate", details

    # Handle duplicate case
    details.update(
        {
            "status": "duplicate",
            "duplicate_of": dup["duplicate_of"],
            "duplicate_type": dup["duplicate_type"],
            "match_type": dup["match_type"],
            "prospect_id": prospect_id,
            "matched_candidate": dup.get("matched_candidate", {}),
            "current_candidate": dup.get("current_candidate", {}),
            "apply_date": dup["apply_date"],
            "processing_decision": dup.get("processing_decision", {}),
            "resume_comparison": dup.get("resume_comparison", {}),
        }
    )

    processing_decision = dup.get("processing_decision", {})
    action = processing_decision.get("action", "reject")

    if action == "warn_and_process":
        # Allow processing to continue with warning
        failure_reason = f"Duplicate candidate ({dup['duplicate_type']}) - matched by {dup['match_type']} - PROCESSING ALLOWED"
        logger.warning(f"WARN_AND_PROCESS: {prospect_id} → {failure_reason}")
        return True, failure_reason, details  # ✅ Return True to allow processing
    else:
        # Reject processing
        failure_reason = f"Duplicate candidate ({dup['duplicate_type']}) - matched by {dup['match_type']}"
        logger.debug(f"REJECT: {prospect_id} → {failure_reason}")
        return False, failure_reason, details  # ❌ Return False to reject
