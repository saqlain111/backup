import logging
from datetime import datetime
from typing import Dict, Tuple, List

from resume_analysis.education_evaluator import evaluate_education_with_gemini

logger = logging.getLogger(__name__)


def education_filter(
    structured_resume: Dict,
) -> Tuple[bool, str, Dict]:
    """
    Check if candidate's education meets requirements using Gemini AI.
    Requirements: Bachelor's in Engineering OR Master's in Engineering/Computer related fields
    Returns tuple: (is_acceptable, failure_reason, field_results)
    """

    field_results = {}

    # Extract education information
    education_data = extract_education_info(structured_resume)

    # If no education data found, pass with warning
    if not education_data or all(not any(edu.values()) for edu in education_data):
        field_results = {
            "education_data": education_data,
            "warning": "No education information found - passing candidate with warning",
            "qualification_status": True,
            "reason": "Education section empty - benefit of doubt given",
        }
        logger.warning("Education filter: No education data found, passing candidate")
        return True, "Education section empty - benefit of doubt given", field_results

    # Use Gemini to evaluate education
    try:
        is_qualified, reason, analysis = evaluate_education_with_gemini(education_data)

        # Handle low confidence scenarios - give benefit of doubt
        confidence = (
            analysis.get("confidence", "medium")
            if isinstance(analysis, dict)
            else "medium"
        )

        if not is_qualified and confidence == "low":
            # Check if this is a case where we should give benefit of doubt
            should_pass_with_warning = _should_give_benefit_of_doubt(
                analysis, education_data
            )

            if should_pass_with_warning:
                warning_reason = (
                    f"Low confidence evaluation - {reason} - giving benefit of doubt"
                )
                field_results = {
                    "education_data": education_data,
                    "gemini_analysis": analysis,
                    "qualification_status": True,
                    "reason": warning_reason,
                    "warning": "Low confidence - benefit of doubt given",
                    "original_rejection_reason": reason,
                }
                logger.warning(
                    f"Education filter: Low confidence rejection converted to warning - {warning_reason}"
                )
                return True, warning_reason, field_results

        field_results = {
            "education_data": education_data,
            "gemini_analysis": analysis,
            "qualification_status": is_qualified,
            "reason": reason,
        }
        return is_qualified, reason if not is_qualified else "", field_results

    except Exception as e:
        logger.error(f"Error evaluating education with Gemini: {str(e)}")
        # If Gemini fails, pass with warning rather than reject
        field_results = {
            "education_data": education_data,
            "error": f"Gemini evaluation failed: {str(e)}",
            "warning": "Technical error - passing candidate with warning",
            "qualification_status": True,
            "reason": "Technical error in evaluation - benefit of doubt given",
        }
        return (
            True,
            "Technical error in evaluation - benefit of doubt given",
            field_results,
        )


def _should_give_benefit_of_doubt(analysis: Dict, education_data: List[Dict]) -> bool:
    """
    Determine if a low-confidence rejection should be converted to a warning.
    Give benefit of doubt in cases where information is incomplete but potentially qualifying.
    """
    if not isinstance(analysis, dict):
        return True  # If analysis format is unexpected, give benefit of doubt

    rejection_category = analysis.get("rejection_category", "")
    highest_degree = analysis.get("highest_degree", "").lower()

    # Cases where we should give benefit of doubt:

    # 1. Bachelor of Engineering with unspecified field (could be computer-related)
    if (
        rejection_category == "no_qualifying_degree"
        and "bachelor" in highest_degree
        and any(
            "engineering" in str(edu.get("degree", "")).lower()
            or "engineering" in str(edu.get("education_level", "")).lower()
            for edu in education_data
        )
    ):
        return True

    # 2. Master's degree with unspecified field (could be computer-related)
    if (
        rejection_category == "no_qualifying_degree"
        and "master" in highest_degree
        and any(
            any(
                term in str(edu.get("degree", "")).lower()
                or term in str(edu.get("education_level", "")).lower()
                for term in ["master", "m.tech", "m.e", "m.s", "msc"]
            )
            for edu in education_data
        )
    ):
        return True

    # 3. Incomplete information scenarios where degree level is appropriate
    if rejection_category == "no_qualifying_degree" and any(
        term in highest_degree for term in ["bachelor", "master", "phd"]
    ):
        return True

    # 4. Any scenario where we have potential engineering/computer education but field unclear
    has_potential_qualifying_terms = any(
        any(
            term in str(edu_info).lower()
            for term in [
                "engineering",
                "engineer",
                "computer",
                "technology",
                "tech",
                "science",
            ]
        )
        for edu_info in education_data
    )

    if has_potential_qualifying_terms and rejection_category == "no_qualifying_degree":
        return True

    # Don't give benefit of doubt for clear rejections:
    clear_rejection_categories = [
        "bca_degree",
        "diploma_only",
        "non_engineering_bachelors",
        "non_computer_masters",
    ]

    if rejection_category in clear_rejection_categories:
        return False

    # Default to giving benefit of doubt for low confidence cases
    return True


def extract_education_info(structured_resume: Dict) -> List[Dict]:
    """Extract and structure education information from resume, handling multiple degrees"""
    education_list = structured_resume.get("education", [])

    structured_education = []

    # Process education list with enhanced filtering
    for edu in education_list:
        edu_info = {
            "institution": edu.get("institution", ""),
            "degree": edu.get("degree", ""),
            "field_of_study": edu.get("field_of_study", ""),
            "start_year": edu.get("start_year", ""),
            "end_year": edu.get("end_year", ""),
            "education_level": edu.get("education_level", ""),
            "description": edu.get("description", ""),
        }

        # Only add if at least one field has meaningful content
        if any(str(value).strip() for value in edu_info.values()):
            # Add priority scoring for later evaluation
            edu_info["_priority"] = _calculate_education_priority(edu_info)
            structured_education.append(edu_info)

    # Also check basic_info for education level and major
    basic_info = structured_resume.get("basic_info", {})
    if basic_info.get("education_level") or basic_info.get("majors"):
        basic_edu_info = {
            "education_level": basic_info.get("education_level", ""),
            "field_of_study": basic_info.get("majors", ""),
            "graduation_year": basic_info.get("graduation_year", ""),
            "university": basic_info.get("university", ""),
            "degree": basic_info.get("education_level", ""),
            "source": "basic_info",
        }
        # Only add if at least one field has meaningful content and not duplicate
        if any(str(value).strip() for value in basic_edu_info.values()):
            basic_edu_info["_priority"] = _calculate_education_priority(basic_edu_info)
            structured_education.append(basic_edu_info)

    # Sort by priority (highest first) to help Gemini focus on most relevant degrees
    structured_education.sort(key=lambda x: x.get("_priority", 0), reverse=True)

    # Remove priority field before returning (internal use only)
    for edu in structured_education:
        edu.pop("_priority", None)

    return structured_education


def _calculate_education_priority(edu_info: Dict) -> int:
    """Calculate priority score for education entry with strict qualification focus"""
    priority = 0
    degree = str(edu_info.get("degree", "")).lower()
    field = str(edu_info.get("field_of_study", "")).lower()
    education_level = str(edu_info.get("education_level", "")).lower()

    combined_text = f"{degree} {field} {education_level}".lower()

    # Higher education levels get higher priority
    if any(term in combined_text for term in ["phd", "doctorate", "doctoral"]):
        priority += 100
    elif any(
        term in combined_text
        for term in ["master", "m.tech", "m.e", "m.s", "msc", "m-tech", "mca"]
    ):
        priority += 80
        # Extra priority for Master's in computer/IT fields (since they can qualify)
        if any(
            term in combined_text
            for term in [
                "computer",
                "information technology",
                "software",
                "data science",
                "cybersecurity",
                "artificial intelligence",
                "machine learning",
            ]
        ):
            priority += 20
    elif any(
        term in combined_text
        for term in [
            "bachelor",
            "b.tech",
            "b.e",
            "b.s",
            "bsc",
            "b-tech",
            "undergraduate",
        ]
    ):
        priority += 60
        # ONLY Engineering Bachelor's get priority boost
        if any(term in combined_text for term in ["engineering", "engineer"]):
            priority += 30
        # BCA gets deprioritized (will be rejected anyway)
        elif (
            "bca" in combined_text
            or "bachelor of computer applications" in combined_text
        ):
            priority -= 20
    elif any(term in combined_text for term in ["diploma"]):
        priority += 20  # Lower priority, will be rejected anyway

    # Engineering fields get priority boost (for Bachelor's)
    if any(term in combined_text for term in ["engineering", "engineer"]) and not any(
        term in combined_text for term in ["diploma"]
    ):
        priority += 25

    # Computer/IT fields get priority boost ONLY for Master's level
    is_masters = any(
        term in combined_text
        for term in ["master", "m.tech", "m.e", "m.s", "msc", "m-tech", "mca"]
    )
    if is_masters and any(
        term in combined_text
        for term in [
            "computer",
            "information technology",
            "software",
            "cybersecurity",
            "data science",
        ]
    ):
        priority += 25

    # Reduce priority for clearly non-qualifying education
    if any(
        term in combined_text
        for term in ["hsc", "ssc", "high school", "secondary", "12th", "10th"]
    ):
        priority -= 50

    # Reduce priority for non-engineering bachelor's (will be rejected)
    if any(
        term in combined_text
        for term in ["bachelor", "b.tech", "b.e", "b.s", "bsc", "b-tech"]
    ) and not any(term in combined_text for term in ["engineering", "engineer"]):
        priority -= 30

    # Recent education gets slight priority boost
    end_year = edu_info.get("end_year", "")
    if end_year and str(end_year).isdigit():
        current_year = datetime.now().year
        year_diff = current_year - int(end_year)
        if year_diff <= 5:
            priority += 10
        elif year_diff <= 10:
            priority += 5

    return max(priority, 0)  # Don't allow negative priorities
