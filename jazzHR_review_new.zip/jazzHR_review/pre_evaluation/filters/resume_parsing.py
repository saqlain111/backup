from typing import Dict, Tuple


def document_parsing_filter(extracted_content: dict) -> Tuple[bool, str, Dict]:
    """
    Check if document extraction encountered errors (like image-only PDFs)
    that would prevent proper analysis. Always returns detailed parsing info.

    Returns tuple: (is_acceptable, failure_reason, details)
    """
    details = {
        "status": "success",
        "char_count": len(extracted_content.get("text", "").strip()),
        "error": extracted_content.get("error", ""),
        "source": extracted_content.get("source", "document"),
    }

    # Check for explicit error message
    if details["error"]:
        details["status"] = "error"
        return False, "Resume parsing failed", details

    # Check for insufficient text
    if details["char_count"] < 100:
        details["status"] = "insufficient_text"
        details["reason"] = f"Insufficient text ({details['char_count']} chars)"
        return False, details["reason"], details

    # Document is parsable - add success metrics
    details["hyperlink_count"] = len(extracted_content.get("hyperlinks", []))
    return True, "Resume parsed successfully", details
