from utils.calculate_total_experience import (
    calculate_total_experience_months,
    parse_job_experience_format,
)

from config.constants import DEFAULT_EXPERIENCE_THRESHOLD_IN_MONTHS


def experience_filter(
    structured_resume, experience_threshold=DEFAULT_EXPERIENCE_THRESHOLD_IN_MONTHS
):
    """
    Filters candidate based on total experience.
    Returns (is_acceptable, reason, details)
    """
    work_experience = structured_resume.get("work_experience", [])

    # Handle both your job format and standard format automatically
    if work_experience and isinstance(work_experience[0], dict):
        # Check if it's your format (has 'duration' field)
        if "duration" in work_experience[0]:
            work_experience = parse_job_experience_format(work_experience)

    # Calculate experience - handle the enhanced return format
    result = calculate_total_experience_months(work_experience)
    total_months = result.get("total_months", 0) if isinstance(result, dict) else result

    # Create details with both months and years for clarity
    details = {
        "total_months": total_months,
        "total_years": round(total_months / 12, 1),
        "threshold_months": experience_threshold,
        "threshold_years": round(experience_threshold / 12, 1),
        "processed_jobs": (
            result.get("processed_jobs", len(work_experience))
            if isinstance(result, dict)
            else len(work_experience)
        ),
    }

    # Add errors if any occurred during processing
    if isinstance(result, dict) and result.get("errors"):
        details["processing_errors"] = result["errors"]

    if total_months < experience_threshold:
        reason = f"Insufficient experience: {total_months} months ({details['total_years']} years) < {experience_threshold} months ({details['threshold_years']} years)"
        return False, reason, details

    reason = f"Meets experience requirement: {total_months} months ({details['total_years']} years)"
    return True, reason, details
