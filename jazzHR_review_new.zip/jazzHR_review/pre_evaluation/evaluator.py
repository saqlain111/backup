import logging

from pre_evaluation.filters.duplicate_candidates import filter_duplicates
from pre_evaluation.filters.location import location_filter
from pre_evaluation.filters.resume_parsing import document_parsing_filter

logger = logging.getLogger(__name__)


def pre_evaluate_candidate(
    candidate_data: dict,
    extracted_content: dict,
    structured_resume: dict,
    prospect_id: str,
) -> dict:
    """
    Run pre-evaluation checks in this order:
      1. Location filter
      2. Duplicate filter (only if location passed)
    Returns a result dict with:
      - passed: bool
      - filtered: bool
      - reasons: list[str]
      - prospect_id: str
      - location_details: dict
      - duplicate_candidate_details: dict
    """

    """Run all pre-evaluation checks with detailed location and parsing analysis"""
    results = {
        "passed": True,
        "reasons": [],
        "prospect_id": prospect_id,
        "location_details": {},
        "parsing_details": {},
        "filtered": False,
        "duplicate_candidate_details": {},
    }

    # 1. First run document parsing check - if it fails, skip all other checks
    (parsing_acceptable, parsing_reason, parsing_details) = document_parsing_filter(
        extracted_content
    )

    results["parsing_details"] = parsing_details

    if not parsing_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(parsing_reason)
        return results

    # 2. Only run location check if document parsing passed
    loc_acceptable, loc_reason, loc_details = location_filter(
        candidate_data,
        structured_resume,
    )
    results["location_details"] = loc_details

    if not loc_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(loc_reason)
        return results

    # 3. Only run duplicate check if location passed
    is_unique, dup_reason, dup_details = filter_duplicates(
        candidate_data,
        prospect_id,
    )
    results["duplicate_candidate_details"] = dup_details

    if not is_unique:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(dup_reason)
        return results

    return results
