import logging

from pre_evaluation.filters.duplicate_candidates import filter_duplicates
from pre_evaluation.filters.location import location_filter
from pre_evaluation.filters.resume_parsing import document_parsing_filter
from pre_evaluation.filters.experience import experience_filter
from pre_evaluation.filters.education import education_filter

logger = logging.getLogger(__name__)


def pre_evaluate_candidate(
    candidate_data: dict,
    extracted_content: dict,
    structured_resume: dict,
    prospect_id: str,
) -> dict:
    """
    Run pre-evaluation checks in this order:
      1. Document parsing filter
      2. Location filter (only if parsing passed)
      3. Duplicate filter (only if location passed)
      4. Education filter (only if duplicate passed)
      5. Experience filter (only if education passed)

    Returns a result dict with:
      - passed: bool
      - filtered: bool
      - reasons: list[str]
      - prospect_id: str
      - location_details: dict
      - education_details: dict
      - parsing_details: dict
      - duplicate_candidate_details: dict
    """

    results = {
        "passed": True,
        "reasons": [],
        "prospect_id": prospect_id,
        "location_details": {},
        "experience_details": {},
        "education_details": {},
        "parsing_details": {},
        "duplicate_candidate_details": {},
        "filtered": False,
    }

    # 1. First run document parsing check - if it fails, skip all other checks
    (parsing_acceptable, parsing_reason, parsing_details) = document_parsing_filter(
        extracted_content
    )

    results["parsing_details"] = parsing_details

    if not parsing_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(parsing_reason)
        return results

    # 2. Only run location check if document parsing passed
    loc_acceptable, loc_reason, loc_details = location_filter(
        candidate_data,
        structured_resume,
    )
    results["location_details"] = loc_details

    if not loc_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(loc_reason)
        return results

    # 3. Only run duplicate check if location passed
    is_unique, dup_reason, dup_details = filter_duplicates(
        candidate_data,
        prospect_id,
    )
    results["duplicate_candidate_details"] = dup_details

    if not is_unique:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(dup_reason)
        return results

    # 4. Only run education check if duplicate passed
    edu_acceptable, edu_reason, edu_details = education_filter(
        structured_resume,
    )
    results["education_details"] = edu_details

    if not edu_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(edu_reason)
        return results

    # 5. Only run experience check if education passed
    exp_acceptable, exp_reason, exp_details = experience_filter(
        structured_resume,
    )
    results["experience_details"] = exp_details

    if not exp_acceptable:
        results["passed"] = False
        results["filtered"] = True
        results["reasons"].append(exp_reason)
        return results

    return results
