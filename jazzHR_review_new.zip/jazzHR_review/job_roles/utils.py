from job_roles.job_role_enum import JobRole

def make_role_enum_key(config: dict) -> str:
    def normalize(s):
        return s.strip().upper().replace("-", "_").replace(" ", "_")
    return "_".join([normalize(config["ROLE"]), normalize(config["CITY"]), normalize(config["COUNTRY"])])


def get_job_role_enum(config: dict) -> JobRole:
    key = make_role_enum_key(config)
    try:
        return JobRole[key]
    except KeyError:
        raise ValueError(f"No job role enum found for key: {key}")
