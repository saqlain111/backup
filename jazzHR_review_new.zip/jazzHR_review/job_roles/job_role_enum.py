from enum import Enum
from pathlib import Path


class JobRole(Enum):
    DEVOPS_SITE_RELIABILITY_ENGINEER_PUNE_INDIA = {
        "role": "devops_site_reliability_engineer",
        "job_id": "job_20250606191347_4YNDE2PKDYP04UQY",
        "job_url_id": "10046387",
        "acceptable_locations": ["Pune"],
    }
    # SRE_NYC_USA = {
    #     "role": "sre",
    #     "job_id": 456,
    #     "job_url_id": "site-reliability-engineer",
    #     "acceptable_locations": ["United States", "US", "USA", "New York", "NYC"],
    # }
    # BACKEND_ENGINEER_KYIV_UKRAINE = {
    #     "role": "backend_engineer",
    #     "job_id": 789,
    #     "job_url_id": "backend-engineer-role",
    #     "acceptable_locations": ["Ukraine", "UA", "Kyiv", "Kiev"],
    # }

    def __init__(self, metadata):
        self._metadata = metadata

    @property
    def json_path(self):
        return Path(__file__).parent.parent / "roles" / f"{self._metadata['role']}.json"

    @property
    def job_id(self):
        return self._metadata["job_id"]

    @property
    def job_url_id(self):
        return self._metadata["job_url_id"]

    @property
    def acceptable_locations(self):
        return self._metadata["acceptable_locations"]
