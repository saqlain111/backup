import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

# Mapping for suffix to numeric value
LEVEL_SUFFIX_SCORE = {"Developing": 1, "Established": 2, "Experienced": 3}


def convert_level_to_points(level_str: str) -> str:
    """
    Convert any E-level format to standardized E<digit>.<digit> format.
    Handles both underscore format (E2_Established) and dotted format (E2.2).
    """
    try:
        if not level_str:
            logger.warning("Empty level string provided")
            return "E0.0"

        # Handle dotted format directly (E2.2)
        if "." in level_str:
            parts = level_str.split(".")
            if (
                len(parts) == 2
                and parts[0].startswith("E")
                and parts[0][1:].isdigit()
                and parts[1].isdigit()
            ):
                return level_str  # Already in correct format

        # Handle underscore format (E2_Established)
        if "_" in level_str:
            base, suffix = level_str.split("_", 1)
            if not base.startswith("E") or suffix not in LEVEL_SUFFIX_SCORE:
                logger.warning(f"Invalid underscore format: {level_str}")
                return "E0.0"

            level_num = base[1]  # Get the digit after E
            point_suffix = LEVEL_SUFFIX_SCORE[suffix]
            return f"E{level_num}.{point_suffix}"

        # Handle simple format (E2) - assume Developing
        if level_str.startswith("E") and level_str[1:].isdigit():
            return f"{level_str}.1"

        logger.warning(f"Unrecognized level format: {level_str}")
        return "E0.0"

    except Exception as e:
        logger.error(f"Error converting level '{level_str}': {str(e)}")
        return "E0.0"


def transform_evaluation_to_points(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transform evaluation data to standardized point format.
    Handles both input formats:
    1. Underscore format: {"overall_level": "E2_Established", ...}
    2. Dotted format: {"overall_level": "E2.2", ...}
    """
    try:
        transformed = {
            "overall_level": convert_level_to_points(data.get("overall_level", "")),
            "skill_assessments": {},
            "justification": data.get("justification", ""),
        }

        # Process skill assessments
        for category, subskills in data.get("skill_assessments", {}).items():
            transformed["skill_assessments"][category] = {}
            for skill, level in subskills.items():
                transformed["skill_assessments"][category][skill] = (
                    convert_level_to_points(level)
                )

        return transformed

    except Exception as e:
        logger.error(f"Failed to transform evaluation: {str(e)}")
        raise
