import logging
import json

logger = logging.getLogger(__name__)


def parse_markdown_json(md_string: str) -> dict:
    """
    Extracts and parses JSON content from a Markdown code block string.

    Args:
        md_string (str): The Markdown string containing a code block with JSON.

    Returns:
        dict: Parsed JSON as a dictionary.

    Raises:
        ValueError: If parsing fails due to malformed input or invalid JSON.
    """
    try:
        # Clean and split the input
        lines = [
            line.strip() for line in md_string.strip().splitlines() if line.strip()
        ]

        if len(lines) < 3:
            raise ValueError("Markdown code block is too short to contain valid JSON.")

        # Check for starting and ending code fences
        if not lines[0].startswith("```") or not lines[-1].startswith("```"):
            raise ValueError(
                f"Markdown does not contain valid code fences: found '{lines[0]}' and '{lines[-1]}'."
            )

        # Extract JSON lines (skip the first and last)
        json_content = "\n".join(lines[1:-1])

        # Parse JSON
        parsed_data = json.loads(json_content)
        logger.info("Successfully parsed JSON from Markdown.")
        return parsed_data

    except json.JSONDecodeError as jde:
        logger.error(f"Failed to decode JSON: {jde}\nContent:\n{json_content}")
        raise ValueError("Invalid JSON content.") from jde
    except Exception as e:
        logger.error(f"Error while parsing Markdown JSON: {e}")
        raise
