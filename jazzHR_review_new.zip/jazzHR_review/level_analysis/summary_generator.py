import logging
from loaders.template_loader import load_template

logger = logging.getLogger(__name__)


def generate_evaluation_summary(evaluation_data: dict) -> str:
    """
    Generates a concise evaluation summary from AI-generated JSON.

    Args:
        evaluation_data (dict): AI output in structured format.

    Returns:
        str: Formatted summary string.

    Raises:
        KeyError, ValueError, FileNotFoundError, etc.
    """
    try:
        overall_level = evaluation_data["overall_level"]
        justification = evaluation_data["justification"]
        skills = evaluation_data["skill_assessments"]

        # Build skills breakdown section
        skills_breakdown = ""
        for topic, subtopics in skills.items():
            skills_breakdown += f"\n• {topic}:\n"
            for subtopic, level in subtopics.items():
                display_name = subtopic or "General"
                skills_breakdown += f"  - {display_name}: {level}\n"

        template = load_template("ai_analysis/level_evaluation_summary")
        summary = template.format(
            overall_level=overall_level,
            skills_breakdown=skills_breakdown.strip(),
            justification=justification.strip(),
        )

        logger.info("Successfully generated evaluation summary.")
        return summary

    except KeyError as e:
        logger.error(f"Missing expected key in evaluation data: {e}")
        raise

    except FileNotFoundError as e:
        logger.error(f"Summary template not found: {e}")
        raise

    except Exception as e:
        logger.exception("Unexpected error generating evaluation summary.")
        raise
