import json
import logging

from utils.gemini_client import query_gemini
from loaders.template_loader import load_template
from loaders.prompt_loader import load_prompt

from config.env_config import JOB_ROLE_DEFINATION_FILE_PATH


logger = logging.getLogger(__name__)


def analyze_level_evaluation_with_gemini(
    resume_json_text: str,
) -> str:
    """Analyze level evaluation from resume text using Google's Gemini API."""
    try:
        logger.info("Starting level evaluation with Gemini.")

        with open(JOB_ROLE_DEFINATION_FILE_PATH) as f:
            role_definition_json = json.dumps(json.load(f))
        logger.debug("Loaded job role definition JSON.")

        custom_prompt = load_prompt("level_evaluation")
        logger.debug("Loaded custom prompt template.")

        template = load_template("ai_analysis/level_evaluation_prompt")
        prompt = template.format(
            role_definition=role_definition_json,
            resume_json_text=resume_json_text,
            custom_prompt=custom_prompt,
        )
        logger.debug("Constructed final prompt for Gemini model.")

        # Query Gemini
        response = query_gemini(prompt)
        logger.info("Received response from Gemini.")
        return response.text

    except FileNotFoundError as e:
        logger.error(f"Required file not found: {e}")
        return f"Error: Missing required file - {e}"

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in role definition: {e}")
        return "Error: Could not parse job role definition JSON."

    except Exception as e:
        logger.exception("Unexpected error during level evaluation with Gemini.")
        return f"Error analyzing resume: {str(e)}"
