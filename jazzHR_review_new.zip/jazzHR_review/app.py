import json
import os
import logging
import time

from services.jazzhr_api import fetch_candidates_from_api
from utils.candidate_storage import save_candidate_csv_and_resumes
from utils.resume_downloader import download_and_extract_resumes_from_json_files
from utils.auth import initialize_auth
from workflows.resume_processor import process_candidates
from slack_utils.notifier import send_report_to_recipients
from utils.cleanup import cleanup_files
from config.constants import (
    RESUME_DIR,
    RESUME_CONTENT_DIR,
    RESUME_JSON_TEXT_DIR,
    LOG_PATH,
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[logging.FileHandler(LOG_PATH), logging.StreamHandler()],
)
logger = logging.getLogger(__name__)


def setup_directories():
    """Ensure required directories exist."""
    for directory in [RESUME_DIR, RESUME_CONTENT_DIR, RESUME_JSON_TEXT_DIR]:
        os.makedirs(directory, exist_ok=True)


def run_resume_analysis_pipeline():
    """Run the end-to-end resume analysis pipeline."""
    setup_directories()

    logger.info("===== JazzHR Resume Analyzer Started =====")
    start_time = time.time()

    candidates = fetch_candidates_from_api()
    if not candidates:
        logger.warning("No candidates found. Exiting.")
        return False

    # Show structure of first candidate
    logger.info("Example candidate structure:")
    logger.info(json.dumps(candidates[0], indent=2))

    # Initialize Authentication
    initialize_auth()

    # Save raw data & resume PDFs
    save_candidate_csv_and_resumes(candidates)

    # Extract from any downloaded resume JSONs missed earlier
    download_and_extract_resumes_from_json_files()

    # Process candidate resume content and take action
    process_candidates()

    # Send report to all recipients
    send_results = send_report_to_recipients()

    # Log results
    for email, success in send_results.items():
        if success:
            logger.info(f"Report successfully sent to {email}")
        else:
            logger.error(f"Failed to send report to {email}")

    # Cleanup all intermediate files
    cleanup_files()

    elapsed = time.time() - start_time
    logger.info(f"🎉 JazzHR Resume Analyzer Complete in {elapsed:.2f} seconds")
    return True


def main():
    try:
        return run_resume_analysis_pipeline()
    except Exception as e:
        logger.exception(f"Unhandled error in main: {str(e)}")
        return False


if __name__ == "__main__":
    main()
