import sys
import logging
from typing import List, Dict

from utils.auth import add_auth_cookies_to_browser
from level_analysis.summary_generator import generate_evaluation_summary
from utils.browser_utils import playwright_browser
from workflows.core_browser_actions import handle_candidate_action

from config.constants import JAZZHR_WEB_BASE_URL
from config.env_config import JOB_URL_ID

logger = logging.getLogger(__name__)

# Global report storage
REPORT_DATA = {
    "found_candidates": 0,
    "rejected_candidates": 0,
    "advanced_candidates": 0,
    "pre_filter_rejects": 0,
    "candidate_details": [],
    "success": False,
}


def process_all_candidates_in_browser(
    low_scoring_candidates: List[Dict],
    high_scoring_candidates: List[Dict],
    pre_filter_rejects: List[Dict],
) -> None:
    """Process candidates and update global REPORT_DATA"""
    # Reset global report
    global REPORT_DATA
    REPORT_DATA = {
        "found_candidates": len(low_scoring_candidates)
        + len(high_scoring_candidates)
        + len(pre_filter_rejects),
        "rejected_candidates": len(low_scoring_candidates),
        "advanced_candidates": len(high_scoring_candidates),
        "pre_filter_rejects": len(pre_filter_rejects),
        "candidate_details": [],
        "success": False,
    }

    if (
        not low_scoring_candidates
        and not high_scoring_candidates
        and not pre_filter_rejects
    ):
        logger.info("No candidates to process.")
        return

    logger.info("\n===== Processing Candidates =====")
    logger.info(f"Candidates to reject: {len(low_scoring_candidates)}")
    logger.info(f"Candidates to advance: {len(high_scoring_candidates)}")
    logger.info(f"Pre-filter rejects: {len(pre_filter_rejects)}")

    try:
        with playwright_browser() as (manager, page):
            logger.info("Setting authentication cookies...")
            if not add_auth_cookies_to_browser(page):
                logger.warning("Authentication failed. Aborting browser automation.")
                sys.exit(1)

            candidates_list_url = f"{JAZZHR_WEB_BASE_URL}/app/v2/job/{JOB_URL_ID}/candidate?workflowStep=1"
            page.goto(candidates_list_url, wait_until="load")

            if any(sub in page.url.lower() for sub in ("login", "auth")):
                logger.warning("⚠️ Authentication failed in headless mode. Exiting.")
                sys.exit(1)
            else:
                logger.info("✓ Authentication successful!")

            # Process pre-filter rejects first
            if pre_filter_rejects:
                logger.info("\nProcessing pre-filter rejects...")
                for i, candidate in enumerate(pre_filter_rejects, 1):
                    process_candidate(
                        page,
                        candidate,
                        i,
                        len(pre_filter_rejects),
                        "reject",
                        candidates_list_url,
                    )

            if high_scoring_candidates:
                logger.info("\nProcessing candidates to advance...")
                for i, candidate in enumerate(high_scoring_candidates, 1):
                    process_candidate(
                        page,
                        candidate,
                        i,
                        len(high_scoring_candidates),
                        "advance",
                        candidates_list_url,
                    )

            if low_scoring_candidates:
                logger.info("\nProcessing candidates to reject...")
                for i, candidate in enumerate(low_scoring_candidates, 1):
                    process_candidate(
                        page,
                        candidate,
                        i,
                        len(low_scoring_candidates),
                        "reject",
                        candidates_list_url,
                    )

            REPORT_DATA["success"] = True
            logger.info("\nAll candidates processed successfully.")

    except Exception as e:
        logger.exception(f"Error during browser-based candidate processing: {str(e)}")
        raise


def process_candidate(
    page,
    candidate: Dict,
    index: int,
    total: int,
    action: str,
    candidates_list_url: str,
    max_retries: int = 2,
) -> bool:
    """Process any type of candidate in the browser with the specified action."""
    candidate_name = candidate.get("name", "").replace("_", " ")
    prospect_id = candidate.get("prospect_id")

    # Get evaluation results
    pre_eval = candidate.get("pre_eval_result", {})
    status = "Passed" if pre_eval.get("passed") else "Rejected"
    reasons = ", ".join(pre_eval.get("reasons", ["Pre-filter rejection"]))

    # Extract name for search
    name_parts = candidate_name.split()
    search_name = (
        f"{name_parts[0]} {name_parts[1]}" if len(name_parts) >= 2 else candidate_name
    )
    logger.info("-" * 100)

    # Check candidate type
    if "score" in candidate:
        # Analyzed candidate
        score = candidate.get("score")
        analysis = candidate.get("analysis", "")
        level_evaluation = candidate.get("level_evaluation_analysis", {})
        level_summary = generate_evaluation_summary(level_evaluation)
        level_score = level_evaluation.get("overall_level", "")

        logger.info(
            f"[{index}/{total}] Processing candidate: {search_name} "
            f"(Pre-Filter Status: {status}, Score: {score}, E-Level: {level_score}, Action: {action}, Pre-Filter Rejection Reasons: -)"
        )

        REPORT_DATA["candidate_details"].append(
            {
                "name": search_name,
                "score": score,
                "e_level": level_score,
                "action": action,
                "pre_filter_status": status,
                "rejection_reasons": reasons,
                "is_pre_filter": False,
            }
        )

    else:
        # Pre-filter reject
        logger.info(
            f"[{index}/{total}] Processing candidate: {search_name} "
            f"(Pre-Filter Status: {status}, Score: 0, E-Level: -, Action: {action}, Pre-Filter Rejection Reasons: {reasons})"
        )

        REPORT_DATA["candidate_details"].append(
            {
                "name": search_name,
                "score": 0,
                "e_level": "N/A",
                "action": action,
                "pre_filter_status": status,
                "rejection_reasons": reasons,
                "is_pre_filter": True,
            }
        )

        # Set defaults for pre-filter rejects
        score = None
        analysis = ""
        level_summary = ""

    try:
        return handle_candidate_action(
            page=page,
            search_name=search_name,
            action=action,
            candidates_list_url=candidates_list_url,
            prospect_id=prospect_id,
            score=score,
            analysis=analysis,
            level_summary=level_summary,
            evaluation_result=pre_eval,
            max_retries=max_retries,
        )
    except Exception as e:
        if "score" in candidate:
            logger.warning(f"⚠️ Error processing candidate {candidate_name}: {str(e)}")
        else:
            logger.warning(
                f"⚠️ Error processing pre-filter reject {candidate_name}: {str(e)}"
            )
        return False
