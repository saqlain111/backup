import os
import logging
import json
import re

from level_analysis.gemini_analyzer import analyze_level_evaluation_with_gemini
from resume_analysis.resume_analyzer import analyze_resume_with_gemini
from resume_analysis.structured_extractor import generate_structured_resume
from level_analysis.evaluation_parser import parse_markdown_json
from level_analysis.evaluation_scorer import transform_evaluation_to_points
from workflows.candidate_browser_processor import process_all_candidates_in_browser
from utils.score_extractor import extract_overall_score
from pre_evaluation.evaluator import pre_evaluate_candidate
from pre_evaluation.loggers.education import log_education_evaluation
from pre_evaluation.loggers.experience import log_experience_evaluation

from config.constants import (
    DEFAULT_E_LEVEL_THRESHOLD,
    RESUME_JSON_TEXT_DIR,
    RESUME_CONTENT_DIR,
)

logger = logging.getLogger(__name__)


def _load_candidate_data(json_file: str) -> tuple:
    """Load candidate data from JSON files"""
    file_base = os.path.splitext(json_file)[0]
    file_path = os.path.join(RESUME_JSON_TEXT_DIR, json_file)
    candidate_path = os.path.join(RESUME_CONTENT_DIR, json_file)

    if not os.path.exists(candidate_path):
        logger.warning(f"Candidate data not found in {json_file}")
        return None, None, None

    with open(file_path, "r", encoding="utf-8") as f:
        resume_data = json.load(f)

    with open(candidate_path, "r", encoding="utf-8") as f:
        candidate_data = json.load(f)

    return resume_data, candidate_data, file_base


def _process_resume(resume_text: str, hyperlinks: list, file_base: str) -> dict:
    """Generate and save structured resume data"""
    logger.info("Generating structured resume data...")
    structured_resume = generate_structured_resume(resume_text, hyperlinks)

    structured_path = os.path.join(RESUME_JSON_TEXT_DIR, f"{file_base}_structured.json")
    with open(structured_path, "w", encoding="utf-8") as f:
        json.dump(structured_resume, f, indent=2, ensure_ascii=False)

    return structured_resume


def _log_pre_evaluation(pre_eval_result: dict):
    """Log pre-evaluation results in structured format"""
    logger.info("Pre-evaluation results:")

    # Log parsing details
    parsing_details = pre_eval_result.get("parsing_details", {})
    char_count = parsing_details.get("char_count", "N/A")

    status_icons = {"error": "❌", "insufficient_text": "❌", "success": "✅"}
    status_msg = {
        "error": f"{pre_eval_result['parsing_details'].get('error', 'Unknown error')}",
        "insufficient_text": f"Insufficient text ({char_count} chars)",
        "success": f"Parsable Resume ({char_count} characters)",
    }

    status = parsing_details.get("status")
    icon = status_icons.get(status, "❓")
    msg = status_msg.get(status, "Unknown parsing status")
    logger.info(f"Resume parsing: {icon} - {msg}")

    # Log location details
    logger.info("Location check results:")
    for field, result in pre_eval_result.get("location_details", {}).items():
        if result.get("reason", "") == "Field empty":
            status = "⚠️"
        elif result.get("match", False):
            status = "✅"
        else:
            status = "❌"
        logger.info(f"  {field}: {status} - {result.get('reason', '')}")

    # Log Duplicate details
    dup_details = pre_eval_result.get("duplicate_candidate_details", {})
    logger.info("Duplicate check results:")
    candidate_name = f"{dup_details.get('first_name', '')} {dup_details.get('last_name', '')}".strip()

    if dup_details.get("status") == "duplicate":
        duplicate_of = dup_details.get("duplicate_of", "unknown")
        duplicate_type = dup_details.get("duplicate_type", "unknown")
        match_type = dup_details.get("match_type", "unknown")
        apply_date = dup_details.get("apply_date", "unknown date")

        # Get processing decision with better fallback handling
        processing_decision = dup_details.get("processing_decision", {})
        action = processing_decision.get("action", "reject")

        # Better fallback for decision reason - check if we have enhanced data
        if processing_decision.get("reason"):
            decision_reason = processing_decision.get("reason")
        elif processing_decision.get("date_analysis"):
            # If we have date analysis but no reason, construct one
            decision_reason = f"Enhanced duplicate analysis: {processing_decision.get('date_analysis')}"
        else:
            # True fallback to standard
            decision_reason = "Standard duplicate detection"

        decision_icon = processing_decision.get("icon", "❌")
        date_analysis = processing_decision.get("date_analysis", "")
        job_role_analysis = processing_decision.get("job_role_analysis", "")

        # Get matched candidate details
        matched_candidate = dup_details.get("matched_candidate", {})
        current_candidate = dup_details.get("current_candidate", {})

        # Main duplicate message with processing decision
        reason = f"Duplicate of {duplicate_of} (applied {apply_date}) - Type: {duplicate_type}, Matched by: {match_type}"
        logger.info(f"  {decision_icon} {reason}")
        logger.info(f"  🎯 Processing Decision: {action.upper()} - {decision_reason}")

        # Date analysis (now more prominent since it's checked first)
        if date_analysis:
            logger.info(f"  📅 Date Analysis: {date_analysis}")

        # Job role analysis for interview stage duplicates
        job_role_check = dup_details.get("job_role_check", {})
        if job_role_check and duplicate_type == "interview_stage":
            is_same_job_role = job_role_check.get("is_same_job_role", False)
            job_description = job_role_check.get("description", "")
            matched_job_id = job_role_check.get("matched_job_id", "N/A")
            current_job_id = job_role_check.get("current_job_id", "N/A")

            logger.info(f"  🎯 Job Role Analysis:")
            logger.info(f"    - Same job role: {'Yes' if is_same_job_role else 'No'}")
            logger.info(f"    - Description: {job_description}")
            logger.info(f"    - Matched candidate job ID: {matched_job_id}")
            logger.info(f"    - Current job ID: {current_job_id}")

            if is_same_job_role:
                logger.info(
                    f"    - Impact: ❌ REJECT - Candidate actively interviewing for same position"
                )
            else:
                logger.info(
                    f"    - Impact: ℹ️ Different job role - following date/resume analysis"
                )
        elif job_role_analysis:
            # Fallback if we have job_role_analysis in processing_decision but not full job_role_check
            logger.info(f"  🎯 Job Role Analysis: {job_role_analysis}")

        # Resume comparison details if available - Updated to reflect new logic
        resume_comparison = dup_details.get("resume_comparison", {})
        has_resume_data = bool(resume_comparison)

        if has_resume_data:
            resumes_identical = resume_comparison.get("resumes_identical")
            comparison_result = resume_comparison.get("comparison_result", "")
            current_chars = resume_comparison.get("current_char_count")
            matched_chars = resume_comparison.get("matched_char_count")

            logger.info(f"  📄 Resume Analysis:")

            if resumes_identical is not None:
                # Resume comparison was performed
                logger.info(
                    f"    - Comparison performed: Yes (matched candidate was 6+ months older)"
                )
                logger.info(
                    f"    - Resumes identical: {'Yes' if resumes_identical else 'No'}"
                )
                if current_chars is not None:
                    logger.info(f"    - Current resume: {current_chars} chars")
                if matched_chars is not None:
                    logger.info(f"    - Matched resume: {matched_chars} chars")
                logger.info(f"    - Result: {comparison_result}")
            else:
                # Resume comparison was skipped
                logger.info(f"    - Comparison performed: No")
                logger.info(f"    - Reason: {comparison_result}")
                if (
                    "too recent" in comparison_result.lower()
                    or "skipped" in comparison_result.lower()
                ):
                    logger.info(
                        f"    - Logic: Date check failed - matched candidate not old enough for resume comparison"
                    )
                else:
                    logger.info(f"    - Logic: Resume comparison unavailable or failed")
        else:
            # No resume comparison data available (older logic or same-batch duplicates)
            logger.info(f"  📄 Resume Analysis:")
            logger.info(f"    - Comparison performed: No")
            logger.info(f"    - Reason: No resume comparison data available")
            logger.info(f"    - Logic: Using standard duplicate detection logic")

        # Enhanced details logging
        if matched_candidate:
            matched_status = matched_candidate.get("status", "unknown")
            matched_email = matched_candidate.get("email", "N/A")
            matched_phone = matched_candidate.get("phone", "N/A")
            matched_name = f"{matched_candidate.get('first_name', '')} {matched_candidate.get('last_name', '')}".strip()
            matched_apply_date = matched_candidate.get("apply_date", "N/A")

            logger.info(
                f"  📋 Matched candidate: {matched_name or 'Unknown'} (ID: {duplicate_of})"
            )
            logger.info(f"    - Apply date: {matched_apply_date}")
            logger.info(f"    - Email: {matched_email}")
            logger.info(f"    - Phone: {matched_phone}")
            logger.info(f"    - Status: {matched_status}")

            # Add job ID information for interview stage duplicates
            if duplicate_type == "interview_stage" and job_role_check:
                matched_job_id = job_role_check.get("matched_job_id", "N/A")
                logger.info(f"    - Job ID: {matched_job_id}")

        if current_candidate:
            current_email = current_candidate.get("email", "N/A")
            current_phone = current_candidate.get("phone", "N/A")
            current_status = current_candidate.get("status", "New")
            current_id = current_candidate.get(
                "id", dup_details.get("prospect_id", "unknown")
            )
            current_apply_date = current_candidate.get("apply_date", "N/A")

            logger.info(
                f"  🆕 Current candidate: {candidate_name or 'Unknown'} (ID: {current_id})"
            )
            logger.info(f"    - Apply date: {current_apply_date}")
            logger.info(f"    - Email: {current_email}")
            logger.info(f"    - Phone: {current_phone}")
            logger.info(f"    - Status: {current_status}")

            # Add current job ID information
            if duplicate_type == "interview_stage" and job_role_check:
                current_job_id = job_role_check.get("current_job_id", "N/A")
                logger.info(f"    - Job ID: {current_job_id}")

        # Show what specifically matched
        if match_type == "phone and email":
            logger.info(f"  🔍 Match details: Both phone and email matched")
        elif match_type == "phone":
            logger.info(f"  🔍 Match details: Phone number matched")
        elif match_type == "email":
            logger.info(f"  🔍 Match details: Email address matched")

        # Summary of the new date-first logic flow
        logger.info(f"  🔄 Processing Flow Summary:")

        # Determine date check status from available data
        date_check_passed = False
        resume_comparison_performed = False
        resume_comparison_skipped = False
        job_role_check_performed = False

        # Check if job role analysis was performed
        if job_role_check and duplicate_type == "interview_stage":
            job_role_check_performed = True

        if has_resume_data:
            resumes_identical = resume_comparison.get("resumes_identical")
            comparison_result = resume_comparison.get("comparison_result", "")

            if resumes_identical is not None:
                # Resume comparison was actually performed
                date_check_passed = True
                resume_comparison_performed = True
            elif (
                "too recent" in comparison_result.lower()
                or "skipped" in comparison_result.lower()
            ):
                # Resume comparison was skipped due to date check
                date_check_passed = False
                resume_comparison_skipped = True
        else:
            # No resume comparison data - check processing_decision for date analysis
            if date_analysis:
                if (
                    ">" in date_analysis
                    or "old" in date_analysis.lower()
                    or "months gap" in date_analysis.lower()
                ):
                    # Extract if it passed or failed from the date analysis text
                    if (
                        "<6 months gap" in date_analysis
                        or "Recent duplicate" in decision_reason
                    ):
                        date_check_passed = False
                    elif (
                        ">6 months gap" in date_analysis
                        or "old application" in decision_reason.lower()
                    ):
                        date_check_passed = True
                    else:
                        # Parse the date analysis more carefully
                        date_check_passed = None  # Unknown

        # Log based on what we determined
        if duplicate_type == "same_batch":
            logger.info(f"    1. Date check: ⏭️ N/A (same-batch duplicate)")
            logger.info(f"    2. Job role check: ⏭️ N/A (same-batch duplicate)")
            logger.info(f"    3. Resume comparison: ❌ Not available (same-batch)")
            logger.info(f"    4. Final decision: {action.upper()}")
        elif duplicate_type == "interview_stage":
            # Special handling for interview stage with job role check
            if job_role_check_performed:
                is_same_job_role = job_role_check.get("is_same_job_role", False)
                logger.info(f"    1. Job role check: ✅ Performed")
                logger.info(
                    f"       - Same job role: {'Yes' if is_same_job_role else 'No'}"
                )

                if is_same_job_role:
                    logger.info(
                        f"    2. Date check: ⏭️ Skipped (same job role = auto reject)"
                    )
                    logger.info(
                        f"    3. Resume comparison: ⏭️ Skipped (same job role = auto reject)"
                    )
                    logger.info(
                        f"    4. Final decision: {action.upper()} (Same job role)"
                    )
                else:
                    # Different job role - follow normal flow
                    logger.info(
                        f"    2. Date check: {'✅ Passed' if date_check_passed else '❌ Failed' if date_check_passed is False else '❓ Unknown'}"
                    )

                    if resume_comparison_performed:
                        logger.info(f"    3. Resume comparison: ✅ Performed")
                        resumes_identical = resume_comparison.get("resumes_identical")
                        logger.info(
                            f"    4. Final decision: {action.upper()} ({'Identical resumes' if resumes_identical else 'Different resumes'})"
                        )
                    elif resume_comparison_skipped:
                        logger.info(
                            f"    3. Resume comparison: ⏭️ Skipped (matched candidate too recent)"
                        )
                        logger.info(
                            f"    4. Final decision: {action.upper()} (No resume comparison needed)"
                        )
                    else:
                        logger.info(
                            f"    3. Resume comparison: ❌ Failed or unavailable"
                        )
                        logger.info(f"    4. Final decision: {action.upper()}")
            else:
                # Job role check not performed for interview stage (shouldn't happen but fallback)
                logger.info(f"    1. Job role check: ❌ Not performed")
                logger.info(
                    f"    2. Date check: {'✅ Passed' if date_check_passed else '❌ Failed' if date_check_passed is False else '❓ Unknown'}"
                )
                logger.info(
                    f"    3. Resume comparison: {'✅ Performed' if resume_comparison_performed else '⏭️ Skipped' if resume_comparison_skipped else '❌ Not performed'}"
                )
                logger.info(f"    4. Final decision: {action.upper()}")
        elif has_resume_data:
            # Our enhanced logic was used (historical_rejected)
            logger.info(
                f"    1. Date check: {'✅ Passed' if date_check_passed else '❌ Failed' if date_check_passed is False else '❓ Unknown'}"
            )

            if resume_comparison_performed:
                logger.info(f"    2. Resume comparison: ✅ Performed")
                resumes_identical = resume_comparison.get("resumes_identical")
                logger.info(
                    f"    3. Final decision: {action.upper()} ({'Identical resumes' if resumes_identical else 'Different resumes'})"
                )
            elif resume_comparison_skipped:
                logger.info(
                    f"    2. Resume comparison: ⏭️ Skipped (matched candidate too recent)"
                )
                logger.info(
                    f"    3. Final decision: {action.upper()} (No resume comparison needed)"
                )
            else:
                logger.info(f"    2. Resume comparison: ❌ Failed or unavailable")
                logger.info(f"    3. Final decision: {action.upper()}")
        elif date_analysis:
            # We have date analysis but no resume comparison data
            logger.info(
                f"    1. Date check: {'✅ Passed' if date_check_passed else '❌ Failed' if date_check_passed is False else '❓ Partially analyzed'}"
            )
            logger.info(
                f"    2. Resume comparison: {'⏭️ Skipped' if date_check_passed is False else '❌ Not performed'}"
            )
            logger.info(f"    3. Final decision: {action.upper()}")
        else:
            # Standard logic without our enhanced date/resume checking
            logger.info(f"    1. Date check: ❓ Standard duplicate detection")
            logger.info(f"    2. Resume comparison: ❌ Not performed (standard logic)")
            logger.info(f"    3. Final decision: {action.upper()}")

        logger.debug(f"Full duplicate details: {dup_details}")

    else:
        icon = "✅"
        prospect_id = dup_details.get("prospect_id", "unknown prospect")
        candidate_email = dup_details.get("email", "N/A")
        candidate_phone = dup_details.get("phone", "N/A")

        logger.info(f"  {icon} Unique candidate - Prospect ID: {prospect_id}")
        logger.info(f"    👤 Name: {candidate_name or 'Unknown'}")
        logger.info(f"    📧 Email: {candidate_email}")
        logger.info(f"    📱 Phone: {candidate_phone}")
        logger.info(
            f"  🔄 Processing Flow: No duplicates found - proceeding with normal processing"
        )

    # Log Education details
    logger.info("Education check results:")
    log_education_evaluation(pre_eval_result.get("education_details", {}))

    # Log Experience details
    logger.info("Experience check results:")
    log_experience_evaluation(pre_eval_result.get("experience_details", {}))


def _run_ai_analysis(
    structured_resume: dict, file_base: str, hyperlinks: list, prospect_id: str
) -> tuple:
    """Run AI analysis and save results"""
    logger.info("Running Gemini level evaluation...")
    level_eval_response = analyze_level_evaluation_with_gemini(structured_resume)
    level_eval_json = parse_markdown_json(level_eval_response)
    level_eval_data = transform_evaluation_to_points(level_eval_json)
    overall_level = level_eval_data.get("overall_level", "E1")

    logger.info("Running Gemini resume analysis...")
    resume_analysis = analyze_resume_with_gemini(structured_resume)

    # Save analysis results
    analysis_path = os.path.join(RESUME_JSON_TEXT_DIR, f"{file_base}_analysis.json")
    analysis_data = {
        "analysis": resume_analysis,
        "level_evaluation": level_eval_data,
        "source_file": os.path.basename(analysis_path),
        "hyperlinks": hyperlinks,
        "prospect_id": prospect_id,
        "structured_resume": structured_resume,
    }
    with open(analysis_path, "w", encoding="utf-8") as f:
        json.dump(analysis_data, f, indent=2, ensure_ascii=False)

    return resume_analysis, level_eval_data, overall_level


def _categorize_candidate(
    candidate: dict, overall_score: float, overall_level: str
) -> str:
    """Categorize candidate based on score and level"""
    try:
        e_level_float = float(overall_level[1:])
    except (ValueError, TypeError):
        e_level_float = 0

    if e_level_float <= DEFAULT_E_LEVEL_THRESHOLD:
        return "low_scoring"
    return "high_scoring"


def process_candidates():
    """Analyze resumes and categorize candidates based on AI evaluation."""
    logger.info("===== Starting Resume Processing =====")
    json_files = [
        f
        for f in os.listdir(RESUME_JSON_TEXT_DIR)
        if f.endswith(".json")
        and not (f.endswith("_analysis.json") or f.endswith("_structured.json"))
    ]

    counters = {"successful": 0, "failed": 0}
    categories = {"low_scoring": [], "high_scoring": [], "pre_filter_rejects": []}

    for i, json_file in enumerate(json_files, 1):
        logger.info("-" * 100)
        logger.info(f"[{i}/{len(json_files)}] Analyzing {json_file}...")

        try:
            # Load candidate data
            resume_data, candidate_data, file_base = _load_candidate_data(json_file)
            if not all([resume_data, candidate_data, file_base]):
                counters["failed"] += 1
                continue

            # Process resume
            structured_resume = _process_resume(
                resume_data.get("text", ""),
                resume_data.get("hyperlinks", []),
                file_base,
            )

            # Run pre-evaluation
            prospect_id = _extract_prospect_id(file_base)
            pre_eval_result = pre_evaluate_candidate(
                candidate_data, resume_data, structured_resume, prospect_id
            )
            _log_pre_evaluation(pre_eval_result)

            # Create base candidate record
            candidate = {
                "name": file_base,
                "prospect_id": prospect_id,
                "pre_eval_result": pre_eval_result,
            }

            # Handle pre-filter rejects
            if not pre_eval_result.get("passed", False):
                reasons = ", ".join(pre_eval_result.get("reasons", ["Unknown reason"]))
                logger.warning(f"Pre-evaluation failed: {reasons}")
                categories["pre_filter_rejects"].append(candidate)
                continue

            # Run AI analysis
            resume_analysis, level_eval_data, overall_level = _run_ai_analysis(
                structured_resume,
                file_base,
                resume_data.get("hyperlinks", []),
                prospect_id,
            )

            # Extract score and categorize
            overall_score = extract_overall_score(resume_analysis)
            logger.info(f"Score: {overall_score} | Level: {overall_level}")

            if overall_score is not None:
                candidate.update(
                    {
                        "score": overall_score,
                        "analysis": resume_analysis,
                        "level_evaluation_analysis": level_eval_data,
                    }
                )

                category = _categorize_candidate(
                    candidate, overall_score, overall_level
                )
                categories[category].append(candidate)
                logger.info(
                    f"→ Marked for {'rejection' if category == 'low_scoring' else 'advancement'}"
                )

            counters["successful"] += 1

        except Exception as e:
            logger.exception(f"Failed to analyze {json_file}: {str(e)}")
            counters["failed"] += 1

    # Final summary
    pre_filter_count = len(categories["pre_filter_rejects"])
    logger.info(
        f"✅ Completed: {counters['successful']} successful, "
        f"{pre_filter_count} pre-filter failed, {counters['failed']} failed"
    )

    # Process results
    process_all_candidates_in_browser(
        categories["low_scoring"],
        categories["high_scoring"],
        categories["pre_filter_rejects"],
    )


def _extract_prospect_id(file_base: str) -> str | None:
    """Extract everything from 'prospect_' up to the next underscore-free suffix (or end of ID)."""
    match = re.search(r"(prospect_[^_]+_[^_]+)", file_base)
    return match.group(1) if match else None
