import logging
import re
from playwright.sync_api import Page

from utils.comment_generator import generate_final_comment
from services.jazzhr_api import post_comment_to_jazzhr

from config.page_selectors import (
    REJECT_BTN_XPATH,
    DROPPED_OUT_OPTION_XPATH,
    ADVANCE_BTN_XPATH,
    INITIAL_REVIEW_OPTION_XPATH,
    CANDIDATE_LINK_XPATH,
    CANDIDATE_PROFILE_NAME_XPATH,
    DROPPED_OUT_LABEL_XPATH,
    INITIAL_REVIEW_LABEL_XPATH,
)

logger = logging.getLogger(__name__)


def handle_candidate_action(
    page: Page,
    search_name,
    action,
    candidates_list_url,
    prospect_id,
    score,
    analysis,
    level_summary,
    evaluation_result=None,
    max_retries=2,
    timeout=30000,
    candidate_detail=None,
) -> bool:
    """
    Navigate to a candidate, leave mandatory analysis comment, and perform action sequentially.
    Returns True only if all steps complete successfully.

    Args:
        page: Playwright Page instance
        search_name: Candidate's full name
        action: "advance" or "reject"
        candidates_list_url: URL to go back to candidate list
        prospect_id: ID to comment on
        score: AI score (float)
        analysis: Resume analysis text
        level_summary: E-Level summary string
        evaluation_result: Pre-filter evaluation results (dict)
        max_retries: Number of attempts for retry
        timeout: Timeout in milliseconds for element operations
        candidate_detail: Dict to update with profile URL

    Returns:
        bool: True if all steps completed, False otherwise
    """
    logger.info(f"🚀 Starting candidate processing: '{search_name}' | Action: {action}")
    action = action.lower()  # Normalize action early

    for attempt in range(max_retries + 1):
        try:
            # --- Step 1: Open candidate profile ---
            logger.info(f"[{attempt+1}/{max_retries+1}] Opening candidate profile")
            if not _open_candidate_profile(page, search_name, candidates_list_url):
                logger.error(f"Candidate '{search_name}' not found - terminating")
                return False
            logger.info("Profile opened successfully")

            # --- Capture profile URL after successful opening ---
            profile_url = page.url
            logger.info(f"Candidate profile URL: {profile_url}")

            # Update candidate_detail if provided
            if candidate_detail is not None:
                candidate_detail["profile_url"] = profile_url

            # --- Step 2: Generate and post comment ---
            logger.info("Generating analysis comment...")
            comment = generate_final_comment(
                analysis=analysis,
                score=score,
                level_summary=level_summary,
                evaluation_result=evaluation_result,
            )

            logger.info(f"Posting comment for prospect {prospect_id}")
            if not post_comment_to_jazzhr(prospect_id, comment):
                logger.critical("Comment posting failed - terminating")
                return False
            logger.info("Comment posted successfully")

            # --- Step 3: Perform action ---
            logger.info(f"Executing action: {action}")
            if action == "reject":
                action_success = _click_reject(page, timeout)
            elif action == "advance":
                action_success = _click_advance(page, timeout)
            else:
                logger.error(f"Invalid action: '{action}' - terminating")
                return False

            if not action_success:
                raise RuntimeError(f"{action.capitalize()} action failed")

            logger.info(f"Action '{action}' completed successfully")
            return True

        except Exception as e:
            logger.error(f"⚠️ Error during attempt {attempt+1}: {str(e)}")
            logger.exception("Error details:")  # Include stack trace

            if attempt < max_retries:
                logger.warning(f"🔄 Retrying... ({attempt+1}/{max_retries})")
                # Reset state before retry
                page.goto(candidates_list_url)
                page.wait_for_load_state("networkidle", timeout=timeout)
                logger.info("Reset to candidates list page")
            else:
                logger.critical(f"Max retries exceeded for '{search_name}'")
                return False


def _click_reject(page: Page, timeout: int = 30000):
    try:
        logger.info("Clicking Reject...")

        reject_btn = page.locator(REJECT_BTN_XPATH)
        reject_btn.wait_for(timeout=timeout, state="visible")
        assert reject_btn.is_visible(timeout=timeout), "Reject button not visible"
        assert reject_btn.is_enabled(), "Reject button not enabled"
        reject_btn.click()

        drop_option = page.locator(DROPPED_OUT_OPTION_XPATH)
        drop_option.wait_for(timeout=timeout, state="visible")
        assert drop_option.is_visible(timeout=timeout), "Dropped Out option not visible"
        assert drop_option.is_enabled(), "Dropped Out option not enabled"
        drop_option.click()

        dropped_out_label = page.locator(DROPPED_OUT_LABEL_XPATH)
        dropped_out_label.wait_for(timeout=timeout, state="visible")
        assert dropped_out_label.is_visible(
            timeout=timeout
        ), "Workflow label did not change to 'Dropped Out'"

        logger.info("✓ Rejected as 'Dropped Out'")
        return True

    except Exception as e:
        logger.warning(f"⚠️ Rejection failed: {e}")
        return False


def _click_advance(page: Page, timeout: int = 30000):
    try:
        logger.info("Clicking Advance...")

        advance_btn = page.locator(ADVANCE_BTN_XPATH)
        advance_btn.wait_for(timeout=timeout, state="visible")
        assert advance_btn.is_visible(timeout=timeout), "Advance button not visible"
        assert advance_btn.is_enabled(), "Advance button not enabled"
        advance_btn.click()

        review_option = page.locator(INITIAL_REVIEW_OPTION_XPATH)
        review_option.wait_for(timeout=timeout, state="visible")
        assert review_option.is_visible(
            timeout=timeout
        ), "Initial Review option not visible"
        assert review_option.is_enabled(), "Initial Review option not enabled"
        review_option.click()

        initial_review_label = page.locator(INITIAL_REVIEW_LABEL_XPATH)
        initial_review_label.wait_for(timeout=timeout, state="visible")
        assert initial_review_label.is_visible(
            timeout=timeout
        ), "Workflow label did not change to '1. Initial review'"

        logger.info("✓ Advanced to 'Initial Review'")
        return True

    except Exception as e:
        logger.warning(f"⚠️ Advancement failed: {e}")
        return False


def _find_candidate_while_scrolling(
    page: Page, search_name: str, logger, max_attempts: int = 20
) -> bool:
    def normalize(text):
        return re.sub(r"\s+", " ", text.strip().lower())

    last_height = -1
    seen_candidates = set()

    for attempt in range(max_attempts):
        links = page.locator(CANDIDATE_LINK_XPATH)
        links.first.wait_for(state="visible")
        count = links.count()
        logger.info(f"🔍 Attempt {attempt + 1}: Found {count} candidates")

        previous_seen_count = len(seen_candidates)

        for i in range(count):
            link = links.nth(i)
            try:
                link_text = link.text_content()
            except Exception as e:
                logger.warning(f"⚠️ Failed to read candidate text: {e}")
                continue

            if link_text:
                cleaned_text = normalize(link_text)
                seen_candidates.add(cleaned_text)
                if normalize(search_name) in cleaned_text:
                    logger.info(f"✅ Candidate '{search_name}' found. Clicking...")
                    link.click()
                    candidate_profile_name = page.locator(CANDIDATE_PROFILE_NAME_XPATH)
                    candidate_profile_name.wait_for(state="visible")
                    assert (
                        candidate_profile_name.is_visible()
                    ), "Candidate profile name not visible"
                    return True

        current_height = page.evaluate("document.body.scrollHeight")
        # Scroll to load more candidates
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_function(f"document.body.scrollHeight > {current_height}")

        new_height = page.evaluate("document.body.scrollHeight")

        if new_height == last_height:
            logger.warning("⚠️ Page height unchanged — reached bottom.")
            break
        last_height = new_height

        # ❗️ Check if any new candidates were seen after scroll
        if len(seen_candidates) == previous_seen_count:
            logger.warning("⚠️ No new candidates loaded after scrolling.")
            break

    logger.warning(
        f"❌ Candidate '{search_name}' not found after {max_attempts} scrolls."
    )
    return False


def _open_candidate_profile(
    page: Page, search_name: str, candidates_list_url: str
) -> bool:
    try:
        page.goto(candidates_list_url, wait_until="load")
        return _find_candidate_while_scrolling(page, search_name, logger)

    except Exception as e:
        logger.error(f"Error while opening candidate profile: {e}")
        return False
