import logging
import asyncio
import threading
from contextlib import contextmanager
from playwright.sync_api import sync_playwright


logger = logging.getLogger(__name__)


class PlaywrightManager:
    """Thread-safe Playwright manager that handles event loop conflicts."""

    def __init__(self):
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        self._thread_local = threading.local()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()

    def setup_browser(self, timeout: int = 60000):
        """Set up browser in a thread-safe manner."""
        try:
            logger.info("Setting up headless Chromium browser...")

            # Initialize Playwright
            self.playwright = sync_playwright().start()

            # Launch browser
            self.browser = self.playwright.chromium.launch(
                headless=True,
                args=[
                    "--disable-gpu",
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-extensions",
                    "--disable-setuid-sandbox",
                    "--remote-debugging-port=9222",
                ],
            )

            # Create context
            self.context = self.browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            )

            # Set timeouts
            self.context.set_default_timeout(timeout)
            self.context.set_default_navigation_timeout(timeout)

            # Create page
            self.page = self.context.new_page()

            logger.info("✓ Headless browser initialized successfully.")
            return self.browser, self.page

        except Exception as e:
            logger.exception(f"❌ Failed to initialize headless browser: {str(e)}")
            self.cleanup()
            raise

    def cleanup(self):
        """Clean up resources in the correct order."""
        try:
            if self.page:
                try:
                    self.page.close()
                except Exception as e:
                    logger.warning(f"Error closing page: {e}")
                self.page = None

            if self.context:
                try:
                    self.context.close()
                except Exception as e:
                    logger.warning(f"Error closing context: {e}")
                self.context = None

            if self.browser:
                try:
                    self.browser.close()
                except Exception as e:
                    logger.warning(f"Error closing browser: {e}")
                self.browser = None

            if self.playwright:
                try:
                    self.playwright.stop()
                except Exception as e:
                    logger.warning(f"Error stopping playwright: {e}")
                self.playwright = None

        except Exception as e:
            logger.warning(f"Error during cleanup: {e}")


def setup_headless_browser(timeout: int = 60000):
    """
    Sets up and returns a Playwright browser in headless mode.
    Handles asyncio event loop conflicts by running in a separate thread if needed.

    Args:
        timeout: Timeout in milliseconds (default: 60000ms = 60s)

    Returns:
        tuple: (PlaywrightManager, Page) - Manager instance and page
    """

    def _run_in_thread():
        """Run Playwright setup in a dedicated thread."""
        manager = PlaywrightManager()
        try:
            browser, page = manager.setup_browser(timeout)
            return manager, page
        except Exception:
            manager.cleanup()
            raise

    try:
        # Check if we're in an async event loop
        loop = asyncio.get_running_loop()
        logger.info(
            "Detected asyncio event loop, running Playwright in separate thread..."
        )

        # Run in a separate thread
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_run_in_thread)
            return future.result()

    except RuntimeError:
        # No event loop running, safe to use sync API directly
        logger.info("No asyncio event loop detected, running Playwright directly...")
        return _run_in_thread()


@contextmanager
def playwright_browser(timeout: int = 60000):
    """Context manager for Playwright browser setup and cleanup."""
    manager = None
    try:
        manager, page = setup_headless_browser(timeout)
        yield manager, page
    finally:
        if manager:
            manager.cleanup()
