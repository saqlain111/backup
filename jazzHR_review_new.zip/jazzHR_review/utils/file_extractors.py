import logging
import fitz  # PyMuPDF
import os
import re
import json

logger = logging.getLogger(__name__)


def detect_file_type(file_path: str) -> str:
    """
    Detect the actual file type by reading file headers/magic bytes.

    Args:
        file_path (str): Path to the file

    Returns:
        str: 'pdf', 'docx', or 'unknown'
    """
    try:
        with open(file_path, "rb") as file:
            header = file.read(8)

        # PDF magic bytes
        if header.startswith(b"%PDF"):
            return "pdf"

        # DOCX/ZIP magic bytes (DOCX files are ZIP archives)
        if (
            header.startswith(b"PK\x03\x04")
            or header.startswith(b"PK\x05\x06")
            or header.startswith(b"PK\x07\x08")
        ):
            # Additional check for DOCX by testing if PyMuPDF can open it
            try:
                # Try to open as DOCX to confirm
                doc = fitz.open(file_path)
                doc.close()
                return "docx"
            except:
                # If it's a ZIP but not a valid DOCX, we'll treat it as unknown
                return "unknown"

        return "unknown"

    except Exception as e:
        logger.warning(f"Error detecting file type for {file_path}: {str(e)}")
        return "unknown"


def extract_text_from_file(file_path: str, output_path: str) -> bool:
    """
    Extract text from a file, detecting the actual file type rather than relying on extension.

    Args:
        file_path (str): Path to the input file
        output_path (str): Path to save the extracted text

    Returns:
        bool: True if extraction succeeded, False otherwise
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    try:
        # Detect actual file type
        actual_type = detect_file_type(file_path)

        # Log the detection result
        file_extension = os.path.splitext(file_path)[1].lower()
        if actual_type != "unknown":
            logger.info(
                f"File {file_path} has extension '{file_extension}' but detected as '{actual_type}'"
            )

        # Route to appropriate extractor based on detected type
        if actual_type == "pdf":
            return extract_text_from_document(file_path, output_path)
        elif actual_type == "docx":
            return extract_text_from_document(file_path, output_path)
        else:
            # Fallback to extension-based detection
            logger.warning(
                f"Could not detect file type for {file_path}, falling back to extension-based detection"
            )
            if file_extension in [".pdf", ".docx", ".doc", ".rtf"]:
                return extract_text_from_document(file_path, output_path)
            else:
                logger.warning(
                    f"Unsupported file type: {file_path} (extension: {file_extension}, detected: {actual_type})"
                )
                return False
    except Exception as e:
        logger.error(f"❌ General error during text extraction: {str(e)}")
        return False


def extract_text_from_document(file_path: str, output_path: str) -> bool:
    """
    Extract text and hyperlinks from a document file using PyMuPDF,
    and save results in structured JSON format. Checks if document
    is image-only (no parsable text).

    Args:
        file_path: Path to input document file
        output_path: Path to save extracted content

    Returns:
        True if successful, False on failure
    """
    try:
        # Open document
        doc = fitz.open(file_path)

        # Handle encrypted documents
        if doc.needs_pass and not doc.authenticate(""):
            logger.error("Failed to decrypt encrypted document")
            doc.close()
            return False

        # Extract content
        text_parts = []
        all_hyperlinks = []
        for page_num in range(len(doc)):
            page_text, page_links = extract_page_content(doc.load_page(page_num))
            if page_text:
                text_parts.append(page_text)
            all_hyperlinks.extend(page_links)

        doc.close()

        # Process extracted data
        cleaned_text = clean_text("\n\n".join(text_parts))
        valid_links = filter_hyperlinks(all_hyperlinks)

        # Check if document is image-only (no parsable text)
        error_message = None
        if (
            not cleaned_text or len(cleaned_text.strip()) < 20
        ):  # Threshold for minimal text
            error_message = "Resume appears to be an image without parsable text"
            logger.warning(f"⚠️ Image-only Resume detected: {file_path}")

        # Save results
        save_extracted_content(
            output_path, cleaned_text, valid_links, file_path, error_message
        )

        return True

    except Exception as e:
        logger.error(f"Critical error processing {file_path}: {str(e)}")
        return False


def extract_page_content(page: fitz.Page) -> tuple[str, list]:
    """
    Extract text and hyperlinks from a single page

    Args:
        page: PyMuPDF page object

    Returns:
        Tuple of (page_text, hyperlinks)
    """
    page_text = ""
    hyperlinks = []

    try:
        # Extract page text
        page_text = page.get_text().strip()

        # Extract link annotations
        for link in page.get_links():
            if link["kind"] == fitz.LINK_URI and link.get("uri"):
                url = link["uri"]
                if url and url not in hyperlinks:
                    hyperlinks.append(url)

        # Extract text spans with URL annotations
        page_dict = page.get_text("dict")
        for block in page_dict.get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if span.get("url"):
                        url = span["url"]
                        if url and url not in hyperlinks:
                            hyperlinks.append(url)

    except Exception as e:
        logger.warning(f"Error extracting page {page.number}: {str(e)}")

    return page_text, hyperlinks


def clean_text(text: str) -> str:
    """
    Normalize and clean extracted text

    Args:
        text: Raw extracted text

    Returns:
        Cleaned and normalized text
    """
    if not text:
        return ""

    # Normalize whitespace
    cleaned = re.sub(r"\s+", " ", text).strip()
    return cleaned


def filter_hyperlinks(hyperlinks: list) -> list:
    """
    Filter and validate extracted hyperlinks

    Args:
        hyperlinks: List of raw URLs

    Returns:
        Filtered list of valid hyperlinks
    """
    valid_links = []
    seen = set()

    for url in hyperlinks:
        # Normalize for comparison
        norm_url = url.lower()

        # Apply filters
        if "gmail.com" in norm_url and not norm_url.startswith("mailto:"):
            continue

        if not norm_url.startswith(("http", "mailto")):
            continue

        # Deduplicate
        if norm_url not in seen:
            seen.add(norm_url)
            valid_links.append(url)

    return valid_links


def save_extracted_content(
    output_path: str,
    text: str,
    hyperlinks: list,
    source_path: str,
    error_message: str = None,
) -> None:
    """
    Save extracted content to JSON file with optional error message

    Args:
        output_path: Path to save JSON
        text: Extracted text content
        hyperlinks: Validated hyperlinks
        source_path: Original file path for logging
        error_message: Optional error message about extraction issues
    """
    # Create output directory if needed
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Prepare data structure
    output_data = {
        "text": text,
        "hyperlinks": hyperlinks,
    }

    # Add error field if provided
    if error_message:
        output_data["error"] = error_message

    # Save as JSON
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    # Log results
    file_type = os.path.splitext(source_path)[1].upper().replace(".", "")
    char_count = len(text)
    link_count = len(hyperlinks)

    if char_count > 0:
        logger.info(
            f"Extracted {char_count} chars and {link_count} links from {file_type} "
            f"saved to {output_path}"
        )
    else:
        logger.warning(
            f"No text extracted from {file_type}, saved {link_count} links to {output_path}"
        )
