import logging
import os
import json
import csv
import requests

from config.constants import (
    JAZZHR_API_BASE_URL,
    JAZZHR_WEB_BASE_URL,
    RESUME_CONTENT_DIR,
    CANDIDATES_CSV_FILE,
)
from config.env_config import API_KEY

logger = logging.getLogger(__name__)


def save_candidate_csv_and_resumes(candidates: list):
    """
    Save candidates' basic info to CSV and resume content to disk.

    Args:
        candidates (list): List of candidate dictionaries.
    """
    successful_reads = 0
    failed_reads = 0

    with open(CANDIDATES_CSV_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["Name", "Email", "Applied Date", "Status", "URL", "Prospect ID"]
        )

        for i, applicant in enumerate(candidates, 1):
            prospect_id = applicant.get("id", "")
            first_name = applicant.get("first_name", "Unknown")
            last_name = applicant.get("last_name", "Unknown")
            email = applicant.get("email", "")
            applied_date = applicant.get("apply_date", "")
            status = applicant.get("status", {}).get("name", "Unknown")

            name = f"{first_name} {last_name}"
            logger.info("-" * 100)
            logger.info(
                f"[{i}/{len(candidates)}] Processing {name} (ID: {prospect_id})..."
            )

            candidate_url = (
                f"{JAZZHR_WEB_BASE_URL}/app/candidate/{prospect_id}"
                if prospect_id
                else ""
            )
            writer.writerow(
                [name, email, applied_date, status, candidate_url, prospect_id]
            )

            try:
                logger.info(f"Trying to get resume content for {name}...")
                content_url = (
                    f"{JAZZHR_API_BASE_URL}/applicants/{prospect_id}?apikey={API_KEY}"
                )
                response = requests.get(content_url)
                response.raise_for_status()
                applicant_data = response.json()

                resume_content = []
                fields = [
                    "resume_text",
                    "resume_content",
                    "resume_data",
                    "resume_parsed",
                    "work_experience",
                    "education",
                    "skills",
                    "summary",
                    "objective",
                    "resume",
                    "description",
                    "prospect_note",
                    "cover_letter",
                ]

                for field in fields:
                    if field in applicant_data and applicant_data[field]:
                        resume_content.append(f"--- {field.upper()} ---")
                        resume_content.append(str(applicant_data[field]))
                        resume_content.append("")

                safe_name = f"{first_name}_{last_name}_{prospect_id}".replace(
                    " ", "_"
                ).replace("/", "_")
                file_path = os.path.join(
                    RESUME_CONTENT_DIR,
                    f"{safe_name}.txt" if resume_content else f"{safe_name}.json",
                )

                with open(file_path, "w", encoding="utf-8") as file:
                    (
                        file.write("\n".join(resume_content))
                        if resume_content
                        else json.dump(applicant_data, file, indent=2)
                    )

                logger.info(f"✓ Saved resume content to {file_path}")
                successful_reads += 1

            except Exception as err:
                logger.error(f"Error processing {name}: {str(err)}")
                failed_reads += 1

    logger.info(
        f"\nResume content access complete: {successful_reads} successful, {failed_reads} failed"
    )
    logger.info(f"Content saved in directory: {os.path.abspath(RESUME_CONTENT_DIR)}")
