import logging
import re

logger = logging.getLogger(__name__)


def extract_overall_score(analysis_text: str) -> float | None:
    """
    Extract the overall score from AI-generated resume analysis text.

    Looks for lines like "Overall Score: 4.2 / 5" or similar variations.

    Returns:
        float or None: Extracted score between 0 and 5, or None if not found
    """
    try:
        if not analysis_text:
            logger.warning("Empty analysis text received.")
            return None

        lines = analysis_text.strip().splitlines()

        # Priority patterns
        primary_patterns = [
            r"overall\s+score[:\s]+(\d+(?:\.\d+)?)\s*(?:/|out\s+of|of)?\s*5",
            r"overall[:\s]+(\d+(?:\.\d+)?)\s*(?:/|out\s+of|of)?\s*5",
            r"total\s+score[:\s]+(\d+(?:\.\d+)?)\s*(?:/|out\s+of|of)?\s*5",
            r"final\s+score[:\s]+(\d+(?:\.\d+)?)\s*(?:/|out\s+of|of)?\s*5",
        ]

        for pattern in primary_patterns:
            for line in lines:
                match = re.search(pattern, line.lower())
                if match:
                    score = float(match.group(1))
                    if 0 <= score <= 5:
                        logger.info(
                            f"Found overall score: {score} from line: '{line.strip()}'"
                        )
                        return score

        # Fallback: scan all lines for valid scores <= 5
        fallback_scores = []
        fallback_patterns = [
            r"(\d+(?:\.\d+)?)\s*(?:/|out\s+of|of)?\s*5",
            r"(?:^|\s)(\d+(?:\.\d+)?)(?:\s*$|\s*[^\d])",
        ]

        for line in lines:
            for pattern in fallback_patterns:
                for match in re.findall(pattern, line.lower()):
                    try:
                        score = float(match)
                        if 0 <= score <= 5:
                            fallback_scores.append((score, line.strip()))
                    except ValueError:
                        continue

        if fallback_scores:
            final_score, source_line = fallback_scores[-1]
            logger.info(
                f"Using fallback score: {final_score} from line: '{source_line}'"
            )
            return final_score

        logger.warning("No valid score found in analysis text.")
        return None

    except Exception as e:
        logger.exception(f"Error extracting score: {e}")
        return None
