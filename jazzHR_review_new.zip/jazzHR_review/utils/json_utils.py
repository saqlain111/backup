import json
import re
import logging
import json_repair

logger = logging.getLogger(__name__)


def _clean_json_response(response_text: str) -> str:
    """Fix common JSON formatting issues with enhanced pattern matching"""
    # Remove markdown code blocks with optional language specifier
    code_block_match = re.search(
        r"```(?:json)?\s*(.*?)\s*```", response_text, re.DOTALL
    )
    if code_block_match:
        response_text = code_block_match.group(1).strip()

    # Remove JSON schema declarations and prefix text
    response_text = re.sub(r"^[\s\S]*?({[\s\S]*)$", r"\1", response_text)

    # Fix trailing commas before closing braces/brackets
    response_text = re.sub(r",\s*([}\]])", r"\1", response_text)

    # Replace smart quotes and apostrophes
    quote_replacements = {""": '"', """: '"', "'": "'", "'": "'", "`": "'"}
    for smart, straight in quote_replacements.items():
        response_text = response_text.replace(smart, straight)

    # Remove non-printable characters except tabs and newlines
    response_text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]", "", response_text)

    return response_text.strip()


def parse_json_response(response_text: str) -> dict:
    """Robust JSON parsing with professional repair tools"""
    cleaned_text = _clean_json_response(response_text)

    try:
        # First try standard parsing
        return json.loads(cleaned_text)
    except json.JSONDecodeError as primary_error:
        logger.warning(
            f"Initial JSON parse failed: {primary_error}, attempting repair..."
        )

        try:
            return json_repair.loads(cleaned_text)
        except ImportError:
            logger.warning("json_repair not available, falling back to custom repairs")
        except Exception as repair_error:
            logger.warning(f"JSON repair failed: {repair_error}, trying custom methods")

        # Fallback to custom strategies if needed
        return _custom_json_recovery(cleaned_text, primary_error)


def _custom_json_recovery(cleaned_text: str, error: json.JSONDecodeError) -> dict:
    """Custom recovery strategies for JSON parsing"""
    try:
        # Strategy 1: Find first complete JSON object
        json_match = re.search(r"\{[\s\S]*\}", cleaned_text)
        if json_match:
            return json.loads(json_match.group(0))
    except Exception:
        pass

    try:
        # Strategy 2: Add quotes to unquoted keys
        fixed_keys = re.sub(r"([{,]\s*)(\w+)(\s*:)", r'\1"\2"\3', cleaned_text)
        return json.loads(fixed_keys)
    except Exception:
        pass

    try:
        # Strategy 3: Handle single quotes
        single_quoted = cleaned_text.replace("'", '"')
        return json.loads(single_quoted)
    except Exception:
        pass

    try:
        # Strategy 4: Fix missing comma delimiters
        if "Expecting ',' delimiter" in str(error):
            fixed_text = cleaned_text[: error.pos] + "," + cleaned_text[error.pos :]
            return json.loads(fixed_text)
    except Exception:
        pass

    # Final fallback
    logger.error(f"All JSON recovery attempts failed: {error}")
    return {
        "error": f"JSON parsing failed: {str(error)}",
        "error_position": f"Line {error.lineno}, Column {error.colno}",
        "context": cleaned_text[max(0, error.pos - 50) : error.pos + 50],
    }
