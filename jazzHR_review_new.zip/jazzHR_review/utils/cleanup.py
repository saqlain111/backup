import os
import shutil
import logging

from config.constants import (
    RESUME_CONTENT_DIR,
    RESUME_DIR,
    RESUME_JSON_TEXT_DIR,
    CANDIDATES_CSV_FILE,
    LOG_PATH,
)

logger = logging.getLogger(__name__)


def cleanup_files():
    """Clean up files and directories created during script execution."""
    files_to_cleanup = [
        ("Candidate resume content directory", RESUME_CONTENT_DIR),
        ("Downloaded resume files directory", RESUME_DIR),
        ("Extracted resume JSON text directory", RESUME_JSON_TEXT_DIR),
        ("Candidates CSV file", CANDIDATES_CSV_FILE),
        ("App Log file", LOG_PATH),
    ]

    logger.info("\n===== Cleanup =====")
    logger.info("Cleaning up files and directories:")

    for desc, path in files_to_cleanup:
        try:
            if os.path.exists(path):
                if os.path.isdir(path):
                    size = sum(
                        os.path.getsize(os.path.join(dirpath, f))
                        for dirpath, _, filenames in os.walk(path)
                        for f in filenames
                    )
                    size_str = (
                        f"{size / (1024*1024):.2f} MB"
                        if size > 1024 * 1024
                        else f"{size / 1024:.2f} KB"
                    )
                    file_count = sum(len(files) for _, _, files in os.walk(path))
                    logger.info(
                        f"Deleting {desc}: {path} ({file_count} files, {size_str})"
                    )
                    shutil.rmtree(path)
                else:
                    size = os.path.getsize(path)
                    size_str = (
                        f"{size / (1024*1024):.2f} MB"
                        if size > 1024 * 1024
                        else f"{size / 1024:.2f} KB"
                    )
                    logger.info(f"Deleting {desc}: {path} ({size_str})")
                    os.remove(path)
        except Exception as e:
            logger.error(f"Error deleting {path}: {str(e)}")

    logger.info("Cleanup complete.")
