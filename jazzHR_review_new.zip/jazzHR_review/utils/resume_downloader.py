import os
import re
import subprocess
import logging
import json
import urllib.parse
from typing import Optional, Dict, Any, Tuple

from utils.auth import get_auth_cookies_string
from utils.file_extractors import extract_text_from_file

from config.constants import (
    JAZZHR_WEB_BASE_URL,
    RESUME_DIR,
    RESUME_CONTENT_DIR,
    RESUME_JSON_TEXT_DIR,
)

logger = logging.getLogger(__name__)


def download_resume_with_auth(url: str, output_path: str) -> Optional[str]:
    """Download a file with proper authentication headers."""
    logger.info(f"Attempting to download: {url}")
    cookies_str = get_auth_cookies_string()

    cmd = [
        "curl",
        "--location",
        "--silent",
        "--show-error",
        "-H",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "-H",
        f"Referer: {JAZZHR_WEB_BASE_URL}/",
        "-H",
        "Accept: */*",
        "-H",
        "Cache-Control: no-cache",
        "--cookie",
        cookies_str,
        "--output",
        output_path,
        url,
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        if result.returncode != 0:
            logger.error(f"Curl failed ({result.returncode}): {result.stderr.strip()}")
            return None

        if not os.path.exists(output_path):
            logger.error("Output file not created")
            return None

        file_size = os.path.getsize(output_path)
        logger.info(f"Downloaded {file_size} bytes to {output_path}")

        # Validate downloaded file
        if not _validate_downloaded_file(output_path):
            return None

        return output_path

    except Exception as e:
        logger.error(f"Download failed: {str(e)}")
        return None


def _validate_downloaded_file(file_path: str) -> bool:
    """Validate that the downloaded file is not an HTML error page and is a valid file type."""
    try:
        with open(file_path, "rb") as f:
            first_bytes = f.read(1024)

        # Check if it's an HTML error page
        if re.search(rb"<(html|!DOCTYPE)", first_bytes, re.I):
            logger.error("Received HTML error page - likely authentication failure")
            logger.debug(
                f"Content sample: {first_bytes[:200].decode('utf-8', 'ignore')}"
            )
            os.remove(file_path)
            return False

        # Log file type detection
        if first_bytes.startswith(b"%PDF-"):
            logger.info("Valid PDF detected")
        elif first_bytes.startswith(b"PK\x03\x04"):
            logger.info("Valid DOCX detected")
        else:
            logger.warning(f"Unknown file type. Magic: {first_bytes[:8].hex()}")

        return True

    except Exception as e:
        logger.error(f"File validation failed: {str(e)}")
        if os.path.exists(file_path):
            os.remove(file_path)
        return False


def extract_resume_link_from_data(applicant_data: Dict[str, Any]) -> Optional[str]:
    """Extract resume link from applicant data using various possible keys."""
    # Try direct keys first
    for key in ["resume_link", "resume_url", "resume", "attachment_url"]:
        if key in applicant_data and applicant_data[key]:
            return applicant_data[key]

    # Try attachments array
    if "attachments" in applicant_data:
        for attachment in applicant_data.get("attachments", []):
            if isinstance(attachment, dict) and "url" in attachment:
                return attachment["url"]

    return None


def extract_extension_from_encoded_url(encoded_url: str) -> str:
    """
    Extract file extension from an encoded URL.

    Args:
        encoded_url (str): URL-encoded string

    Returns:
        str: File extension (e.g., '.pdf', '.docx') or '.bin' if not found
    """
    try:
        # Decode the URL
        decoded_url = urllib.parse.unquote(encoded_url)
        logger.debug(f"Decoded URL: {decoded_url}")

        # Extract the path part and get the extension
        parsed_url = urllib.parse.urlparse(decoded_url)
        path = parsed_url.path

        # Get the extension from the path
        _, extension = os.path.splitext(path)

        if extension:
            logger.debug(f"Extracted extension: {extension}")
            return extension.lower()
        else:
            logger.warning(f"No extension found in URL: {decoded_url}")
            return ".bin"  # Default extension when none found

    except Exception as e:
        logger.error(f"Error extracting extension from URL: {str(e)}")
        return ".bin"


def generate_safe_filename(first_name: str, last_name: str, prospect_id: str) -> str:
    """Generate a safe filename from applicant details."""
    safe_name = f"{first_name}_{last_name}_{prospect_id}".replace(" ", "_").replace(
        "/", "_"
    )
    return safe_name


def download_resume_from_link(
    resume_link: str, safe_name: str, output_dir: str = RESUME_DIR
) -> Optional[str]:
    """
    Download a resume from a given link and return the path to the downloaded file.

    Args:
        resume_link (str): The resume download link
        safe_name (str): Safe filename without extension
        output_dir (str): Directory to save the resume

    Returns:
        Optional[str]: Path to downloaded resume file, None if failed
    """
    try:
        # Extract extension from the original URL
        file_extension = extract_extension_from_encoded_url(resume_link)

        # Create paths with the correct extension
        resume_path = os.path.join(output_dir, f"{safe_name}{file_extension}")

        # Create Jazz HR download URL
        encoded_url = urllib.parse.quote(resume_link)
        jazz_download_url = (
            f"{JAZZHR_WEB_BASE_URL}/files/download/resume?url={encoded_url}"
        )

        logger.info(
            f"Downloading as {os.path.basename(resume_path)} (extension from URL: {file_extension})"
        )

        return download_resume_with_auth(jazz_download_url, resume_path)

    except Exception as e:
        logger.error(f"Error downloading resume from link: {str(e)}")
        return None


def download_and_extract_single_resume(
    applicant_data: Dict[str, Any], safe_name: str
) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Download and extract text from a single resume.

    Args:
        applicant_data (Dict[str, Any]): Applicant data containing resume link
        safe_name (str): Safe filename for the applicant

    Returns:
        Tuple[bool, Optional[str], Optional[str]]: (success, resume_path, text_path)
    """
    try:
        resume_link = extract_resume_link_from_data(applicant_data)

        if not resume_link:
            logger.warning(f"⚠️ No resume link found in data for {safe_name}")
            return False, None, None

        # Download resume
        resume_path = download_resume_from_link(resume_link, safe_name)

        if not resume_path:
            logger.warning(f"⚠️ Failed to download resume for {safe_name}")
            return False, None, None

        # Extract text
        text_path = os.path.join(RESUME_JSON_TEXT_DIR, f"{safe_name}.json")

        if extract_text_from_file(resume_path, text_path):
            logger.info(f"✓ Extracted resume text to {text_path}")
            return True, resume_path, text_path
        else:
            logger.warning(f"⚠️ Text extraction failed for {safe_name}")
            return False, resume_path, None

    except Exception as e:
        logger.error(f"Error processing resume for {safe_name}: {str(e)}")
        return False, None, None


def download_and_extract_resumes_from_json_files():
    """
    Download resumes using links in JSON files and extract their text content.
    Now with proper extension detection from URLs.
    """
    logger.info("\n===== Downloading Resumes from S3 Links =====")

    successful = 0
    failed = 0

    json_files = [f for f in os.listdir(RESUME_CONTENT_DIR) if f.endswith(".json")]
    logger.info(f"Found {len(json_files)} JSON files to check for resume links")

    for i, json_file in enumerate(json_files, 1):
        try:
            file_path = os.path.join(RESUME_CONTENT_DIR, json_file)

            # Parse filename to extract applicant details
            name_parts = json_file.replace(".json", "").split("_")
            first_name = name_parts[0] if len(name_parts) > 0 else "Unknown"
            last_name = name_parts[1] if len(name_parts) > 1 else "Unknown"
            prospect_id = "_".join(name_parts[2:]) if len(name_parts) > 2 else ""

            logger.info("-" * 100)
            logger.info(
                f"[{i}/{len(json_files)}] Processing {first_name} {last_name}..."
            )

            # Load applicant data
            with open(file_path, "r", encoding="utf-8") as f:
                applicant_data = json.load(f)

            safe_name = generate_safe_filename(first_name, last_name, prospect_id)

            # Download and extract resume
            success, resume_path, text_path = download_and_extract_single_resume(
                applicant_data, safe_name
            )

            if success:
                successful += 1
            else:
                failed += 1

        except Exception as e:
            logger.error(f"Error processing {json_file}: {str(e)}")
            failed += 1

    logger.info(
        f"\n🎯 Resume download/extraction complete: {successful} success, {failed} failed"
    )
    logger.info(
        f"Files stored in:\n- Resumes: {os.path.abspath(RESUME_DIR)}\n- Texts: {os.path.abspath(RESUME_JSON_TEXT_DIR)}"
    )
