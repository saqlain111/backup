from datetime import datetime
from dateutil import parser
from typing import List, Dict, Optional, Union


def calculate_total_experience_months(
    work_experience: List[Dict[str, Union[str, datetime]]],
    handle_overlaps: bool = False,
    reference_date: Optional[datetime] = None,
) -> Dict[str, Union[int, List[str]]]:
    """
    Calculate total work experience in months from a list of job entries.

    Args:
        work_experience: List of job dictionaries with 'start' and 'end' dates
        handle_overlaps: If True, removes overlapping periods to avoid double-counting
        reference_date: Reference date for ongoing jobs (defaults to current UTC time)

    Returns:
        Dictionary containing:
        - 'total_months': Total experience in months
        - 'total_years': Total experience in years (rounded to 1 decimal)
        - 'errors': List of error messages for skipped entries
        - 'processed_jobs': Number of successfully processed jobs

    Each job entry should have:
        - 'start': Start date string or datetime object
        - 'end': End date string/datetime object (optional for current jobs)
        - 'company': Company name (optional, for better error reporting)
        - 'position': Job title (optional, for better error reporting)

    Date formats supported: ISO format, common formats like "Jan 2020", "2020-01", etc.
    """
    if not work_experience:
        return {
            "total_months": 0,
            "total_years": 0.0,
            "errors": ["No work experience provided"],
            "processed_jobs": 0,
        }

    reference_date = reference_date or datetime.utcnow()
    total_months = 0
    errors = []
    periods = []
    processed_jobs = 0

    for i, job in enumerate(work_experience):
        if not isinstance(job, dict):
            errors.append(f"Job entry {i+1}: Invalid format (not a dictionary)")
            continue

        job_identifier = _get_job_identifier(job, i)

        try:
            # Parse start date
            start_raw = job.get("start", "")
            if not start_raw:
                errors.append(f"{job_identifier}: Missing start date")
                continue

            start = _parse_date(start_raw)

            # Parse end date
            end_raw = job.get("end", "")
            if end_raw:
                end = _parse_date(end_raw)
            else:
                end = reference_date

            # Validate date range
            if start > end:
                errors.append(f"{job_identifier}: Start date is after end date")
                continue

            if start > reference_date:
                errors.append(f"{job_identifier}: Start date is in the future")
                continue

            # Calculate months with more precise method
            months = _calculate_months_between_dates(start, end)

            if handle_overlaps:
                periods.append((start, end, months, job_identifier))
            else:
                total_months += months

            processed_jobs += 1

        except ValueError as e:
            errors.append(f"{job_identifier}: Date parsing error - {str(e)}")
        except Exception as e:
            errors.append(f"{job_identifier}: Unexpected error - {str(e)}")

    # Handle overlapping periods if requested
    if handle_overlaps and periods:
        total_months = _remove_overlapping_periods(periods)

    return {
        "total_months": total_months,
        "total_years": round(total_months / 12, 1),
        "errors": errors,
        "processed_jobs": processed_jobs,
    }


def _get_job_identifier(job: Dict, index: int) -> str:
    """Generate a human-readable identifier for a job entry."""
    company = (job.get("company") or "").strip()
    position = (job.get("position") or "").strip()

    if company and position:
        return f"{position} at {company}"
    elif company:
        return f"Job at {company}"
    elif position:
        return position
    else:
        return f"Job entry {index + 1}"


def _parse_date(date_input: Union[str, datetime]) -> datetime:
    """Parse various date formats into datetime object."""
    if isinstance(date_input, datetime):
        return date_input

    if not isinstance(date_input, str):
        raise ValueError(f"Date must be string or datetime, got {type(date_input)}")

    date_str = date_input.strip()
    if not date_str:
        raise ValueError("Empty date string")

    try:
        # Use dateutil parser with default day=1 for partial dates
        return parser.parse(date_str, default=datetime(1900, 1, 1))
    except (ValueError, TypeError) as e:
        raise ValueError(f"Could not parse date '{date_str}': {str(e)}")


def _calculate_months_between_dates(start: datetime, end: datetime) -> int:
    """
    Calculate months between two dates with more accurate method.
    Accounts for partial months and leap years.
    """
    # Calculate total months difference
    months = (end.year - start.year) * 12 + (end.month - start.month)

    # Adjust for day differences within the month
    if end.day < start.day:
        months -= 1

    return max(0, months)


def _remove_overlapping_periods(periods: List[tuple]) -> int:
    """
    Remove overlapping time periods to avoid double-counting experience.
    Uses a greedy algorithm to merge overlapping intervals.
    """
    if not periods:
        return 0

    # Sort periods by start date
    periods.sort(key=lambda x: x[0])

    merged_periods = []
    current_start, current_end = periods[0][0], periods[0][1]

    for start, end, _, _ in periods[1:]:
        if start <= current_end:
            # Overlapping period - extend current period
            current_end = max(current_end, end)
        else:
            # Non-overlapping period - save current and start new
            merged_periods.append((current_start, current_end))
            current_start, current_end = start, end

    # Add the last period
    merged_periods.append((current_start, current_end))

    # Calculate total months from merged periods
    total_months = 0
    for start, end in merged_periods:
        total_months += _calculate_months_between_dates(start, end)

    return total_months


def format_experience_summary(result: Dict) -> str:
    """
    Format the calculation result into a human-readable summary.
    """
    total_months = result["total_months"]
    total_years = result["total_years"]
    processed_jobs = result["processed_jobs"]
    errors = result["errors"]

    summary = f"Total Work Experience: {total_months} months ({total_years} years)\n"
    summary += f"Successfully processed: {processed_jobs} job entries\n"

    if errors:
        summary += f"\nIssues encountered ({len(errors)}):\n"
        for error in errors:
            summary += f"  • {error}\n"

    return summary.strip()


def parse_job_experience_format(jobs_data: List[Dict]) -> List[Dict]:
    """
    Convert job experience data from your specific format to the standard format.

    Expected input format:
    [
        {
            'job_title': 'AWS DevOps Engineer',
            'company': 'Vigoursoft Global Solutions',
            'duration': '04/2024 – present' or 'Aug-2024 - Present',
            'job_summary': '...'
        }
    ]

    Returns standardized format for the calculator.
    """
    standardized_jobs = []

    for i, job in enumerate(jobs_data):
        duration = job.get("duration", "").strip()

        if not duration:
            continue

        # Handle different dash types and normalize
        duration = (
            duration.replace("–", "-")
            .replace("—", "-")
            .replace(" – ", " - ")
            .replace(" — ", " - ")
        )

        # Split on various separators - try multiple approaches
        parts = []

        # Try different separators in order of preference
        separators = [" to ", " - ", " – ", " — ", "-", "–", "—"]
        for separator in separators:
            if separator in duration:
                parts = [
                    part.strip() for part in duration.split(separator, 1)
                ]  # Split only once
                break

        if len(parts) != 2:
            continue

        start_str = parts[0].strip()
        end_str = parts[1].strip()

        # Remove common prefixes like "From" from start date
        if start_str.lower().startswith("from "):
            start_str = start_str[5:].strip()

        # Convert to standard format
        try:
            start_converted = _convert_date_format(start_str)

            end_converted = (
                ""
                if end_str.lower() in ["present", "current"]
                else _convert_date_format(end_str)
            )

            standardized_job = {
                "position": job.get("job_title", ""),
                "company": job.get("company", ""),
                "start": start_converted,
                "end": end_converted,
            }

            standardized_jobs.append(standardized_job)

        except Exception as e:
            continue

    return standardized_jobs


def _convert_date_format(date_str: str) -> str:
    """Convert various date formats to YYYY-MM-DD format."""
    try:
        # Handle MM/YYYY format (e.g., "04/2024")
        if "/" in date_str and len(date_str.split("/")) == 2:
            try:
                month, year = date_str.split("/")
                month = month.zfill(2)
                result = f"{year}-{month}-01"
                return result
            except ValueError:
                pass

        # Handle Month-YYYY format (e.g., "Aug-2024", "Jun-2023")
        if "-" in date_str:
            parts = date_str.split("-")
            if len(parts) == 2:
                try:
                    month_str, year = parts
                    # Map month abbreviations to numbers
                    month_mapping = {
                        "jan": "01",
                        "january": "01",
                        "feb": "02",
                        "february": "02",
                        "mar": "03",
                        "march": "03",
                        "apr": "04",
                        "april": "04",
                        "may": "05",
                        "jun": "06",
                        "june": "06",
                        "jul": "07",
                        "july": "07",
                        "aug": "08",
                        "august": "08",
                        "sep": "09",
                        "sept": "09",
                        "september": "09",
                        "oct": "10",
                        "october": "10",
                        "nov": "11",
                        "november": "11",
                        "dec": "12",
                        "december": "12",
                    }
                    month_num = month_mapping.get(month_str.lower(), None)
                    if month_num:
                        result = f"{year}-{month_num}-01"
                        return result
                except (ValueError, IndexError):
                    pass

        # Handle YYYY format (e.g., "2024")
        if date_str.isdigit() and len(date_str) == 4:
            result = f"{date_str}-01-01"
            return result

        # Handle Month YYYY format (e.g., "Aug 2024")
        if " " in date_str:
            parts = date_str.split()
            if len(parts) == 2:
                try:
                    month_str, year = parts
                    month_mapping = {
                        "jan": "01",
                        "january": "01",
                        "feb": "02",
                        "february": "02",
                        "mar": "03",
                        "march": "03",
                        "apr": "04",
                        "april": "04",
                        "may": "05",
                        "jun": "06",
                        "june": "06",
                        "jul": "07",
                        "july": "07",
                        "aug": "08",
                        "august": "08",
                        "sep": "09",
                        "sept": "09",
                        "september": "09",
                        "oct": "10",
                        "october": "10",
                        "nov": "11",
                        "november": "11",
                        "dec": "12",
                        "december": "12",
                    }
                    month_num = month_mapping.get(month_str.lower(), None)
                    if month_num and year.isdigit():
                        result = f"{year}-{month_num}-01"
                        return result
                except (ValueError, IndexError):
                    pass

        return date_str

    except Exception as e:
        return date_str
