import logging
import requests
from typing import Tuple
from cryptography.fernet import Fernet

from utils.browser_utils import playwright_browser

from config.constants import (
    JAZZHR_WEB_BASE_URL,
    OKTA_DOMAIN,
    JAZZHR_OKTA_REDIRECT_URL,
    OKTA_USERNAME,
    ENCRYPTION_KEY,
)
from config.env_config import ENCRYPTED_PASSWORD

logger = logging.getLogger(__name__)


def get_auth_cookies_string() -> str:
    """Return the authentication cookies as a string for curl requests."""
    if not SANDCASTLE_TICKET:
        raise ValueError("SANDCASTLE_TICKET is required")
    return f"sandcastle_ticket={SANDCASTLE_TICKET}"


def add_auth_cookies_to_browser(page) -> bool:
    """
    Add necessary authentication cookies to the Playwright browser session.

    Args:
        page: Playwright Page instance

    Returns:
        bool: True if cookies added successfully
    """
    try:
        logger.info("Navigating to base URL to initialize cookies...")
        page.goto(JAZZHR_WEB_BASE_URL, wait_until="load")

        cookies = [
            {
                "name": "sandcastle_ticket",
                "value": SANDCASTLE_TICKET,
                "domain": ".jazz.co",
                "path": "/",
                "secure": True,
            },
            {
                "name": "SF_PHPSESSID",
                "value": SF_PHPSESSID,
                "domain": "app.jazz.co",
                "path": "/",
            },
            {
                "name": "AWSALB",
                "value": AWSALB,
                "domain": "app.jazz.co",
                "path": "/",
            },
        ]

        # Add cookies to the browser context
        context = page.context
        for cookie in cookies:
            try:
                context.add_cookies([cookie])
                logger.debug(f"✓ Added cookie: {cookie['name']}")
            except Exception as e:
                logger.warning(f"⚠️ Could not add cookie {cookie['name']}: {str(e)}")

        logger.info("✓ Authentication cookies added successfully.")
        return True

    except Exception as e:
        logger.error(f"Failed to add authentication cookies: {str(e)}")
        return False


def decrypt_password(encrypted_password: str) -> str:
    """Decrypts an encrypted password using Fernet symmetric encryption.

    Args:
        encrypted_password: Encrypted password string

    Returns:
        Decrypted plaintext password

    Raises:
        ValueError: If decryption fails due to invalid key/token
        RuntimeError: For other decryption failures
    """
    try:
        logger.info("🔓 Attempting password decryption...")
        fernet = Fernet(ENCRYPTION_KEY)
        decrypted_bytes = fernet.decrypt(encrypted_password.encode())
        return decrypted_bytes.decode()
    except (ValueError, TypeError) as e:
        logger.error(f"❌ Decryption failed - invalid key or token: {str(e)}")
        raise ValueError("Invalid encryption key or malformed token") from e
    except Exception as e:
        logger.error(f"❌ Unexpected decryption failure: {str(e)}")
        raise RuntimeError("Password decryption failed") from e


def get_okta_session_token(username: str, password: str) -> str:
    """Authenticates with Okta and returns a session token if MFA is not required.

    Args:
        username: Okta username
        password: Okta password

    Returns:
        Okta session token

    Raises:
        RuntimeError: If authentication fails or MFA is required
    """
    try:
        logger.info("🔐 Initiating Okta primary auth...")
        auth_url = f"{OKTA_DOMAIN}/api/v1/authn"
        auth_payload = {"username": username, "password": password}

        auth_resp = requests.post(auth_url, json=auth_payload)
        auth_resp.raise_for_status()
        auth_data = auth_resp.json()

        status = auth_data.get("status")
        if status == "SUCCESS":
            logger.info("✅ Authentication successful without MFA")
            return auth_data["sessionToken"]
        elif status == "MFA_REQUIRED":
            logger.error("❌ MFA is required, but this flow does not support MFA.")
            raise RuntimeError(
                "MFA is required for this user. Please use a different login flow."
            )
        else:
            logger.error(f"❌ Unexpected authentication status: {status}")
            raise RuntimeError(f"Unexpected Okta auth status: {status}")

    except requests.RequestException as e:
        logger.error(f"🌐 Network error during authentication: {str(e)}")
        raise RuntimeError("Okta authentication network failure") from e
    except KeyError as e:
        logger.error(f"🔑 Missing expected field in response: {str(e)}")
        raise RuntimeError("Invalid Okta authentication response") from e


def login_and_get_auth_cookies() -> Tuple[str, str, str]:
    """
    Logs into Okta, opens JazzHR, and retrieves session cookies.

    Returns:
        Tuple containing (sandcastle_ticket, SF_PHPSESSID, AWSALB)

    Raises:
        RuntimeError: For browser errors or missing cookies
    """
    try:
        password = decrypt_password(ENCRYPTED_PASSWORD)
        session_token = get_okta_session_token(OKTA_USERNAME, password)

        logger.info("🌐 Starting browser session for cookie retrieval...")
        login_url = (
            f"{OKTA_DOMAIN}/login/sessionCookieRedirect?"
            f"token={session_token}&redirectUrl={JAZZHR_OKTA_REDIRECT_URL}"
        )

        with playwright_browser() as (manager, page):
            page.goto(login_url, wait_until="load")

            if "jazz.co" not in page.url:
                logger.warning(f"⚠️ Unexpected post-login URL: {page.url}")

            # Get cookies from the browser context
            cookies = page.context.cookies()
            cookie_map = {c["name"]: c["value"] for c in cookies}
            logger.info(f"🍪 Retrieved {len(cookies)} cookies")

            required_cookies = {
                "sandcastle_ticket": cookie_map.get("sandcastle_ticket"),
                "SF_PHPSESSID": cookie_map.get("SF_PHPSESSID"),
                "AWSALB": cookie_map.get("AWSALB"),
            }

            missing = [name for name, val in required_cookies.items() if not val]
            if missing:
                logger.error(f"❌ Missing required cookies: {', '.join(missing)}")
                raise RuntimeError("Essential authentication cookies missing")

            logger.info("✅ All required cookies found")
            return (
                required_cookies["sandcastle_ticket"],
                required_cookies["SF_PHPSESSID"],
                required_cookies["AWSALB"],
            )

    except Exception as e:
        logger.error(f"❌ Cookie retrieval failed: {str(e)}")
        raise RuntimeError("JazzHR authentication failed") from e


def initialize_auth():
    global SANDCASTLE_TICKET, SF_PHPSESSID, AWSALB
    SANDCASTLE_TICKET, SF_PHPSESSID, AWSALB = login_and_get_auth_cookies()
