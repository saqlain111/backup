import logging
import json
import os
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple

from services.jazzhr_api import get_applicants_by_full_name, get_applicant_by_id
from utils.resume_downloader import (
    download_and_extract_single_resume,
    generate_safe_filename,
)

from config.constants import REJECTION_STATUSES, RESUME_JSON_TEXT_DIR
from config.env_config import JOB_ID

logger = logging.getLogger(__name__)

# Global registry for same-batch duplicates
contact_registry = defaultdict(
    lambda: {
        "id": None,
        "apply_date": None,
        "status": None,
        "email": None,
        "phone": None,
    }
)


def reset_contact_registry():
    """Reset the contact registry before processing new candidates"""
    global contact_registry
    contact_registry = defaultdict(
        lambda: {
            "id": None,
            "apply_date": None,
            "status": None,
            "email": None,
            "phone": None,
        }
    )


def get_resume_character_count(resume_text_path: str) -> Optional[int]:
    """
    Get character count from resume text JSON file.

    Args:
        resume_text_path (str): Path to the resume text JSON file

    Returns:
        Optional[int]: Character count or None if file doesn't exist or error
    """
    try:
        if not os.path.exists(resume_text_path):
            logger.warning(f"Resume text file not found: {resume_text_path}")
            return None

        with open(resume_text_path, "r", encoding="utf-8") as f:
            resume_data = json.load(f)

        # Get text content and count characters
        text_content = resume_data.get("text", "")
        char_count = len(text_content.strip())

        logger.debug(f"Resume character count: {char_count}")
        return char_count

    except Exception as e:
        logger.error(f"Error reading resume text file {resume_text_path}: {str(e)}")
        return None


def download_and_compare_resumes(
    current_candidate_data: Dict[str, Any],
    matched_candidate_data: Dict[str, Any],
    current_safe_name: str,
) -> Tuple[bool, Optional[str], Optional[int], Optional[int]]:
    """
    Download resumes for both candidates and compare character counts.

    Args:
        current_candidate_data: Current candidate's data
        matched_candidate_data: Matched candidate's data
        current_safe_name: Safe filename for current candidate

    Returns:
        Tuple[bool, Optional[str], Optional[int], Optional[int]]:
        (resumes_identical, comparison_result, current_char_count, matched_char_count)
    """
    try:
        # Generate safe name for matched candidate using the helper function
        matched_first_name = matched_candidate_data.get("first_name", "")
        matched_last_name = matched_candidate_data.get("last_name", "")
        matched_id = matched_candidate_data.get("id", "")
        matched_safe_name = generate_safe_filename(
            matched_first_name, matched_last_name, matched_id
        )

        # Check if current candidate resume already exists (should already be there)
        current_resume_path = os.path.join(
            RESUME_JSON_TEXT_DIR, f"{current_safe_name}.json"
        )
        current_char_count = None

        if os.path.exists(current_resume_path):
            current_char_count = get_resume_character_count(current_resume_path)
            logger.info(
                f"Found existing resume for current candidate: {current_char_count} chars"
            )
        else:
            # Download and extract current candidate's resume
            logger.info(
                f"Downloading resume for current candidate: {current_safe_name}"
            )
            success, _, text_path = download_and_extract_single_resume(
                current_candidate_data, current_safe_name
            )
            if success and text_path:
                current_char_count = get_resume_character_count(text_path)
                logger.info(
                    f"Downloaded current candidate resume: {current_char_count} chars"
                )
            else:
                logger.warning(f"Failed to download current candidate resume")

        # Check if matched candidate resume already exists
        matched_resume_path = os.path.join(
            RESUME_JSON_TEXT_DIR, f"{matched_safe_name}.json"
        )
        matched_char_count = None

        if os.path.exists(matched_resume_path):
            matched_char_count = get_resume_character_count(matched_resume_path)
            logger.info(
                f"Found existing resume for matched candidate: {matched_char_count} chars"
            )
        else:
            # Download and extract matched candidate's resume
            logger.info(
                f"Downloading resume for matched candidate: {matched_safe_name}"
            )
            success, _, text_path = download_and_extract_single_resume(
                matched_candidate_data, matched_safe_name
            )
            if success and text_path:
                matched_char_count = get_resume_character_count(text_path)
                logger.info(
                    f"Downloaded matched candidate resume: {matched_char_count} chars"
                )
            else:
                logger.warning(f"Failed to download matched candidate resume")

        # Compare character counts
        if current_char_count is not None and matched_char_count is not None:
            # Allow small variance (±5%) to account for minor formatting differences
            variance_threshold = 0.05
            max_diff = max(current_char_count, matched_char_count) * variance_threshold
            char_diff = abs(current_char_count - matched_char_count)

            resumes_identical = char_diff <= max_diff

            if resumes_identical:
                comparison_result = f"Resumes appear identical (diff: {char_diff} chars, ±{variance_threshold*100}% threshold)"
                logger.info(f"Resume comparison: IDENTICAL - {comparison_result}")
            else:
                comparison_result = (
                    f"Resumes differ significantly (diff: {char_diff} chars)"
                )
                logger.info(f"Resume comparison: DIFFERENT - {comparison_result}")

            return (
                resumes_identical,
                comparison_result,
                current_char_count,
                matched_char_count,
            )
        else:
            comparison_result = "Unable to compare resumes - download/extraction failed"
            logger.warning(comparison_result)
            return False, comparison_result, current_char_count, matched_char_count

    except Exception as e:
        error_msg = f"Error during resume comparison: {str(e)}"
        logger.error(error_msg)
        return False, error_msg, None, None


def is_matched_candidate_old_enough(
    current_apply_date_str: str, matched_apply_date_str: str, months_threshold: int = 6
) -> Tuple[bool, str]:
    """
    Check if the matched candidate's apply date is at least X months older than current candidate's apply date.

    Args:
        current_apply_date_str: Current candidate's apply date string
        matched_apply_date_str: Matched candidate's apply date string
        months_threshold: Number of months threshold (default 6)

    Returns:
        Tuple[bool, str]: (is_old_enough, reason_message)
    """
    try:
        current_apply_date = datetime.fromisoformat(current_apply_date_str)
        matched_apply_date = datetime.fromisoformat(matched_apply_date_str)

        # Calculate the threshold date (6 months before current candidate's apply date)
        threshold_date = current_apply_date - timedelta(
            days=30 * months_threshold
        )  # Approximate months

        is_old = matched_apply_date < threshold_date
        days_diff = (current_apply_date - matched_apply_date).days

        if is_old:
            reason = f"Matched candidate applied {days_diff} days before current candidate (>{months_threshold} months gap)"
        else:
            reason = f"Matched candidate applied {days_diff} days before current candidate (<{months_threshold} months gap)"

        logger.info(f"Date comparison: {reason}")
        return is_old, reason

    except Exception as e:
        error_msg = f"Error parsing apply dates - current: '{current_apply_date_str}', matched: '{matched_apply_date_str}': {str(e)}"
        logger.error(error_msg)
        return False, error_msg


def check_job_role_match(matched_candidate_data: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Check if the matched candidate is applying for the same job role or a different one.

    Args:
        matched_candidate_data: The matched candidate's data from API

    Returns:
        Tuple[bool, str]: (is_same_job_role, description)
    """
    try:
        # Get the job information from matched candidate
        jobs = matched_candidate_data.get("jobs", {})
        matched_job_id = jobs.get("job_id", "")

        # Compare with current JOB_ID from constants
        is_same_job = str(matched_job_id) == str(JOB_ID)

        if is_same_job:
            description = f"Same job role (Job ID: {matched_job_id})"
            logger.info(f"Job role check: SAME JOB - {description}")
        else:
            description = f"Different job role (Matched Job ID: {matched_job_id}, Current Job ID: {JOB_ID})"
            logger.info(f"Job role check: DIFFERENT JOB - {description}")

        return is_same_job, description

    except Exception as e:
        error_msg = f"Error checking job role match: {str(e)}"
        logger.error(error_msg)
        return False, error_msg


def detect_latest_duplicate(
    current_status: str = "New",
    current_candidate_data: Optional[Dict[str, Any]] = None,
) -> dict | None:
    """
    Find the latest duplicate candidate by matching phone OR email,
    checking in order: historical_rejected → interview_stage → same_batch

    Enhanced with date-first logic and job role checking for interview stage duplicates.

    Returns duplicate details or None if no duplicate found
    """
    # Extract data from current_candidate_data
    current_id = current_candidate_data.get(
        "prospect_id", current_candidate_data.get("id", "")
    )
    first_name = current_candidate_data.get("first_name", "")
    last_name = current_candidate_data.get("last_name", "").strip()
    current_apply_date = current_candidate_data.get("apply_date", "")
    email = current_candidate_data.get("email", "")
    phone = current_candidate_data.get("prospect_phone") or current_candidate_data.get(
        "phone", ""
    )

    # Normalize contact information
    norm_email = (email or "").strip().lower()
    norm_phone = (phone or "").strip()

    # Create a match checker function that will be passed to the API search
    def check_for_matching_candidates(applicants):
        """
        Check if any of the found applicants match our phone/email criteria.
        Returns True if a match is found (stop searching), False to continue.
        """
        nonlocal historical_rejected, interview_stage_duplicate

        for candidate in applicants:
            candidate_id = candidate.get("id")
            if not candidate_id or candidate_id == current_id:
                continue

            apply_date = candidate.get("apply_date")
            if not apply_date:
                continue

            try:
                details = get_applicant_by_id(candidate_id)
            except Exception as e:
                logger.error(f"Error fetching candidate {candidate_id}: {str(e)}")
                continue

            # Get candidate status
            status = (
                (details.get("jobs", {}).get("applicant_progress", "") or "")
                .strip()
                .lower()
            )

            # Check contact matches
            cand_phone = (
                details.get("prospect_phone") or details.get("phone") or ""
            ).strip()
            cand_email = (details.get("email") or "").strip().lower()

            phone_match = norm_phone and cand_phone and cand_phone == norm_phone
            email_match = norm_email and cand_email and cand_email == norm_email

            if not (phone_match or email_match):
                continue

            # Determine match type
            match_type = (
                "phone and email"
                if phone_match and email_match
                else "phone" if phone_match else "email"
            )

            # Enhanced duplicate info with candidate details
            duplicate_info = {
                "duplicate_of": candidate_id,
                "apply_date": apply_date,
                "status": status,
                "match_type": match_type,
                "matched_candidate": {
                    "id": candidate_id,
                    "phone": cand_phone,
                    "email": cand_email,
                    "status": status,
                    "apply_date": apply_date,
                    "first_name": details.get("first_name", ""),
                    "last_name": details.get("last_name", ""),
                },
                "current_candidate": {
                    "id": current_id,
                    "phone": phone,
                    "email": email,
                    "status": current_status,
                    "apply_date": current_apply_date,
                    "first_name": first_name,
                    "last_name": last_name,
                },
            }

            # Enhanced processing with date-first logic
            duplicate_action = "reject"  # default action
            date_reason = ""

            # If we have candidate data, perform date-first analysis
            if current_candidate_data and current_apply_date:
                logger.info(
                    f"Performing date-first duplicate analysis for {candidate_id}"
                )

                # First check: Is matched candidate 6+ months older than current candidate?
                is_old_enough, date_reason = is_matched_candidate_old_enough(
                    current_apply_date, apply_date, months_threshold=6
                )

                if is_old_enough:
                    # Matched candidate is old enough - proceed with resume comparison
                    logger.info(
                        f"Matched candidate is old enough ({date_reason}) - proceeding with resume comparison"
                    )

                    # Generate safe name for current candidate using correct format
                    current_safe_name = (
                        f"{first_name}_{last_name}_{current_id}".replace(
                            " ", "_"
                        ).replace("/", "_")
                    )

                    # Download and compare resumes
                    (
                        resumes_identical,
                        comparison_result,
                        current_chars,
                        matched_chars,
                    ) = download_and_compare_resumes(
                        current_candidate_data, details, current_safe_name
                    )

                    # Add resume comparison info to duplicate info
                    duplicate_info["resume_comparison"] = {
                        "resumes_identical": resumes_identical,
                        "comparison_result": comparison_result,
                        "current_char_count": current_chars,
                        "matched_char_count": matched_chars,
                    }

                    if resumes_identical:
                        # Old application with identical resumes - reject
                        duplicate_action = "reject"
                        duplicate_info["processing_decision"] = {
                            "action": "reject",
                            "reason": f"Identical resumes with old application ({date_reason})",
                            "icon": "❌",
                            "date_analysis": date_reason,
                        }
                        logger.info(
                            f"Decision: REJECT - Identical resumes with old application"
                        )
                    else:
                        # Old application with different resumes - allow with warning
                        duplicate_action = "warn_and_process"
                        duplicate_info["processing_decision"] = {
                            "action": "warn_and_process",
                            "reason": f"Different resumes with old application ({date_reason})",
                            "icon": "⚠️",
                            "date_analysis": date_reason,
                        }
                        logger.info(
                            f"Decision: WARN AND PROCESS - Different resumes with old application"
                        )
                else:
                    # Matched candidate is too recent - reject without resume comparison
                    duplicate_action = "reject"
                    duplicate_info["processing_decision"] = {
                        "action": "reject",
                        "reason": "Recent duplicate application - no resume comparison needed",
                        "icon": "❌",
                        "date_analysis": date_reason,
                    }
                    logger.info(
                        f"Decision: REJECT - Recent duplicate, skipping resume comparison"
                    )
                    # No resume comparison performed
                    duplicate_info["resume_comparison"] = {
                        "resumes_identical": None,
                        "comparison_result": "Skipped - matched candidate too recent",
                        "current_char_count": None,
                        "matched_char_count": None,
                    }
            else:
                # No candidate data provided - use original logic
                date_reason = "No candidate data provided for enhanced analysis"
                duplicate_info["processing_decision"] = {
                    "action": "reject",
                    "reason": "Standard duplicate detection (no date/resume comparison)",
                    "icon": "❌",
                    "date_analysis": date_reason,
                }

            # Check if this is a rejection status - PRESERVE THE PROCESSING DECISION
            if status in REJECTION_STATUSES:
                # Update historical_rejected if this is more recent
                try:
                    candidate_dt = datetime.fromisoformat(apply_date)
                    if (
                        not historical_rejected
                        or candidate_dt
                        > datetime.fromisoformat(historical_rejected["apply_date"])
                    ):
                        historical_rejected = {
                            **duplicate_info,  # This includes the processing_decision we just set
                            "duplicate_type": "historical_rejected",
                        }
                except ValueError:
                    if not historical_rejected:
                        historical_rejected = {
                            **duplicate_info,  # This includes the processing_decision we just set
                            "duplicate_type": "historical_rejected",
                        }

            # Check if this is an interview-stage candidate (not rejected, not new)
            elif status != "new":
                # Enhanced interview stage handling with job role check
                is_same_job_role, job_role_description = check_job_role_match(details)

                # Add job role information to duplicate info
                duplicate_info["job_role_check"] = {
                    "is_same_job_role": is_same_job_role,
                    "description": job_role_description,
                    "matched_job_id": details.get("jobs", {}).get("job_id", ""),
                    "current_job_id": JOB_ID,
                }

                if is_same_job_role:
                    # Same job role - candidate is in interview stage for current position
                    # Override processing decision for same job role interview stage
                    duplicate_info["processing_decision"] = {
                        "action": "reject",
                        "reason": f"Candidate already in interview stage for same job role ({job_role_description})",
                        "icon": "❌",
                        "date_analysis": date_reason,
                        "job_role_analysis": job_role_description,
                    }
                    logger.info(f"Interview stage - same job role: REJECT")
                else:
                    # Different job role - candidate is in interview stage for different position
                    # Keep existing processing decision but add job role context
                    existing_decision = duplicate_info.get("processing_decision", {})
                    existing_decision["job_role_analysis"] = job_role_description
                    duplicate_info["processing_decision"] = existing_decision
                    logger.info(
                        f"Interview stage - different job role: {existing_decision.get('action', 'reject').upper()}"
                    )

                # Update interview_stage_duplicate if this is more recent
                try:
                    candidate_dt = datetime.fromisoformat(apply_date)
                    if (
                        not interview_stage_duplicate
                        or candidate_dt
                        > datetime.fromisoformat(
                            interview_stage_duplicate["apply_date"]
                        )
                    ):
                        interview_stage_duplicate = {
                            **duplicate_info,  # This includes the updated processing_decision
                            "duplicate_type": "interview_stage",
                        }
                except ValueError:
                    if not interview_stage_duplicate:
                        interview_stage_duplicate = {
                            **duplicate_info,  # This includes the updated processing_decision
                            "duplicate_type": "interview_stage",
                        }

        # Return True if we found any matching candidates (historical_rejected or interview_stage)
        # This will stop the search since we found what we're looking for
        return historical_rejected is not None or interview_stage_duplicate is not None

    # Initialize variables to track duplicates
    historical_rejected = None
    interview_stage_duplicate = None

    # Search for potential matches by name using chunked search with match checker
    # The match checker function processes candidates and updates the variables above
    get_applicants_by_full_name(
        first_name,
        last_name,
        current_apply_date,
        match_checker_func=check_for_matching_candidates,
    )

    # Priority 1: Return historical rejected duplicate if found
    if historical_rejected:
        logger.info(
            f"Historical rejected duplicate found: {current_id} duplicates {historical_rejected['duplicate_of']}"
        )
        return historical_rejected

    # Priority 2: Return interview-stage duplicate if found
    if interview_stage_duplicate:
        logger.info(
            f"Interview-stage duplicate found: {current_id} duplicates {interview_stage_duplicate['duplicate_of']}"
        )
        return interview_stage_duplicate

    # Priority 3: Check for same-batch duplicates (with enhanced processing)
    same_batch_duplicate = None
    registry_entries = []

    # Check email match
    if norm_email and norm_email in contact_registry:
        entry = contact_registry[norm_email]
        if entry["id"] and entry["id"] != current_id:
            registry_entries.append(("email", entry))

    # Check phone match
    if norm_phone and norm_phone in contact_registry:
        entry = contact_registry[norm_phone]
        if entry["id"] and entry["id"] != current_id:
            registry_entries.append(("phone", entry))

    # Find the latest same-batch duplicate
    if registry_entries:
        try:
            match_type, latest_entry = max(
                registry_entries,
                key=lambda x: datetime.fromisoformat(x[1]["apply_date"]),
            )
        except Exception:
            match_type, latest_entry = registry_entries[0]  # Fallback to first

        same_batch_duplicate = {
            "duplicate_of": latest_entry["id"],
            "apply_date": latest_entry["apply_date"],
            "status": latest_entry["status"],
            "duplicate_type": "same_batch",
            "match_type": match_type,
            "matched_candidate": {
                "id": latest_entry["id"],
                "phone": latest_entry["phone"],
                "email": latest_entry["email"],
                "status": latest_entry["status"],
                "apply_date": latest_entry["apply_date"],
                "first_name": "",  # Not available in registry
                "last_name": "",  # Not available in registry
            },
            "current_candidate": {
                "id": current_id,
                "phone": phone,
                "email": email,
                "status": current_status,
                "apply_date": current_apply_date,
                "first_name": first_name,
                "last_name": last_name,
            },
            # For same-batch, we don't have full candidate data for resume comparison
            "processing_decision": {
                "action": "reject",
                "reason": "Same-batch duplicate (no date/resume comparison available)",
                "icon": "❌",
            },
        }
        logger.info(
            f"Same-batch duplicate found: {current_id} duplicates {same_batch_duplicate['duplicate_of']}"
        )
        return same_batch_duplicate

    # No duplicates found - register candidate with enhanced info
    candidate_info = {
        "id": current_id,
        "apply_date": current_apply_date,
        "status": current_status,
        "email": norm_email,
        "phone": norm_phone,
    }

    if norm_email:
        contact_registry[norm_email] = candidate_info
    if norm_phone:
        contact_registry[norm_phone] = candidate_info

    return None
