import logging
import google.generativeai as genai
from google.api_core import exceptions, retry

from config.constants import GEMINI_MODEL
from config.env_config import GEMINI_API_KEY

logger = logging.getLogger(__name__)

# Configure API and model once at module load
genai.configure(api_key=GEMINI_API_KEY)
MODEL = genai.GenerativeModel(GEMINI_MODEL)


# Custom retry predicate for transient errors
def _is_retryable_error(exc):
    return isinstance(
        exc,
        (
            exceptions.ResourceExhausted,
            exceptions.ServiceUnavailable,
            exceptions.DeadlineExceeded,
            exceptions.InternalServerError,
            exceptions.TooManyRequests,
        ),
    )


# Configure exponential backoff with jitter
retry_policy = retry.Retry(
    predicate=_is_retryable_error,
    initial=1.0,  # Initial delay (seconds)
    maximum=60.0,  # Max delay
    multiplier=2.0,  # Exponential factor
    deadline=300.0,  # Max total time (5 minutes)
)


def query_gemini(prompt: str) -> genai.types.GenerateContentResponse:
    """
    Query Gemini API with robust error handling and retry mechanism

    Args:
        prompt: Input prompt for the model

    Returns:
        Raw Gemini response object (caller should use response.text)

    Raises:
        Permanent errors after retries
    """
    try:
        # Execute query and return response OBJECT
        return _execute_gemini_query(prompt)
    except Exception as e:
        logger.exception("Gemini query failed after retries")
        raise RuntimeError(f"Gemini query failed: {str(e)}") from e


def _execute_gemini_query(prompt: str) -> genai.types.GenerateContentResponse:
    """Internal function to execute the Gemini query without retry logic"""
    logger.info(
        f"Querying Gemini with prompt [{prompt[:50]}...] (length: {len(prompt)})"
    )

    try:
        response = MODEL.generate_content(
            prompt,
            generation_config=genai.types.GenerationConfig(
                temperature=0.0,
                max_output_tokens=8000,
                top_p=1.0,
                top_k=40,
                candidate_count=1,
            ),
            request_options={"timeout": 120},  # 2-minute timeout per request
        )

        # Validate we got a response object
        if not response:
            logger.error("Empty response object received")
            raise ValueError("Gemini returned empty response")

        logger.debug("Successful API response received")
        return response

    except exceptions.InvalidArgument as e:
        logger.error("Invalid request parameters: %s", str(e))
        raise ValueError("Invalid request parameters") from e

    except exceptions.NotFound as e:
        logger.critical("Resource not found: %s", str(e))
        raise RuntimeError("API resource not found") from e

    except exceptions.PermissionDenied as e:
        logger.critical("Permission denied: %s", str(e))
        raise RuntimeError("API permission error") from e

    except genai.types.BlockedPromptException as e:
        logger.error("Prompt blocked by safety filters: %s", str(e))
