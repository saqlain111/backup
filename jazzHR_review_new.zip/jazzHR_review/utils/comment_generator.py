from loaders.template_loader import load_template
import logging
import re

logger = logging.getLogger(__name__)


def _generate_experience_section(experience_details: dict) -> tuple[str, str]:
    """
    Build a concise experience evaluation section for management review.
    Returns (section_text, status_override).
    """
    if not experience_details:
        return "", None

    total_months = experience_details.get("total_months", 0)
    total_years = experience_details.get("total_years", 0)
    threshold_months = experience_details.get("threshold_months", 0)
    threshold_years = experience_details.get("threshold_years", 0)
    processed_jobs = experience_details.get("processed_jobs", 0)

    # Determine qualification status
    is_qualified = total_months >= threshold_months

    section_lines = []

    # Main status with detailed metrics
    if is_qualified:
        icon = "✅"
        status = "QUALIFIED"
        status_override = None

        # Show excess experience
        excess_months = total_months - threshold_months
        excess_years = round(excess_months / 12, 1)
        if excess_months > 0:
            section_lines.append(
                f"- Status: {icon} {status} (Exceeds by {excess_months} months / {excess_years} years)"
            )
        else:
            section_lines.append(f"- Status: {icon} {status} (Meets exactly)")
    else:
        icon = "❌"
        status = "NOT QUALIFIED"
        status_override = f"❌ Experience Requirements Not Met"

        # Show experience gap
        gap_months = threshold_months - total_months
        gap_years = round(gap_months / 12, 1)
        section_lines.append(
            f"- Status: {icon} {status} (Short by {gap_months} months / {gap_years} years)"
        )

    # Core metrics
    section_lines.extend(
        [
            f"- Total Experience: {total_months} months ({total_years} years)",
            f"- Required Threshold: {threshold_months} months ({threshold_years} years)",
            f"- Jobs Processed: {processed_jobs}",
        ]
    )

    # Processing errors/warnings
    processing_errors = experience_details.get("processing_errors", [])
    if processing_errors:
        section_lines.append(
            f"- Processing Issues: {len(processing_errors)} job(s) had parsing errors"
        )
        if status_override is None:  # Only add warning if not already failed
            status_override = f"⚠️ Experience Warning - Some Jobs Had Processing Issues"

        # Show first few errors (truncated)
        for i, error in enumerate(processing_errors[:2], 1):  # Show max 2 errors
            if len(error) > 80:
                error = error[:77] + "..."
            section_lines.append(f"  - Issue {i}: {error}")

        if len(processing_errors) > 2:
            section_lines.append(
                f"  - ... and {len(processing_errors) - 2} more issues"
            )

    section = "\n".join(section_lines)
    return section, status_override


def _generate_education_section(education_info: dict) -> tuple[str, str]:
    """
    Build a concise education evaluation section for management review.
    Returns (section_text, status_override).
    """
    if not education_info:
        return "", None

    qualification_status = education_info.get("qualification_status")
    reason = education_info.get("reason", "")
    education_data = education_info.get("education_data", [])

    section_lines = []

    # Main status
    if qualification_status is True:
        if "warning" in education_info or "error" in education_info:
            icon = "⚠️"
            status = "QUALIFIED (with warning)"
            status_override = f"⚠️ Education Warning - Processing Allowed"
        else:
            icon = "✅"
            status = "QUALIFIED"
            status_override = None
    elif qualification_status is False:
        icon = "❌"
        status = "NOT QUALIFIED"
        status_override = f"❌ Education Requirements Not Met"
    else:
        icon = "❓"
        status = "UNKNOWN"
        status_override = f"❓ Education Status Unknown"

    section_lines.extend(
        [
            f"- Status: {icon} {status}",
        ]
    )

    # Add reason if available
    if reason:
        section_lines.append(f"- Result Reason: {reason}")

    # Add Gemini analysis if available
    gemini_analysis = education_info.get("gemini_analysis", {})
    if gemini_analysis and isinstance(gemini_analysis, dict):
        highest_degree = gemini_analysis.get("highest_degree", "Unknown")
        relevant_field = gemini_analysis.get("relevant_field", "Unknown")
        confidence = gemini_analysis.get("confidence", "Unknown")

        section_lines.extend(
            [
                f"- AI Analysis:",
                f"  - Highest Degree: {highest_degree}",
                f"  - Relevant Field: {relevant_field}",
                f"  - Confidence: {confidence}",
            ]
        )

        # Show qualifying degree if available
        qualifying_degree = gemini_analysis.get("qualifying_degree")
        if qualifying_degree:
            section_lines.append(f"  - Qualifying Degree: {qualifying_degree}")

        # Show detailed analysis (truncated if too long)
        detailed_analysis = gemini_analysis.get("detailed_analysis", "")
        if detailed_analysis and detailed_analysis != "No detailed analysis provided":
            if len(detailed_analysis) > 150:
                detailed_analysis = detailed_analysis
            section_lines.append(f"  - Analysis: {detailed_analysis}")

    # Add warnings or errors
    if "warning" in education_info:
        section_lines.append(f"- Warning: {education_info['warning']}")

    if "error" in education_info:
        section_lines.append(f"- Error: {education_info['error']}")

    section = "\n".join(section_lines)
    return section, status_override


def _generate_duplicate_section(duplicate_info: dict) -> tuple[str, str]:
    """
    Build a concise duplicate evaluation section for management review.
    Returns (section_text, status_override).
    """
    if not duplicate_info:
        return "", None

    status = duplicate_info.get("status", "unknown")
    current_id = duplicate_info.get("prospect_id", "current candidate")

    if status == "duplicate":
        # Extract key information
        dup_id = duplicate_info.get("duplicate_of", "unknown")
        apply_date = duplicate_info.get("apply_date", "unknown date")
        raw_duplicate_type = duplicate_info.get("duplicate_type", "unknown")
        match_type = (
            duplicate_info.get("match_type", "unknown").replace("_", " ").title()
        )

        # Determine display name for duplicate type based on processing decision
        processing_decision = duplicate_info.get("processing_decision", {})
        decision_reason = processing_decision.get("reason", "Standard duplicate")

        # Override duplicate type display name based on actual rejection reason
        if raw_duplicate_type == "interview_stage":
            job_role_check = duplicate_info.get("job_role_check", {})
            is_same_job_role = job_role_check.get("is_same_job_role", False)

            if is_same_job_role:
                duplicate_type = "Active Interview (Same Role)"
            elif (
                "Recent duplicate" in decision_reason
                or "too recent" in decision_reason.lower()
            ):
                duplicate_type = "Recent Duplicate"
            elif "old application" in decision_reason.lower():
                duplicate_type = "Historical Application"
            else:
                duplicate_type = "Interview Stage (Different Role)"
        else:
            duplicate_type = raw_duplicate_type.replace("_", " ").title()

        # Get processing decision
        action = processing_decision.get("action", "reject")
        decision_icon = processing_decision.get("icon", "❌")
        date_analysis = processing_decision.get("date_analysis", "")
        job_role_analysis = processing_decision.get("job_role_analysis", "")

        # Get candidate details
        matched_candidate = duplicate_info.get("matched_candidate", {})
        current_candidate = duplicate_info.get("current_candidate", {})

        # Get job role check details
        job_role_check = duplicate_info.get("job_role_check", {})

        # Build concise section
        section_lines = []

        # Core duplicate information
        section_lines.extend(
            [
                f"- Duplicate Type: {decision_icon} {duplicate_type}",
                f"- Match Method: {match_type}",
                f"- Processing Decision: {action.replace('_', ' ').title()}",
                f"- Decision Reason: {decision_reason}",
            ]
        )

        # Job role analysis for interview stage duplicates
        if job_role_check and raw_duplicate_type == "interview_stage":
            is_same_job_role = job_role_check.get("is_same_job_role", False)
            matched_job_id = job_role_check.get("matched_job_id", "N/A")
            current_job_id = job_role_check.get("current_job_id", "N/A")

            if is_same_job_role:
                section_lines.append(
                    f"- Job Role: 🎯 Same position (Job ID: {current_job_id})"
                )
                section_lines.append(
                    f"- Impact: ❌ Auto-reject (Active candidate for same role)"
                )
            else:
                section_lines.append(
                    f"- Job Role: 🔄 Different position (Matched: {matched_job_id}, Current: {current_job_id})"
                )
                section_lines.append(
                    f"- Impact: ℹ️ Different role - Following enhanced analysis"
                )
        elif job_role_analysis:
            # Fallback if we have job_role_analysis but not full job_role_check
            section_lines.append(f"- Job Role: {job_role_analysis}")

        # Date analysis (concise)
        if date_analysis:
            # Extract key info from date analysis
            if "days before" in date_analysis:
                section_lines.append(f"- Time Gap: {date_analysis}")
            else:
                section_lines.append(f"- Date Analysis: {date_analysis}")

        # Resume comparison (concise)
        resume_comparison = duplicate_info.get("resume_comparison", {})
        if resume_comparison:
            resumes_identical = resume_comparison.get("resumes_identical")
            comparison_result = resume_comparison.get("comparison_result", "")

            if resumes_identical is not None:
                identical_status = (
                    "✅ Identical" if resumes_identical else "❌ Different"
                )
                section_lines.append(f"- Resume Comparison: {identical_status}")
            else:
                if "too recent" in comparison_result.lower():
                    section_lines.append(
                        f"- Resume Comparison: ⏭️ Skipped (Recent duplicate)"
                    )
                elif "same job role" in comparison_result.lower() or (
                    job_role_check and job_role_check.get("is_same_job_role")
                ):
                    section_lines.append(
                        f"- Resume Comparison: ⏭️ Skipped (Same job role)"
                    )
                else:
                    section_lines.append(f"- Resume Comparison: ❌ Not performed")
        elif (
            raw_duplicate_type == "interview_stage"
            and job_role_check
            and job_role_check.get("is_same_job_role")
        ):
            # For same job role interview stage, explicitly mention resume comparison was skipped
            section_lines.append(
                f"- Resume Comparison: ⏭️ Skipped (Same job role = auto-reject)"
            )

        # Candidate information (essential only)
        current_name = "Unknown"
        matched_name = "Unknown"

        if current_candidate:
            current_name = (
                f"{current_candidate.get('first_name', '')} {current_candidate.get('last_name', '')}".strip()
                or "Unknown"
            )
            current_apply_date = current_candidate.get("apply_date", "N/A")
            section_lines.append(
                f"- Current: {current_name} (ID: {current_id}, Applied: {current_apply_date})"
            )

        if matched_candidate:
            matched_name = (
                f"{matched_candidate.get('first_name', '')} {matched_candidate.get('last_name', '')}".strip()
                or "Unknown"
            )
            matched_status = matched_candidate.get("status", "unknown").title()
            matched_apply_date = matched_candidate.get("apply_date", "N/A")

            # Include job ID for interview stage duplicates
            if raw_duplicate_type == "interview_stage" and job_role_check:
                matched_job_id = job_role_check.get("matched_job_id", "N/A")
                section_lines.append(
                    f"- Matched: {matched_name} (ID: {dup_id}, Status: {matched_status}, Job: {matched_job_id}, Applied: {matched_apply_date})"
                )
            else:
                section_lines.append(
                    f"- Matched: {matched_name} (ID: {dup_id}, Status: {matched_status}, Applied: {matched_apply_date})"
                )

        section = "\n".join(section_lines)

        # Enhanced status override based on action and job role
        if action == "warn_and_process":
            if (
                raw_duplicate_type == "interview_stage"
                and job_role_check
                and not job_role_check.get("is_same_job_role")
            ):
                status_override = (
                    f"⚠️ Duplicate Warning ({duplicate_type}) - Processing Allowed"
                )
            else:
                status_override = (
                    f"⚠️ Duplicate Warning ({duplicate_type}) - Processing Allowed"
                )
        else:
            if raw_duplicate_type == "interview_stage" and job_role_check:
                if job_role_check.get("is_same_job_role"):
                    status_override = f"❌ Duplicate Candidate ({duplicate_type})"
                else:
                    status_override = f"❌ Duplicate Candidate ({duplicate_type})"
            else:
                status_override = f"❌ Duplicate Candidate ({duplicate_type})"

        return section, status_override

    else:  # Unique candidate
        section_lines = [
            "- Status: ✅ Unique Candidate",
            f"- Prospect ID: {current_id}",
            "- No duplicates found",
        ]

        # Add name if available
        candidate_name = f"{duplicate_info.get('first_name', '')} {duplicate_info.get('last_name', '')}".strip()
        if candidate_name:
            section_lines.insert(-1, f"- Name: {candidate_name}")

        section = "\n".join(section_lines)
        return section, None


def _generate_resume_parsing_section(parsing_details: dict) -> str:
    """Generate resume parsing evaluation section"""
    if not parsing_details:
        return ""

    status_map = {
        "error": ("❌", parsing_details.get("error", "Error")),
        "insufficient_text": (
            "❌",
            f"Insufficient text ({parsing_details['char_count']} chars)",
        ),
        "success": ("✅", f"Parsable Resume ({parsing_details['char_count']} chars)"),
    }

    status, reason = status_map.get(
        parsing_details.get("status"), ("", "Unknown parsing status")
    )
    return f"- {status} {reason}"


def _generate_location_section(location_details: dict) -> tuple:
    """Generate location evaluation section and determine status impact"""
    if not location_details:
        return "", None

    section_lines = []
    status_override = None
    match_found = False

    for field, details in location_details.items():
        formatted_field = field.replace("_", " ").title()
        reason = details.get("reason", "")

        if reason == "Field empty":
            status_icon = "⚠️"
            if not match_found and not status_override:
                status_override = "⚠️ Human Evaluation Needed - Empty Fields Detected"
        elif details.get("match", False):
            status_icon = "✅"
            match_found = True
            status_override = "✅ Passed"
        else:
            status_icon = "❌"

        section_lines.append(f"- {formatted_field}: {status_icon} {reason}")

    return "\n".join(section_lines), status_override


def _generate_prefilter_section(evaluation_result: dict) -> str:
    """Generate prefilter evaluation section"""
    eval_template = load_template("prefilter_evaluation/result")
    resume_template = load_template("prefilter_evaluation/resume_parsing_evaluation")
    location_template = load_template("prefilter_evaluation/location_evaluation")
    experience_template = load_template("prefilter_evaluation/experience_evaluation")
    duplicate_template = load_template("prefilter_evaluation/duplicate_evaluation")
    education_template = load_template("prefilter_evaluation/education_evaluation")

    # Default values
    status = "No pre-filter evaluation data available"
    reasons_section = ""
    resume_section = ""
    location_section = ""
    experience_section = ""
    duplicate_section = ""
    education_section = ""

    if not evaluation_result:
        return eval_template.format(
            status=status,
            reasons_section=reasons_section,
            resume_parsing_evaluation=resume_section,
            location_evaluation=location_section,
            duplicate_section=duplicate_section,
            education_section=education_section,
        )

    # Initial status setup
    status = "✅ Passed" if evaluation_result.get("passed") else "❌ Rejected"

    # Reasons section
    if reasons := evaluation_result.get("reasons", []):
        reasons_section = f"Reasons: {', '.join(reasons)}\n"

    # Resume parsing section
    if parsing_details := evaluation_result.get("parsing_details"):
        if parsed_section := _generate_resume_parsing_section(parsing_details):
            resume_section = resume_template.format(
                resume_parsing_details_section=parsed_section
            )

    # Location evaluation section
    if location_details := evaluation_result.get("location_details"):
        location_output, status_override = _generate_location_section(location_details)
        if location_output:
            location_section = location_template.format(
                location_details_section=location_output
            )
        if status_override:
            status = status_override

    # Experience evaluation section
    if experience_details := evaluation_result.get("experience_details"):
        exp_output, status_override = _generate_experience_section(experience_details)
        if exp_output:
            experience_template = load_template(
                "prefilter_evaluation/experience_evaluation"
            )
            experience_section = experience_template.format(
                experience_details_section=exp_output
            )
        if status_override and not evaluation_result.get("passed"):
            status = status_override

    # Duplicate evaluation section
    if dup_info := evaluation_result.get("duplicate_candidate_details"):
        dup_text, dup_override = _generate_duplicate_section(dup_info)
        if dup_text:
            duplicate_section = duplicate_template.format(
                duplicate_evaluation_section=dup_text
            )
        if dup_override:
            status = dup_override

    # Education evaluation section
    if education_info := evaluation_result.get("education_details"):
        edu_text, edu_override = _generate_education_section(education_info)
        if edu_text:
            education_section = education_template.format(
                education_evaluation_section=edu_text
            )
        if edu_override:
            status = edu_override

    return eval_template.format(
        status=status,
        reasons_section=reasons_section,
        resume_parsing_evaluation=resume_section,
        location_evaluation=location_section,
        experience_evaluation=experience_section,
        duplicate_evaluation=duplicate_section,
        education_evaluation=education_section,
    )


def _generate_analysis_section(analysis: str, score: int, level_summary: str) -> str:
    """Generate AI analysis section for qualified candidates"""
    template = load_template("ai_analysis/result")
    return template.format(
        analysis=analysis.strip() if analysis else "No analysis available",
        score=score,
        level_evaluation_summary=level_summary.strip() if level_summary else "",
    )


def generate_final_comment(
    analysis: str = None,
    score: int = None,
    level_summary: str = None,
    evaluation_result: dict = None,
) -> str:
    """
    Generate appropriate comment based on available data
    Includes evaluation results for all candidate types
    """
    try:
        # Generate prefilter section
        eval_section = _generate_prefilter_section(evaluation_result)

        # Generate analysis section for qualified candidates
        if score is not None:
            analysis_section = _generate_analysis_section(
                analysis, score, level_summary
            )
            full_comment = eval_section + analysis_section
        else:
            full_comment = (
                eval_section + "🚫 Candidate rejected during pre-filter evaluation"
            )

        # Clean up excessive newlines
        return re.sub(r"\n{3,}", "\n\n", full_comment)

    except Exception as e:
        logger.error(f"Error generating comment: {str(e)}", exc_info=True)
        return "Automated evaluation completed - error generating details"
