from loaders.template_loader import load_template
import logging
import re

logger = logging.getLogger(__name__)


def _generate_duplicate_section(duplicate_info: dict) -> tuple[str, str]:
    """
    Build a concise duplicate evaluation section for management review.
    Returns (section_text, status_override).
    """
    if not duplicate_info:
        return "", None

    status = duplicate_info.get("status", "unknown")
    current_id = duplicate_info.get("prospect_id", "current candidate")

    if status == "duplicate":
        # Extract key information
        dup_id = duplicate_info.get("duplicate_of", "unknown")
        apply_date = duplicate_info.get("apply_date", "unknown date")
        raw_duplicate_type = duplicate_info.get("duplicate_type", "unknown")
        match_type = (
            duplicate_info.get("match_type", "unknown").replace("_", " ").title()
        )

        # Determine display name for duplicate type based on processing decision
        processing_decision = duplicate_info.get("processing_decision", {})
        decision_reason = processing_decision.get("reason", "Standard duplicate")

        # Override duplicate type display name based on actual rejection reason
        if raw_duplicate_type == "interview_stage":
            job_role_check = duplicate_info.get("job_role_check", {})
            is_same_job_role = job_role_check.get("is_same_job_role", False)

            if is_same_job_role:
                duplicate_type = "Active Interview (Same Role)"
            elif (
                "Recent duplicate" in decision_reason
                or "too recent" in decision_reason.lower()
            ):
                duplicate_type = "Recent Duplicate"
            elif "old application" in decision_reason.lower():
                duplicate_type = "Historical Application"
            else:
                duplicate_type = "Interview Stage (Different Role)"
        else:
            duplicate_type = raw_duplicate_type.replace("_", " ").title()

        # Get processing decision
        action = processing_decision.get("action", "reject")
        decision_icon = processing_decision.get("icon", "❌")
        date_analysis = processing_decision.get("date_analysis", "")
        job_role_analysis = processing_decision.get("job_role_analysis", "")

        # Get candidate details
        matched_candidate = duplicate_info.get("matched_candidate", {})
        current_candidate = duplicate_info.get("current_candidate", {})

        # Get job role check details
        job_role_check = duplicate_info.get("job_role_check", {})

        # Build concise section
        section_lines = []

        # Core duplicate information
        section_lines.extend(
            [
                f"- Duplicate Type: {decision_icon} {duplicate_type}",
                f"- Match Method: {match_type}",
                f"- Processing Decision: {action.replace('_', ' ').title()}",
                f"- Decision Reason: {decision_reason}",
            ]
        )

        # Job role analysis for interview stage duplicates
        if job_role_check and raw_duplicate_type == "interview_stage":
            is_same_job_role = job_role_check.get("is_same_job_role", False)
            matched_job_id = job_role_check.get("matched_job_id", "N/A")
            current_job_id = job_role_check.get("current_job_id", "N/A")

            if is_same_job_role:
                section_lines.append(
                    f"- Job Role: 🎯 Same position (Job ID: {current_job_id})"
                )
                section_lines.append(
                    f"- Impact: ❌ Auto-reject (Active candidate for same role)"
                )
            else:
                section_lines.append(
                    f"- Job Role: 🔄 Different position (Matched: {matched_job_id}, Current: {current_job_id})"
                )
                section_lines.append(
                    f"- Impact: ℹ️ Different role - Following enhanced analysis"
                )
        elif job_role_analysis:
            # Fallback if we have job_role_analysis but not full job_role_check
            section_lines.append(f"- Job Role: {job_role_analysis}")

        # Date analysis (concise)
        if date_analysis:
            # Extract key info from date analysis
            if "days before" in date_analysis:
                section_lines.append(f"- Time Gap: {date_analysis}")
            else:
                section_lines.append(f"- Date Analysis: {date_analysis}")

        # Resume comparison (concise)
        resume_comparison = duplicate_info.get("resume_comparison", {})
        if resume_comparison:
            resumes_identical = resume_comparison.get("resumes_identical")
            comparison_result = resume_comparison.get("comparison_result", "")

            if resumes_identical is not None:
                identical_status = (
                    "✅ Identical" if resumes_identical else "❌ Different"
                )
                section_lines.append(f"- Resume Comparison: {identical_status}")
            else:
                if "too recent" in comparison_result.lower():
                    section_lines.append(
                        f"- Resume Comparison: ⏭️ Skipped (Recent duplicate)"
                    )
                elif "same job role" in comparison_result.lower() or (
                    job_role_check and job_role_check.get("is_same_job_role")
                ):
                    section_lines.append(
                        f"- Resume Comparison: ⏭️ Skipped (Same job role)"
                    )
                else:
                    section_lines.append(f"- Resume Comparison: ❌ Not performed")
        elif (
            raw_duplicate_type == "interview_stage"
            and job_role_check
            and job_role_check.get("is_same_job_role")
        ):
            # For same job role interview stage, explicitly mention resume comparison was skipped
            section_lines.append(
                f"- Resume Comparison: ⏭️ Skipped (Same job role = auto-reject)"
            )

        # Candidate information (essential only)
        current_name = "Unknown"
        matched_name = "Unknown"

        if current_candidate:
            current_name = (
                f"{current_candidate.get('first_name', '')} {current_candidate.get('last_name', '')}".strip()
                or "Unknown"
            )
            current_apply_date = current_candidate.get("apply_date", "N/A")
            section_lines.append(
                f"- Current: {current_name} (ID: {current_id}, Applied: {current_apply_date})"
            )

        if matched_candidate:
            matched_name = (
                f"{matched_candidate.get('first_name', '')} {matched_candidate.get('last_name', '')}".strip()
                or "Unknown"
            )
            matched_status = matched_candidate.get("status", "unknown").title()
            matched_apply_date = matched_candidate.get("apply_date", "N/A")

            # Include job ID for interview stage duplicates
            if raw_duplicate_type == "interview_stage" and job_role_check:
                matched_job_id = job_role_check.get("matched_job_id", "N/A")
                section_lines.append(
                    f"- Matched: {matched_name} (ID: {dup_id}, Status: {matched_status}, Job: {matched_job_id}, Applied: {matched_apply_date})"
                )
            else:
                section_lines.append(
                    f"- Matched: {matched_name} (ID: {dup_id}, Status: {matched_status}, Applied: {matched_apply_date})"
                )

        section = "\n".join(section_lines)

        # Enhanced status override based on action and job role
        if action == "warn_and_process":
            if (
                raw_duplicate_type == "interview_stage"
                and job_role_check
                and not job_role_check.get("is_same_job_role")
            ):
                status_override = (
                    f"⚠️ Duplicate Warning ({duplicate_type}) - Processing Allowed"
                )
            else:
                status_override = (
                    f"⚠️ Duplicate Warning ({duplicate_type}) - Processing Allowed"
                )
        else:
            if raw_duplicate_type == "interview_stage" and job_role_check:
                if job_role_check.get("is_same_job_role"):
                    status_override = f"❌ Duplicate Candidate ({duplicate_type})"
                else:
                    status_override = f"❌ Duplicate Candidate ({duplicate_type})"
            else:
                status_override = f"❌ Duplicate Candidate ({duplicate_type})"

        return section, status_override

    else:  # Unique candidate
        section_lines = [
            "- Status: ✅ Unique Candidate",
            f"- Prospect ID: {current_id}",
            "- No duplicates found",
        ]

        # Add name if available
        candidate_name = f"{duplicate_info.get('first_name', '')} {duplicate_info.get('last_name', '')}".strip()
        if candidate_name:
            section_lines.insert(-1, f"- Name: {candidate_name}")

        section = "\n".join(section_lines)
        return section, None


def _generate_resume_parsing_section(parsing_details: dict) -> str:
    """Generate resume parsing evaluation section"""
    if not parsing_details:
        return ""

    status_map = {
        "error": ("❌", parsing_details.get("error", "Error")),
        "insufficient_text": (
            "❌",
            f"Insufficient text ({parsing_details['char_count']} chars)",
        ),
        "success": ("✅", f"Parsable Resume ({parsing_details['char_count']} chars)"),
    }

    status, reason = status_map.get(
        parsing_details.get("status"), ("", "Unknown parsing status")
    )
    return f"- {status} {reason}"


def _generate_location_section(location_details: dict) -> tuple:
    """Generate location evaluation section and determine status impact"""
    if not location_details:
        return "", None

    section_lines = []
    status_override = None
    match_found = False

    for field, details in location_details.items():
        formatted_field = field.replace("_", " ").title()
        reason = details.get("reason", "")

        if reason == "Field empty":
            status_icon = "⚠️"
            if not match_found and not status_override:
                status_override = "⚠️ Human Evaluation Needed - Empty Fields Detected"
        elif details.get("match", False):
            status_icon = "✅"
            match_found = True
            status_override = "✅ Passed"
        else:
            status_icon = "❌"

        section_lines.append(f"- {formatted_field}: {status_icon} {reason}")

    return "\n".join(section_lines), status_override


def _generate_prefilter_section(evaluation_result: dict) -> str:
    """Generate prefilter evaluation section"""
    eval_template = load_template("prefilter_evaluation/result")
    resume_template = load_template("prefilter_evaluation/resume_parsing_evaluation")
    location_template = load_template("prefilter_evaluation/location_evaluation")

    # Default values
    status = "No pre-filter evaluation data available"
    reasons_section = ""
    resume_section = ""
    location_section = ""
    duplicate_section = ""

    if not evaluation_result:
        return eval_template.format(
            status=status,
            reasons_section=reasons_section,
            resume_parsing_evaluation=resume_section,
            location_evaluation=location_section,
        )

    # Initial status setup
    status = "✅ Passed" if evaluation_result.get("passed") else "❌ Rejected"

    # Reasons section
    if reasons := evaluation_result.get("reasons", []):
        reasons_section = f"Reasons: {', '.join(reasons)}\n"

    # Resume parsing section
    if parsing_details := evaluation_result.get("parsing_details"):
        if parsed_section := _generate_resume_parsing_section(parsing_details):
            resume_section = resume_template.format(
                resume_parsing_details_section=parsed_section
            )

    # Location evaluation section
    if location_details := evaluation_result.get("location_details"):
        location_output, status_override = _generate_location_section(location_details)
        if location_output:
            location_section = location_template.format(
                location_details_section=location_output
            )
        if status_override:
            status = status_override

    # Duplicate evaluation section
    if dup_info := evaluation_result.get("duplicate_candidate_details"):
        dup_text, dup_override = _generate_duplicate_section(dup_info)
        if dup_text:
            dup_template = load_template("prefilter_evaluation/duplicate_evaluation")
            duplicate_section = dup_template.format(
                duplicate_evaluation_section=dup_text
            )
        if dup_override:
            status = dup_override

    return eval_template.format(
        status=status,
        reasons_section=reasons_section,
        resume_parsing_evaluation=resume_section,
        location_evaluation=location_section,
        duplicate_evaluation=duplicate_section,
    )


def _generate_analysis_section(analysis: str, score: int, level_summary: str) -> str:
    """Generate AI analysis section for qualified candidates"""
    template = load_template("ai_analysis/result")
    return template.format(
        analysis=analysis.strip() if analysis else "No analysis available",
        score=score,
        level_evaluation_summary=level_summary.strip() if level_summary else "",
    )


def generate_final_comment(
    analysis: str = None,
    score: int = None,
    level_summary: str = None,
    evaluation_result: dict = None,
) -> str:
    """
    Generate appropriate comment based on available data
    Includes evaluation results for all candidate types
    """
    try:
        # Generate prefilter section
        eval_section = _generate_prefilter_section(evaluation_result)

        # Generate analysis section for qualified candidates
        if score is not None:
            analysis_section = _generate_analysis_section(
                analysis, score, level_summary
            )
            full_comment = eval_section + analysis_section
        else:
            full_comment = (
                eval_section + "🚫 Candidate rejected during pre-filter evaluation"
            )

        # Clean up excessive newlines
        return re.sub(r"\n{3,}", "\n\n", full_comment)

    except Exception as e:
        logger.error(f"Error generating comment: {str(e)}", exc_info=True)
        return "Automated evaluation completed - error generating details"
