import logging
import re
from services.jazzhr_api import fetch_job_information, fetch_user_information

from config.constants import ADMIN_EMAILS
from config.env_config import JOB_ROLE_TITLE, JOB_CITY_LOCATION, REPORT_EMAIL

logger = logging.getLogger(__name__)


def is_valid_email(email: str) -> bool:
    """Check if the email is in valid format."""
    email_pattern = r"^[^@]+@[^@]+\.[^@]+$"
    return bool(re.match(email_pattern, email))


def get_report_recipients() -> list:
    """
    Get all email recipients for the report (hiring lead + admins + optional REPORT_EMAIL)

    Returns:
        list: List of unique email addresses
    """
    try:
        recipients = set(ADMIN_EMAILS)

        # Add REPORT_EMAIL if it's non-empty and valid
        if REPORT_EMAIL and is_valid_email(REPORT_EMAIL):
            recipients.add(REPORT_EMAIL)
        elif REPORT_EMAIL:
            logger.warning(f"Invalid REPORT_EMAIL: {REPORT_EMAIL}")

        # Get job information
        job_info_list = fetch_job_information(
            title=JOB_ROLE_TITLE, city=JOB_CITY_LOCATION
        )
        if not job_info_list:
            logger.error("Failed to fetch job information")
            return list(recipients)

        if len(job_info_list) != 1:
            logger.warning(
                f"Expected 1 job, but got {len(job_info_list)} jobs for title={JOB_ROLE_TITLE}, city={JOB_CITY_LOCATION}"
            )
            return list(recipients)

        job_info = job_info_list[0]
        hiring_lead_id = job_info.get("hiring_lead")
        if not hiring_lead_id:
            logger.warning("No hiring lead found for job")
            return list(recipients)

        user_info = fetch_user_information(hiring_lead_id)
        if not user_info or "email" not in user_info:
            logger.warning("Failed to fetch hiring lead information")
            return list(recipients)

        hiring_lead_email = user_info["email"]
        recipients.add(hiring_lead_email)

        return list(recipients)

    except Exception as e:
        logger.exception(f"Error getting recipients: {str(e)}")
        return list(ADMIN_EMAILS)
