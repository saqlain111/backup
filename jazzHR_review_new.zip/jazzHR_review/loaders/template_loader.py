from pathlib import Path
import logging

logger = logging.getLogger(__name__)


def load_template(template_name: str) -> str:
    template_path = Path(__file__).parent.parent / "templates" / f"{template_name}.txt"

    try:
        with open(template_path, "r") as f:
            content = f.read()
            logger.info(f"Loaded template: {template_path.name}")
            return content

    except FileNotFoundError:
        logger.error(f"Template file not found: {template_path}")
        raise

    except Exception as e:
        logger.error(f"Error loading template {template_path}: {str(e)}")
        raise
