from pathlib import Path
import yaml
import logging

logger = logging.getLogger(__name__)


def load_prompt(prompt_name: str) -> str:
    prompt_path = Path(__file__).parent.parent / "prompts" / f"{prompt_name}.yaml"

    try:
        with open(prompt_path, "r") as f:
            data = yaml.safe_load(f)
            template = data.get("template")

            if not template:
                logger.warning(f"'template' key missing in {prompt_path}")
                raise KeyError(f"'template' key not found in {prompt_path}")

            logger.info(f"Loaded prompt: {prompt_path.name}")
            return template

    except FileNotFoundError:
        logger.error(f"Prompt file not found: {prompt_path}")
        raise

    except yaml.YAMLError as e:
        logger.error(f"YAML parsing error in {prompt_path}: {str(e)}")
        raise
