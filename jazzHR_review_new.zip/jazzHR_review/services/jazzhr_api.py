import logging
import requests
import urllib.parse
import time
import random
from datetime import datetime, timedelta
from typing import Optional

from config.constants import JAZZHR_API_BASE_URL
from config.env_config import JOB_ID, API_KEY

logger = logging.getLogger(__name__)


def post_comment_to_jazzhr(applicant_id: str, comment_text: str) -> bool:
    """
    Post a comment to a candidate's profile in JazzHR.

    Args:
        applicant_id (str): Unique applicant ID in JazzHR
        comment_text (str): The comment content to post

    Returns:
        bool: True if the comment was posted successfully, False otherwise
    """
    try:
        payload = {
            "apikey": API_KEY,
            "applicant_id": applicant_id,
            "contents": comment_text,
            "security": "1",
        }

        headers = {"Content-Type": "application/json"}

        logger.info(f"Posting comment for applicant ID: {applicant_id}")
        comment_api_url = f"{JAZZHR_API_BASE_URL}/notes"
        response = requests.post(comment_api_url, json=payload, headers=headers)

        if response.status_code == 200:
            try:
                result = response.json()
                comment_id = result.get("comment_id")
                logger.info(f"✓ Comment posted successfully! Comment ID: {comment_id}")
            except Exception:
                logger.info(
                    "✓ Comment posted, but response could not be parsed as JSON"
                )
            return True

        logger.error(f"❌ Failed to post comment: HTTP {response.status_code}")
        logger.debug(f"Response: {response.text}")
        return False

    except requests.RequestException as e:
        logger.error(f"❌ Request failed: {str(e)}")
        return False
    except Exception as e:
        logger.exception(f"❌ Unexpected error while posting comment: {str(e)}")
        return False


def fetch_candidates_from_api() -> list:
    """
    Fetch candidates from the JazzHR API.

    Returns:
        list: List of candidate dictionaries, or empty list on failure.
    """
    try:
        logger.info("📥 Fetching candidates from JazzHR API...")
        candidates_api_url = f"{JAZZHR_API_BASE_URL}/applicants/job_id/{JOB_ID}/status/1?apikey={API_KEY}"
        response = requests.get(candidates_api_url)

        if response.status_code != 200:
            logger.error(
                f"❌ API request failed with status code {response.status_code}"
            )
            logger.debug(f"Response: {response.text}")
            return []

        candidates_data = response.json()

        if isinstance(candidates_data, dict):
            logger.info("Received single candidate. Wrapping into list.")
            return [candidates_data]

        if isinstance(candidates_data, list):
            logger.info(f"✅ Retrieved {len(candidates_data)} candidates.")
            return candidates_data

        logger.error(f"❌ Unexpected response type: {type(candidates_data)}")
        logger.debug(f"Response content: {candidates_data}")
        return []

    except requests.RequestException as e:
        logger.error(f"❌ Request error while fetching candidates: {str(e)}")
        return []
    except Exception as e:
        logger.exception(f"❌ Unexpected error while fetching candidates: {str(e)}")
        return []


def get_applicants_by_full_name_chunked(
    first_name: str,
    last_name: str,
    current_apply_date: str,
    chunk_months: int = 1,
    total_years: int = 2,
    match_checker_func=None,
) -> list[dict]:
    """
    Fetch applicants matching the full name from JazzHR API using date-based chunking.
    Optimized to deduplicate candidates at the chunk level to avoid reprocessing.

    Args:
        first_name: First name of the applicant
        last_name: Last name of the applicant
        current_apply_date: Current application date in YYYY-MM-DD format
        chunk_months: Number of months per chunk (default: 1)
        total_years: Total years to search back (default: 2)
        match_checker_func: Optional function to check if found applicants match criteria.
                           Should return True if match found, False to continue searching.
                           Function signature: match_checker_func(chunk_applicants_list) -> bool

    Returns:
        List of applicant dictionaries
    """
    try:
        full_name = f"{first_name} {last_name}".strip()
        logger.info(
            f"📥 Starting chunked search for applicants by full name='{full_name}'"
        )

        # Parse the current apply date
        current_date = datetime.strptime(current_apply_date, "%Y-%m-%d")

        # Calculate the earliest date (2 years back from current date)
        earliest_date = current_date - timedelta(days=total_years * 365)

        all_applicants = []
        seen_applicant_ids = set()  # Track seen IDs to avoid reprocessing
        current_end_date = current_date
        chunk_number = 1

        while current_end_date > earliest_date:
            # Calculate chunk start date (chunk_months back from current end date)
            current_start_date = current_end_date - timedelta(days=chunk_months * 30)

            # Don't go before the earliest date
            if current_start_date < earliest_date:
                current_start_date = earliest_date

            # Skip if the chunk is too small (less than 1 day) or if we've reached the limit
            if current_end_date <= current_start_date:
                logger.info(
                    f"🛑 Chunk {chunk_number}: Date range too small or reached earliest date, stopping search"
                )
                break

            # Format dates for API
            from_date = current_start_date.strftime("%Y-%m-%d")
            to_date = current_end_date.strftime("%Y-%m-%d")

            logger.info(
                f"🔍 Chunk {chunk_number}: Searching from {from_date} to {to_date}"
            )

            # Get applicants for this chunk
            chunk_applicants = get_applicants_chunk(full_name, from_date, to_date)

            if chunk_applicants:
                # Deduplicate within this chunk based on what we've already seen
                unique_chunk_applicants = []
                new_applicants_count = 0

                for applicant in chunk_applicants:
                    applicant_id = get_applicant_id(applicant)

                    if applicant_id not in seen_applicant_ids:
                        seen_applicant_ids.add(applicant_id)
                        unique_chunk_applicants.append(applicant)
                        new_applicants_count += 1

                logger.info(
                    f"✅ Chunk {chunk_number}: Found {len(chunk_applicants)} total applicants, "
                    f"{new_applicants_count} new (unique), {len(chunk_applicants) - new_applicants_count} duplicates"
                )

                if unique_chunk_applicants:
                    # If match checker function is provided, use it to determine if we should stop
                    if match_checker_func:
                        # Pass only the NEW unique applicants from this chunk
                        if match_checker_func(unique_chunk_applicants):
                            logger.info(
                                f"🎯 Match found in chunk {chunk_number} - STOPPING SEARCH"
                            )
                            # Add current chunk's unique applicants to accumulated list before stopping
                            all_applicants.extend(unique_chunk_applicants)
                            break
                        else:
                            logger.info(
                                f"🔄 No matching criteria found in chunk {chunk_number} - CONTINUING SEARCH"
                            )
                            # Add current chunk's unique applicants to accumulated list and continue
                            all_applicants.extend(unique_chunk_applicants)
                    else:
                        # Default behavior: stop on first unique applicants found
                        all_applicants.extend(unique_chunk_applicants)
                        logger.info(
                            f"✅ Chunk {chunk_number}: Found {new_applicants_count} new applicants - STOPPING SEARCH (no match checker)"
                        )
                        break
                else:
                    logger.info(
                        f"📭 Chunk {chunk_number}: No new unique applicants found (all were duplicates)"
                    )
            else:
                logger.info(f"📭 Chunk {chunk_number}: No applicants found")

            # Move to next chunk: set end date to start date minus 1 day (no overlap)
            next_end_date = current_start_date - timedelta(days=1)

            # Check if we've reached or passed the earliest date
            if next_end_date <= earliest_date:
                logger.info(
                    f"🛑 Reached earliest date limit after chunk {chunk_number}, stopping search"
                )
                break

            current_end_date = next_end_date
            chunk_number += 1

            # Safety check to prevent infinite loops
            if chunk_number > 50:  # Reasonable limit
                logger.warning(
                    f"🛑 Reached maximum chunk limit ({chunk_number-1}), stopping search"
                )
                break

        if all_applicants:
            logger.info(
                f"🎯 Search completed - found {len(all_applicants)} unique applicants across {chunk_number-1} chunks"
            )
        else:
            logger.info(
                f"📭 Search completed - no applicants found across all {chunk_number-1} chunks"
            )

        return all_applicants

    except ValueError as e:
        logger.error(f"❌ Invalid date format: {str(e)}")
        return []
    except Exception as e:
        logger.exception(f"❌ Unexpected error during chunked search: {str(e)}")
        return []


def get_applicant_id(applicant: dict) -> str:
    """
    Extract a unique identifier for an applicant.

    Args:
        applicant: Applicant dictionary

    Returns:
        Unique identifier string
    """
    # Try different possible ID fields
    applicant_id = (
        applicant.get("id")
        or applicant.get("applicant_id")
        or applicant.get("Id")
        or f"{applicant.get('first_name', '')}_{applicant.get('last_name', '')}_{applicant.get('email', '')}"
    )
    return str(applicant_id)


def get_applicants_chunk(full_name: str, from_date: str, to_date: str) -> list[dict]:
    """
    Fetch applicants for a specific date range chunk with exponential retry logic.

    Args:
        full_name: Full name to search for
        from_date: Start date in YYYY-MM-DD format
        to_date: End date in YYYY-MM-DD format

    Returns:
        List of applicant dictionaries for this chunk
    """
    max_retries = 5
    base_delay = 5

    for attempt in range(max_retries + 1):
        try:
            # URL-encode parameters to handle special characters
            encoded_full_name = urllib.parse.quote(full_name)
            encoded_from_date = urllib.parse.quote(from_date)
            encoded_to_date = urllib.parse.quote(to_date)

            url = (
                f"{JAZZHR_API_BASE_URL}/applicants/name/{encoded_full_name}/"
                f"from_apply_date/{encoded_from_date}/"
                f"to_apply_date/{encoded_to_date}/"
                f"?apikey={API_KEY}"
            )

            if attempt > 0:
                logger.info(
                    f"🔄 Retry attempt {attempt} for date range {from_date} to {to_date}"
                )

            response = requests.get(url, timeout=60)

            if response.status_code != 200:
                error_msg = (
                    f"❌ Chunk request failed with status code {response.status_code} "
                    f"for date range {from_date} to {to_date}"
                )

                # Check if it's a retryable error
                if (
                    response.status_code in [429, 500, 502, 503, 504]
                    and attempt < max_retries
                ):
                    logger.warning(f"{error_msg} - Will retry")
                    delay = calculate_retry_delay(attempt, base_delay)
                    logger.info(f"⏳ Waiting {delay:.2f} seconds before retry...")
                    time.sleep(delay)
                    continue
                else:
                    logger.error(error_msg)
                    logger.debug(f"Response: {response.text}")
                    return []

            data = response.json()

            # Handle different response formats
            if isinstance(data, dict):
                if attempt > 0:
                    logger.info(f"✅ Retry successful after {attempt} attempts")
                return [data]
            elif isinstance(data, list):
                if attempt > 0:
                    logger.info(f"✅ Retry successful after {attempt} attempts")
                return data
            else:
                logger.error(f"❌ Unexpected response type: {type(data)}")
                return []

        except requests.Timeout as e:
            error_msg = (
                f"⏰ Chunk request timed out for date range {from_date} to {to_date}"
            )
            if attempt < max_retries:
                logger.warning(f"{error_msg} - Will retry")
                delay = calculate_retry_delay(attempt, base_delay)
                logger.info(f"⏳ Waiting {delay:.2f} seconds before retry...")
                time.sleep(delay)
                continue
            else:
                logger.error(f"{error_msg} - Max retries exceeded")
                return []

        except requests.RequestException as e:
            error_msg = f"❌ Request error for chunk {from_date} to {to_date}: {str(e)}"
            if attempt < max_retries:
                logger.warning(f"{error_msg} - Will retry")
                delay = calculate_retry_delay(attempt, base_delay)
                logger.info(f"⏳ Waiting {delay:.2f} seconds before retry...")
                time.sleep(delay)
                continue
            else:
                logger.error(f"{error_msg} - Max retries exceeded")
                return []

        except Exception as e:
            error_msg = (
                f"❌ Unexpected error for chunk {from_date} to {to_date}: {str(e)}"
            )
            if attempt < max_retries:
                logger.warning(f"{error_msg} - Will retry")
                delay = calculate_retry_delay(attempt, base_delay)
                logger.info(f"⏳ Waiting {delay:.2f} seconds before retry...")
                time.sleep(delay)
                continue
            else:
                logger.exception(f"{error_msg} - Max retries exceeded")
                return []

    # This should never be reached, but just in case
    return []


def calculate_retry_delay(attempt: int, base_delay: float) -> float:
    """
    Calculate exponential backoff delay with jitter.

    Args:
        attempt: Current attempt number (0-based)
        base_delay: Base delay in seconds

    Returns:
        Delay in seconds
    """
    # Exponential backoff: base_delay * (2 ^ attempt)
    delay = base_delay * (2**attempt)

    # Add jitter (±25% randomness) to avoid thundering herd
    jitter = delay * 0.25 * random.uniform(-1, 1)
    final_delay = delay + jitter

    # Cap maximum delay at 30 seconds
    return min(final_delay, 30.0)


def remove_duplicate_applicants(applicants: list[dict]) -> list[dict]:
    """
    Remove duplicate applicants based on ID or other unique identifiers.
    Note: This function is now primarily used as a final safety net,
    as deduplication is handled at the chunk level.

    Args:
        applicants: List of applicant dictionaries

    Returns:
        List of unique applicants
    """
    if not applicants:
        return []

    seen_ids = set()
    unique_applicants = []

    for applicant in applicants:
        applicant_id = get_applicant_id(applicant)

        if applicant_id not in seen_ids:
            seen_ids.add(applicant_id)
            unique_applicants.append(applicant)

    return unique_applicants


# Wrapper function that maintains backward compatibility
def get_applicants_by_full_name(
    first_name: str,
    last_name: str,
    current_apply_date: Optional[str] = None,
    match_checker_func=None,
) -> list[dict]:
    """
    Backward compatible wrapper for the original function.
    If current_apply_date is provided, uses chunked search; otherwise falls back to original logic.
    """
    if current_apply_date:
        return get_applicants_by_full_name_chunked(
            first_name,
            last_name,
            current_apply_date,
            match_checker_func=match_checker_func,
        )
    else:
        # Original implementation for backward compatibility
        try:
            full_name = f"{first_name} {last_name}".strip()
            logger.info(
                f"📥 Searching applicants by full name='{full_name}' (non-chunked)"
            )
            encoded_full_name = urllib.parse.quote(full_name)
            url = f"{JAZZHR_API_BASE_URL}/applicants/name/{encoded_full_name}?apikey={API_KEY}"
            response = requests.get(url, timeout=180)

            if response.status_code != 200:
                logger.error(
                    f"❌ Search request failed with status code {response.status_code}"
                )
                logger.debug(f"Response: {response.text}")
                return []

            data = response.json()
            if isinstance(data, dict):
                return [data]
            if isinstance(data, list):
                return data

            logger.error(f"❌ Unexpected response type: {type(data)}")
            return []
        except requests.Timeout:
            logger.error("⏰ Request timed out after 3 minutes")
            return []
        except requests.RequestException as e:
            logger.error(f"❌ Request error during search: {str(e)}")
            return []
        except Exception as e:
            logger.exception(f"❌ Unexpected error during search: {str(e)}")
            return []


def get_applicant_by_id(prospect_id: str) -> dict:
    """
    Fetch full details for an applicant by ID (including status and apply_date).

    Returns:
        dict: Applicant details, or empty dict on failure.
    """
    try:
        logger.info(f"📥 Fetching details for applicant ID: {prospect_id}")
        url = f"{JAZZHR_API_BASE_URL}/applicants/{prospect_id}?apikey={API_KEY}"
        response = requests.get(url)

        if response.status_code != 200:
            logger.error(
                f"❌ Detail request failed with status code {response.status_code}"
            )
            logger.debug(f"Response: {response.text}")
            return {}

        return response.json()

    except requests.RequestException as e:
        logger.error(f"❌ Request error fetching details: {str(e)}")
        return {}
    except Exception as e:
        logger.exception(f"❌ Unexpected error fetching details: {str(e)}")


def fetch_job_information(title: str, city: str, status: str = "open") -> list:
    """
    Fetch job information from JazzHR API based on title, city, and status.

    Args:
        title (str): Job title to search for
        city (str): Job location city
        status (str): Job status (e.g., 'open', 'closed')

    Returns:
        list: List of job dictionaries, or empty list on failure
    """
    try:
        # URL-encode parameters to handle special characters
        encoded_title = urllib.parse.quote(title)
        encoded_city = urllib.parse.quote(city)
        encoded_status = urllib.parse.quote(status)

        # Construct API endpoint URL
        jobs_api_url = (
            f"{JAZZHR_API_BASE_URL}/jobs/title/{encoded_title}/"
            f"city/{encoded_city}/status/{encoded_status}?"
            f"apikey={API_KEY}"
        )

        logger.info(f"📡 Fetching jobs: {title} in {city} ({status} status)")
        response = requests.get(jobs_api_url)

        if response.status_code != 200:
            logger.error(
                f"❌ Job API request failed with status {response.status_code}"
            )
            logger.debug(f"URL: {jobs_api_url}\nResponse: {response.text}")
            return []

        jobs_data = response.json()

        # Handle API response whether single object or list
        if isinstance(jobs_data, dict):
            return [jobs_data]
        if isinstance(jobs_data, list):
            logger.info(f"✅ Found {len(jobs_data)} matching jobs")
            return jobs_data

        logger.error(f"❌ Unexpected response type: {type(jobs_data)}")
        return []

    except requests.RequestException as e:
        logger.error(f"❌ Network error fetching jobs: {str(e)}")
        return []
    except Exception as e:
        logger.exception(f"❌ Unexpected error fetching jobs: {str(e)}")
        return []


def fetch_user_information(user_id: str) -> dict:
    """
    Fetch user information from JazzHR API based on user ID.

    Args:
        user_id (str): Unique user ID in JazzHR

    Returns:
        dict: User information dictionary, or empty dict on failure
    """
    try:
        # Construct API endpoint URL
        user_api_url = f"{JAZZHR_API_BASE_URL}/users/{user_id}?apikey={API_KEY}"

        logger.info(f"👤 Fetching user information for ID: {user_id}")
        response = requests.get(user_api_url)

        if response.status_code != 200:
            logger.error(
                f"❌ User API request failed with status {response.status_code}"
            )
            logger.debug(f"URL: {user_api_url}\nResponse: {response.text}")
            return {}

        user_data = response.json()

        if isinstance(user_data, dict):
            logger.info(
                f"✅ Retrieved user: {user_data.get('first_name', 'Unknown')} {user_data.get('last_name', 'Unknown')}"
            )
            return user_data

        logger.error(f"❌ Unexpected response type: {type(user_data)}")
        return {}

    except requests.RequestException as e:
        logger.error(f"❌ Network error fetching user: {str(e)}")
        return {}
    except Exception as e:
        logger.exception(f"❌ Unexpected error fetching user: {str(e)}")
        return {}
