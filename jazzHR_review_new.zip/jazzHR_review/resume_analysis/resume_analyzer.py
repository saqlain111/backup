import logging

from utils.gemini_client import query_gemini

from config.env_config import CUSTOM_PROMPT

logger = logging.getLogger(__name__)


def analyze_resume_with_gemini(resume_json_text: str) -> str:
    """
    Analyze resume text using Google's Gemini API.

    Args:
        resume_text (str): Text extracted from resume file

    Returns:
        str: AI-generated analysis or error message
    """
    try:
        if not CUSTOM_PROMPT:
            logger.error("CUSTOM_PROMPT not provided.")
            raise ValueError("CUSTOM_PROMPT is required")

        full_prompt = f"{CUSTOM_PROMPT}\n\nResume JSON text:\n{resume_json_text}"
        logger.debug("Sending prompt to Gemini API.")

        # Query Gemini
        response = query_gemini(full_prompt)

        return response.text

    except Exception as e:
        logger.exception("Error analyzing resume with Gemini.")
        return f"Error analyzing resume: {str(e)}"
