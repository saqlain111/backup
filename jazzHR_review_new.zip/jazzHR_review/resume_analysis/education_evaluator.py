import json
import logging

from typing import Dict, Tuple, List

from utils.gemini_client import query_gemini
from utils.json_utils import parse_json_response
from loaders.template_loader import load_template
from loaders.prompt_loader import load_prompt

logger = logging.getLogger(__name__)


def evaluate_education_with_gemini(
    education_data: List[Dict],
) -> Tuple[bool, str, Dict]:
    """
    Evaluate education requirements using Gemini AI with enhanced error handling

    Args:
        education_data: List of education dictionaries extracted from resume

    Returns:
        Tuple of (is_qualified, reason, analysis_data)
    """
    try:
        # Load prompt components
        custom_prompt = load_prompt("education_evaluation")
        template = load_template("ai_analysis/education_evaluation_prompt")

        # Build the final prompt
        prompt = template.format(
            custom_prompt=custom_prompt,
            education_data_json=json.dumps(education_data, indent=2),
        )
        logger.debug("Constructed education evaluation prompt")

        # Query Gemini
        response = query_gemini(prompt)
        response_text = response.text

        # Parse and validate response
        result = parse_json_response(response_text)

        # Handle error in parsing
        if "error" in result:
            logger.error(f"Gemini response parsing error: {result['error']}")
            return False, f"AI evaluation failed: {result['error']}", result

        # Extract results with validation
        is_qualified = result.get("qualified", False)
        reason = result.get("reason", "No reason provided")
        confidence = result.get("confidence", "unknown")

        # Validate required fields are present
        if not isinstance(is_qualified, bool):
            logger.warning(
                f"Invalid 'qualified' value: {is_qualified}, defaulting to False"
            )
            is_qualified = False

        analysis_data = {
            "qualified": is_qualified,
            "reason": reason,
            "confidence": confidence,
            "highest_degree": result.get("highest_degree", "Unknown"),
            "relevant_field": result.get("relevant_field", "Unknown"),
            "detailed_analysis": result.get(
                "analysis", "No detailed analysis provided"
            ),
            "raw_response": response_text,
            "education_data": education_data,
        }

        logger.info(
            f"Education evaluation completed: qualified={is_qualified}, confidence={confidence}"
        )

        return is_qualified, reason, analysis_data

    except FileNotFoundError as e:
        logger.error(f"Template/prompt file not found: {e}")
        return (
            False,
            f"Configuration error: {str(e)}",
            {
                "error": f"Missing template/prompt file: {str(e)}",
                "education_data": education_data,
            },
        )

    except json.JSONDecodeError as e:
        logger.error(f"Invalid education data JSON: {e}")
        return (
            False,
            f"Data formatting error: {str(e)}",
            {
                "error": f"Education data JSON invalid: {str(e)}",
                "education_data": education_data,
            },
        )

    except Exception as e:
        logger.exception("Fatal error in education evaluation")
        return (
            False,
            f"Evaluation failed: {str(e)}",
            {
                "error": f"Processing failed: {str(e)}",
                "error_type": type(e).__name__,
                "education_data": education_data,
            },
        )
