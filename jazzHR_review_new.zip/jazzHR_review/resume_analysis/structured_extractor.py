import json
import re
import logging
import json_repair

from utils.gemini_client import query_gemini
from utils.json_utils import parse_json_response
from loaders.template_loader import load_template
from loaders.prompt_loader import load_prompt

logger = logging.getLogger(__name__)


def generate_structured_resume(resume_json_text: str, hyperlinks: list) -> dict:
    """
    Generate structured resume JSON using Gemini with enhanced error handling

    Args:
        text: Extracted resume text
        hyperlinks: List of hyperlinks from resume

    Returns:
        Structured resume data with error information if processing fails
    """
    try:
        # Load prompt components
        custom_prompt = load_prompt("resume_extraction")
        template = load_template("ai_analysis/resume_extraction_prompt")

        # Build the final prompt
        prompt = template.format(
            custom_prompt=custom_prompt,
            resume_json_text=resume_json_text[:15000],  # Truncate to avoid token limits
            hyperlinks_json=json.dumps(hyperlinks),
        )
        logger.debug("Constructed structured resume extraction prompt")

        # Query Gemini
        response = query_gemini(prompt)
        response_text = response.text

        # Parse and validate response
        result = parse_json_response(response_text)

        # Post-process hyperlinks
        result.setdefault("hyperlinks", [])
        ai_urls = {
            link["url"].lower() for link in result["hyperlinks"] if "url" in link
        }

        # Add missing hyperlinks with context detection
        for url in hyperlinks:
            norm_url = url.lower()
            if norm_url in ai_urls:
                continue

            # Context detection logic
            context = "other"
            if "linkedin" in norm_url:
                context = "profile"
            elif "github" in norm_url:
                context = "profile"
            elif "mailto:" in norm_url:
                context = "contact"
            elif "portfolio" in norm_url:
                context = "profile"
            elif any(x in norm_url for x in [".edu", "university", "college"]):
                context = "education"
            elif any(x in norm_url for x in ["amazonaws", "s3"]):
                context = "storage"

            result["hyperlinks"].append(
                {"url": url, "context": context, "source": "direct_extraction"}
            )

        return result

    except FileNotFoundError as e:
        logger.error(f"Template/prompt file not found: {e}")
        return {
            "error": f"Missing template/prompt file: {str(e)}",
            "text": resume_json_text,
            "hyperlinks": hyperlinks,
        }

    except json.JSONDecodeError as e:
        logger.error(f"Invalid hyperlinks JSON: {e}")
        return {
            "error": f"Hyperlinks JSON invalid: {str(e)}",
            "text": resume_json_text,
            "hyperlinks": hyperlinks,
        }

    except Exception as e:
        logger.exception("Fatal error in structured resume generation")
        return {
            "error": f"Processing failed: {str(e)}",
            "error_type": type(e).__name__,
            "text": resume_json_text,
            "hyperlinks": hyperlinks,
        }
